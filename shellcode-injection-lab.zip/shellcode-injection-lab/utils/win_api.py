"""
Windows API Wrapper Utilities
=============================
Shellcode injection için gereken Windows API fonksiyonlarını saran yardımcı modül.

Author: Ugur Ates
Purpose: Educational - Blue Team & Red Team Training
"""

import ctypes
from ctypes import wintypes
import struct

# ============================================================================
# CONSTANTS
# ============================================================================

# Memory Allocation Types
MEM_COMMIT = 0x1000
MEM_RESERVE = 0x2000
MEM_RELEASE = 0x8000

# Memory Protection Constants
PAGE_NOACCESS = 0x01
PAGE_READONLY = 0x02
PAGE_READWRITE = 0x04
PAGE_WRITECOPY = 0x08
PAGE_EXECUTE = 0x10
PAGE_EXECUTE_READ = 0x20
PAGE_EXECUTE_READWRITE = 0x40
PAGE_EXECUTE_WRITECOPY = 0x80

# Process Access Rights
PROCESS_ALL_ACCESS = 0x1F0FFF
PROCESS_CREATE_THREAD = 0x0002
PROCESS_VM_OPERATION = 0x0008
PROCESS_VM_READ = 0x0010
PROCESS_VM_WRITE = 0x0020
PROCESS_QUERY_INFORMATION = 0x0400

# Thread Access Rights
THREAD_ALL_ACCESS = 0x1F03FF
THREAD_GET_CONTEXT = 0x0008
THREAD_SET_CONTEXT = 0x0010
THREAD_SUSPEND_RESUME = 0x0002

# Process Creation Flags
CREATE_SUSPENDED = 0x00000004
CREATE_NO_WINDOW = 0x08000000

# Wait Constants
INFINITE = 0xFFFFFFFF

# ============================================================================
# STRUCTURES
# ============================================================================

class STARTUPINFO(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("lpReserved", wintypes.LPWSTR),
        ("lpDesktop", wintypes.LPWSTR),
        ("lpTitle", wintypes.LPWSTR),
        ("dwX", wintypes.DWORD),
        ("dwY", wintypes.DWORD),
        ("dwXSize", wintypes.DWORD),
        ("dwYSize", wintypes.DWORD),
        ("dwXCountChars", wintypes.DWORD),
        ("dwYCountChars", wintypes.DWORD),
        ("dwFillAttribute", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("wShowWindow", wintypes.WORD),
        ("cbReserved2", wintypes.WORD),
        ("lpReserved2", ctypes.POINTER(wintypes.BYTE)),
        ("hStdInput", wintypes.HANDLE),
        ("hStdOutput", wintypes.HANDLE),
        ("hStdError", wintypes.HANDLE),
    ]

class PROCESS_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("hProcess", wintypes.HANDLE),
        ("hThread", wintypes.HANDLE),
        ("dwProcessId", wintypes.DWORD),
        ("dwThreadId", wintypes.DWORD),
    ]

class CONTEXT64(ctypes.Structure):
    """64-bit thread context structure"""
    _fields_ = [
        ("P1Home", ctypes.c_ulonglong),
        ("P2Home", ctypes.c_ulonglong),
        ("P3Home", ctypes.c_ulonglong),
        ("P4Home", ctypes.c_ulonglong),
        ("P5Home", ctypes.c_ulonglong),
        ("P6Home", ctypes.c_ulonglong),
        ("ContextFlags", wintypes.DWORD),
        ("MxCsr", wintypes.DWORD),
        ("SegCs", wintypes.WORD),
        ("SegDs", wintypes.WORD),
        ("SegEs", wintypes.WORD),
        ("SegFs", wintypes.WORD),
        ("SegGs", wintypes.WORD),
        ("SegSs", wintypes.WORD),
        ("EFlags", wintypes.DWORD),
        ("Dr0", ctypes.c_ulonglong),
        ("Dr1", ctypes.c_ulonglong),
        ("Dr2", ctypes.c_ulonglong),
        ("Dr3", ctypes.c_ulonglong),
        ("Dr6", ctypes.c_ulonglong),
        ("Dr7", ctypes.c_ulonglong),
        ("Rax", ctypes.c_ulonglong),
        ("Rcx", ctypes.c_ulonglong),
        ("Rdx", ctypes.c_ulonglong),
        ("Rbx", ctypes.c_ulonglong),
        ("Rsp", ctypes.c_ulonglong),
        ("Rbp", ctypes.c_ulonglong),
        ("Rsi", ctypes.c_ulonglong),
        ("Rdi", ctypes.c_ulonglong),
        ("R8", ctypes.c_ulonglong),
        ("R9", ctypes.c_ulonglong),
        ("R10", ctypes.c_ulonglong),
        ("R11", ctypes.c_ulonglong),
        ("R12", ctypes.c_ulonglong),
        ("R13", ctypes.c_ulonglong),
        ("R14", ctypes.c_ulonglong),
        ("R15", ctypes.c_ulonglong),
        ("Rip", ctypes.c_ulonglong),
        # ... XMM registers omitted for brevity
    ]

# Context flags
CONTEXT_FULL = 0x10001F

# ============================================================================
# DLL LOADING
# ============================================================================

kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
ntdll = ctypes.WinDLL('ntdll', use_last_error=True)

# ============================================================================
# KERNEL32 FUNCTIONS
# ============================================================================

# VirtualAlloc - Local memory allocation
VirtualAlloc = kernel32.VirtualAlloc
VirtualAlloc.argtypes = [wintypes.LPVOID, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD]
VirtualAlloc.restype = wintypes.LPVOID

# VirtualAllocEx - Remote memory allocation
VirtualAllocEx = kernel32.VirtualAllocEx
VirtualAllocEx.argtypes = [wintypes.HANDLE, wintypes.LPVOID, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD]
VirtualAllocEx.restype = wintypes.LPVOID

# VirtualProtect - Change memory protection
VirtualProtect = kernel32.VirtualProtect
VirtualProtect.argtypes = [wintypes.LPVOID, ctypes.c_size_t, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
VirtualProtect.restype = wintypes.BOOL

# VirtualProtectEx - Remote memory protection change
VirtualProtectEx = kernel32.VirtualProtectEx
VirtualProtectEx.argtypes = [wintypes.HANDLE, wintypes.LPVOID, ctypes.c_size_t, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
VirtualProtectEx.restype = wintypes.BOOL

# VirtualFree - Free memory
VirtualFree = kernel32.VirtualFree
VirtualFree.argtypes = [wintypes.LPVOID, ctypes.c_size_t, wintypes.DWORD]
VirtualFree.restype = wintypes.BOOL

# WriteProcessMemory - Write to remote process
WriteProcessMemory = kernel32.WriteProcessMemory
WriteProcessMemory.argtypes = [wintypes.HANDLE, wintypes.LPVOID, wintypes.LPCVOID, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
WriteProcessMemory.restype = wintypes.BOOL

# ReadProcessMemory - Read from remote process
ReadProcessMemory = kernel32.ReadProcessMemory
ReadProcessMemory.argtypes = [wintypes.HANDLE, wintypes.LPCVOID, wintypes.LPVOID, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
ReadProcessMemory.restype = wintypes.BOOL

# CreateThread - Create local thread
CreateThread = kernel32.CreateThread
CreateThread.argtypes = [wintypes.LPVOID, ctypes.c_size_t, wintypes.LPVOID, wintypes.LPVOID, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
CreateThread.restype = wintypes.HANDLE

# CreateRemoteThread - Create thread in remote process
CreateRemoteThread = kernel32.CreateRemoteThread
CreateRemoteThread.argtypes = [wintypes.HANDLE, wintypes.LPVOID, ctypes.c_size_t, wintypes.LPVOID, wintypes.LPVOID, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
CreateRemoteThread.restype = wintypes.HANDLE

# OpenProcess - Open process handle
OpenProcess = kernel32.OpenProcess
OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenProcess.restype = wintypes.HANDLE

# OpenThread - Open thread handle
OpenThread = kernel32.OpenThread
OpenThread.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenThread.restype = wintypes.HANDLE

# CloseHandle - Close handle
CloseHandle = kernel32.CloseHandle
CloseHandle.argtypes = [wintypes.HANDLE]
CloseHandle.restype = wintypes.BOOL

# WaitForSingleObject - Wait for object
WaitForSingleObject = kernel32.WaitForSingleObject
WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
WaitForSingleObject.restype = wintypes.DWORD

# CreateProcessW - Create new process
CreateProcessW = kernel32.CreateProcessW
CreateProcessW.argtypes = [
    wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.LPVOID, wintypes.LPVOID,
    wintypes.BOOL, wintypes.DWORD, wintypes.LPVOID, wintypes.LPCWSTR,
    ctypes.POINTER(STARTUPINFO), ctypes.POINTER(PROCESS_INFORMATION)
]
CreateProcessW.restype = wintypes.BOOL

# ResumeThread - Resume suspended thread
ResumeThread = kernel32.ResumeThread
ResumeThread.argtypes = [wintypes.HANDLE]
ResumeThread.restype = wintypes.DWORD

# SuspendThread - Suspend thread
SuspendThread = kernel32.SuspendThread
SuspendThread.argtypes = [wintypes.HANDLE]
SuspendThread.restype = wintypes.DWORD

# GetThreadContext - Get thread context
GetThreadContext = kernel32.GetThreadContext
GetThreadContext.argtypes = [wintypes.HANDLE, ctypes.POINTER(CONTEXT64)]
GetThreadContext.restype = wintypes.BOOL

# SetThreadContext - Set thread context
SetThreadContext = kernel32.SetThreadContext
SetThreadContext.argtypes = [wintypes.HANDLE, ctypes.POINTER(CONTEXT64)]
SetThreadContext.restype = wintypes.BOOL

# QueueUserAPC - Queue APC to thread
QueueUserAPC = kernel32.QueueUserAPC
QueueUserAPC.argtypes = [wintypes.LPVOID, wintypes.HANDLE, wintypes.LPVOID]
QueueUserAPC.restype = wintypes.DWORD

# GetLastError
GetLastError = kernel32.GetLastError
GetLastError.restype = wintypes.DWORD

# ============================================================================
# NTDLL FUNCTIONS (for Direct Syscalls)
# ============================================================================

# NtAllocateVirtualMemory
NtAllocateVirtualMemory = ntdll.NtAllocateVirtualMemory
NtAllocateVirtualMemory.argtypes = [
    wintypes.HANDLE,  # ProcessHandle
    ctypes.POINTER(wintypes.LPVOID),  # BaseAddress
    ctypes.c_ulong,  # ZeroBits
    ctypes.POINTER(ctypes.c_size_t),  # RegionSize
    wintypes.ULONG,  # AllocationType
    wintypes.ULONG   # Protect
]
NtAllocateVirtualMemory.restype = wintypes.LONG

# NtWriteVirtualMemory
NtWriteVirtualMemory = ntdll.NtWriteVirtualMemory
NtWriteVirtualMemory.argtypes = [
    wintypes.HANDLE,  # ProcessHandle
    wintypes.LPVOID,  # BaseAddress
    wintypes.LPVOID,  # Buffer
    ctypes.c_size_t,  # NumberOfBytesToWrite
    ctypes.POINTER(ctypes.c_size_t)  # NumberOfBytesWritten
]
NtWriteVirtualMemory.restype = wintypes.LONG

# NtCreateThreadEx
NtCreateThreadEx = ntdll.NtCreateThreadEx
NtCreateThreadEx.argtypes = [
    ctypes.POINTER(wintypes.HANDLE),  # ThreadHandle
    wintypes.DWORD,  # DesiredAccess
    wintypes.LPVOID,  # ObjectAttributes
    wintypes.HANDLE,  # ProcessHandle
    wintypes.LPVOID,  # StartRoutine
    wintypes.LPVOID,  # Argument
    wintypes.ULONG,  # CreateFlags
    ctypes.c_size_t,  # ZeroBits
    ctypes.c_size_t,  # StackSize
    ctypes.c_size_t,  # MaximumStackSize
    wintypes.LPVOID   # AttributeList
]
NtCreateThreadEx.restype = wintypes.LONG

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_last_error_message():
    """Get human-readable error message for last error"""
    error_code = GetLastError()
    return f"Error Code: {error_code} (0x{error_code:08X})"

def bytes_to_hex(data: bytes) -> str:
    """Convert bytes to hex string for display"""
    return ' '.join(f'{b:02x}' for b in data)

def print_api_call(api_name: str, result, **kwargs):
    """Print API call details for educational purposes"""
    print(f"\n{'='*60}")
    print(f"📞 API Call: {api_name}")
    print(f"{'='*60}")
    for key, value in kwargs.items():
        if isinstance(value, bytes):
            print(f"   {key}: {bytes_to_hex(value[:32])}{'...' if len(value) > 32 else ''}")
        elif isinstance(value, int):
            print(f"   {key}: {value} (0x{value:X})")
        else:
            print(f"   {key}: {value}")
    print(f"   Result: {result}")
    if not result:
        print(f"   ⚠️ {get_last_error_message()}")
    print(f"{'='*60}\n")

# ============================================================================
# DETECTION NOTES FOR BLUE TEAM
# ============================================================================

DETECTION_NOTES = """
🛡️ BLUE TEAM DETECTION NOTES
=============================

1. VirtualAlloc/VirtualAllocEx with PAGE_EXECUTE_READWRITE
   - Sysmon Event ID 8 (CreateRemoteThread)
   - ETW: Microsoft-Windows-Kernel-Memory

2. WriteProcessMemory
   - Sysmon Event ID 10 (ProcessAccess)
   - Cross-process write is suspicious

3. CreateRemoteThread
   - Sysmon Event ID 8
   - Very commonly monitored

4. NtCreateThreadEx (Direct Syscall)
   - Harder to detect
   - Look for syscall patterns in memory

5. Process Hollowing Indicators:
   - CREATE_SUSPENDED flag
   - NtUnmapViewOfSection/ZwUnmapViewOfSection
   - Memory region changes in suspended process

6. Thread Hijacking:
   - SuspendThread followed by SetThreadContext
   - RIP/EIP modification
"""

if __name__ == "__main__":
    print("Windows API Utilities loaded successfully!")
    print(DETECTION_NOTES)
