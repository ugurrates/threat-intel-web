# MITRE ATT&CK Mapping - Shellcode Injection Techniques

## Genel Bakış

Bu dokümantasyon, shellcode injection tekniklerinin MITRE ATT&CK framework'ü ile eşleşmesini gösterir.

---

## T1055 - Process Injection

### Genel Bilgi
| Alan | Değer |
|------|-------|
| **Tactic** | Defense Evasion, Privilege Escalation |
| **Platform** | Windows, Linux, macOS |
| **Permissions** | User |
| **Data Sources** | Process monitoring, API monitoring, DLL monitoring |

### Alt Teknikler (Sub-techniques)

---

### T1055.001 - Dynamic-link Library Injection
**Dosya:** `techniques/02_remote_injection.py`

**Açıklama:**
- CreateRemoteThread ile remote thread injection
- DLL injection via LoadLibrary

**API Çağrıları:**
```
OpenProcess → VirtualAllocEx → WriteProcessMemory → CreateRemoteThread
```

**Detection:**
- Sysmon Event ID 8 (CreateRemoteThread)
- Sysmon Event ID 10 (ProcessAccess)

---

### T1055.003 - Thread Execution Hijacking
**Dosya:** `techniques/05_thread_hijacking.py` (TODO)

**Açıklama:**
- Mevcut thread'in execution flow'unu değiştirme
- SuspendThread + SetThreadContext + ResumeThread

**API Çağrıları:**
```
OpenThread → SuspendThread → VirtualAllocEx → WriteProcessMemory → GetThreadContext → SetThreadContext → ResumeThread
```

**Detection:**
- SetThreadContext API çağrısı
- Thread context değişikliği (RIP/EIP)

---

### T1055.004 - Asynchronous Procedure Call
**Dosya:** `techniques/04_apc_injection.py`

**Açıklama:**
- QueueUserAPC ile APC kuyruğuna shellcode ekleme
- Early Bird variant

**API Çağrıları:**
```
OpenProcess → VirtualAllocEx → WriteProcessMemory → OpenThread → QueueUserAPC
```

**Detection:**
- QueueUserAPC API çağrısı
- Cross-process APC

---

### T1055.012 - Process Hollowing
**Dosya:** `techniques/03_process_hollowing.py`

**Açıklama:**
- Suspended process oluşturma
- Orijinal image'i kaldırma (NtUnmapViewOfSection)
- Zararlı kod yazma

**API Çağrıları:**
```
CreateProcess(SUSPENDED) → NtUnmapViewOfSection → VirtualAllocEx → WriteProcessMemory → SetThreadContext → ResumeThread
```

**Detection:**
- CREATE_SUSPENDED flag
- NtUnmapViewOfSection çağrısı
- Image/memory mismatch

---

## T1106 - Native API

**Açıklama:**
- Direct syscall kullanımı
- NTDLL fonksiyonları

**Dosya:** `techniques/06_direct_syscalls.py` (TODO)

**API'ler:**
- NtAllocateVirtualMemory
- NtWriteVirtualMemory
- NtCreateThreadEx

---

## T1562 - Impair Defenses

### T1562.001 - Disable or Modify Tools

**Açıklama:**
- AMSI bypass
- ETW patching
- NTDLL unhooking

**Dosyalar:**
- `evasion/03_amsi_bypass.py`
- `evasion/04_etw_bypass.py`
- `evasion/02_ntdll_unhooking.py`

---

## Detection Matrix

| Teknik | Sysmon | ETW | Defender | Difficulty |
|--------|--------|-----|----------|------------|
| Local Injection | ⚠️ | ✅ | ✅ | Kolay |
| Remote Thread | ✅ | ✅ | ✅ | Kolay |
| Process Hollowing | ⚠️ | ✅ | ✅ | Orta |
| APC Injection | ⚠️ | ✅ | ⚠️ | Orta |
| Thread Hijacking | ⚠️ | ✅ | ⚠️ | Zor |
| Direct Syscalls | ❌ | ⚠️ | ⚠️ | Zor |
| NTDLL Unhooking | ❌ | ⚠️ | ❌ | Çok Zor |

**Açıklama:**
- ✅ = Kolayca tespit edilir
- ⚠️ = Tespit edilebilir ama zor
- ❌ = Tespit edilmesi çok zor

---

## Telemetry Sources

### Windows Event Logs
- Security (4688 - Process Creation)
- Sysmon (1, 8, 10)

### ETW Providers
- Microsoft-Windows-Kernel-Process
- Microsoft-Windows-Kernel-Memory
- Microsoft-Windows-Threat-Intelligence (PPL required)

### EDR Telemetry
- API hooking
- Kernel callbacks
- Memory scanning

---

## References

1. [MITRE ATT&CK - Process Injection](https://attack.mitre.org/techniques/T1055/)
2. [Elastic - Ten Process Injection Techniques](https://www.elastic.co/blog/ten-process-injection-techniques-technical-survey-common-and-trending-process)
3. [Red Team Notes - Code Injection](https://www.ired.team/offensive-security/code-injection-process-injection)
