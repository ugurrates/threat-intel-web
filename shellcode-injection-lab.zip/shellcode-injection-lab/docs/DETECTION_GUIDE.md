# 🛡️ Detection Rules - Blue Team Guide

## Shellcode Injection Tekniklerinin Tespiti

Bu dokümantasyon, SOC analistleri için shellcode injection tekniklerinin
YARA, Sigma ve KQL kuralları ile tespitini içerir.

---

## 📋 YARA Rules

### Generic Process Injection Detection

```yara
rule Process_Injection_APIs {
    meta:
        description = "Detects common process injection API patterns"
        author = "Ugur Ates"
        mitre = "T1055"
        severity = "high"
    
    strings:
        // Memory allocation
        $api_valloc = "VirtualAlloc" ascii wide
        $api_vallocex = "VirtualAllocEx" ascii wide
        
        // Memory write
        $api_wpm = "WriteProcessMemory" ascii wide
        
        // Thread creation
        $api_crt = "CreateRemoteThread" ascii wide
        $api_ntcte = "NtCreateThreadEx" ascii wide
        $api_rtlcreate = "RtlCreateUserThread" ascii wide
        
        // Process access
        $api_open = "OpenProcess" ascii wide
        
        // Memory protection
        $prot_rwx = { 40 00 00 00 }  // PAGE_EXECUTE_READWRITE
        
    condition:
        uint16(0) == 0x5A4D and  // MZ header
        3 of ($api_*) and
        $prot_rwx
}

rule Process_Hollowing_Pattern {
    meta:
        description = "Detects process hollowing technique"
        author = "Ugur Ates"
        mitre = "T1055.012"
        severity = "critical"
    
    strings:
        $api1 = "CreateProcessW" ascii wide
        $api2 = "CreateProcessA" ascii wide
        $api3 = "NtUnmapViewOfSection" ascii wide
        $api4 = "ZwUnmapViewOfSection" ascii wide
        $api5 = "VirtualAllocEx" ascii wide
        $api6 = "WriteProcessMemory" ascii wide
        $api7 = "SetThreadContext" ascii wide
        $api8 = "ResumeThread" ascii wide
        
        // CREATE_SUSPENDED flag
        $flag = { 04 00 00 00 }
        
    condition:
        uint16(0) == 0x5A4D and
        ($api1 or $api2) and
        ($api3 or $api4) and
        $api5 and $api6 and $api7 and $api8
}

rule APC_Injection_Pattern {
    meta:
        description = "Detects APC injection technique"
        author = "Ugur Ates"
        mitre = "T1055.004"
        severity = "high"
    
    strings:
        $api1 = "QueueUserAPC" ascii wide
        $api2 = "NtQueueApcThread" ascii wide
        $api3 = "VirtualAllocEx" ascii wide
        $api4 = "WriteProcessMemory" ascii wide
        $api5 = "OpenThread" ascii wide
        
    condition:
        uint16(0) == 0x5A4D and
        ($api1 or $api2) and
        $api3 and $api4
}

rule Direct_Syscall_Pattern {
    meta:
        description = "Detects direct syscall usage"
        author = "Ugur Ates"
        mitre = "T1106"
        severity = "high"
    
    strings:
        // syscall instruction
        $syscall = { 0F 05 }
        
        // Common syscall stub pattern
        // mov r10, rcx; mov eax, XX; syscall
        $stub1 = { 4C 8B D1 B8 ?? ?? 00 00 0F 05 }
        
        // int 2e (legacy syscall)
        $int2e = { CD 2E }
        
    condition:
        uint16(0) == 0x5A4D and
        (#syscall > 5 or $stub1 or $int2e)
}

rule AMSI_Bypass_Pattern {
    meta:
        description = "Detects AMSI bypass attempts"
        author = "Ugur Ates"
        mitre = "T1562.001"
        severity = "critical"
    
    strings:
        $s1 = "AmsiScanBuffer" ascii wide
        $s2 = "AmsiInitialize" ascii wide
        $s3 = "amsiInitFailed" ascii wide
        $s4 = "AmsiUtils" ascii wide
        
        // Patch pattern: mov eax, 0x80070057; ret
        $patch = { B8 57 00 07 80 C3 }
        
    condition:
        2 of ($s*) or $patch
}

rule Shellcode_Memory_Pattern {
    meta:
        description = "Detects common shellcode patterns in memory"
        author = "Ugur Ates"
        mitre = "T1055"
        severity = "medium"
    
    strings:
        // x64 shellcode prologue patterns
        $sc1 = { FC 48 83 E4 F0 }  // cld; and rsp, 0xFFFFFFF0
        $sc2 = { 48 31 C9 48 81 E9 }  // xor rcx, rcx; sub rcx, XX
        $sc3 = { 48 8D 05 ?? ?? ?? ?? 48 BB }  // lea rax; mov rbx
        
        // PEB access pattern (shellcode)
        $peb = { 65 48 8B 04 25 60 00 00 00 }  // mov rax, gs:[0x60]
        
        // GetProcAddress hash
        $hash = { 41 C1 C9 0D }  // ror r9d, 0xD
        
    condition:
        2 of them
}

rule NTDLL_Unhooking_Pattern {
    meta:
        description = "Detects NTDLL unhooking attempts"
        author = "Ugur Ates"
        mitre = "T1562.001"
        severity = "critical"
    
    strings:
        $s1 = "\\KnownDlls\\ntdll.dll" ascii wide
        $s2 = "NtOpenSection" ascii wide
        $s3 = "NtMapViewOfSection" ascii wide
        $s4 = "C:\\Windows\\System32\\ntdll.dll" ascii wide nocase
        
    condition:
        uint16(0) == 0x5A4D and
        2 of them
}
```

---

## 📋 Sigma Rules

### Process Injection Detection

```yaml
title: CreateRemoteThread Injection
id: a1b2c3d4-e5f6-7890-abcd-ef1234567890
status: experimental
description: Detects CreateRemoteThread API usage for process injection
author: Ugur Ates
references:
    - https://attack.mitre.org/techniques/T1055/
logsource:
    product: windows
    service: sysmon
detection:
    selection:
        EventID: 8  # CreateRemoteThread
    filter_legitimate:
        SourceImage|endswith:
            - '\csrss.exe'
            - '\services.exe'
            - '\svchost.exe'
            - '\wininit.exe'
            - '\lsass.exe'
    condition: selection and not filter_legitimate
level: high
tags:
    - attack.defense_evasion
    - attack.privilege_escalation
    - attack.t1055
```

```yaml
title: Process Hollowing Detection
id: b2c3d4e5-f6a7-8901-bcde-f23456789012
status: experimental
description: Detects process hollowing via suspended process creation
author: Ugur Ates
logsource:
    product: windows
    service: sysmon
detection:
    selection_create:
        EventID: 1  # Process Creation
        # CREATE_SUSPENDED can be detected via behavior
    selection_access:
        EventID: 10  # ProcessAccess
        GrantedAccess|contains:
            - '0x1FFFFF'  # PROCESS_ALL_ACCESS
    filter:
        SourceImage|endswith: '\explorer.exe'
    condition: (selection_create or selection_access) and not filter
level: high
tags:
    - attack.defense_evasion
    - attack.t1055.012
```

```yaml
title: Suspicious Memory Allocation
id: c3d4e5f6-a7b8-9012-cdef-345678901234
status: experimental
description: Detects suspicious memory allocation with RWX permissions
author: Ugur Ates
logsource:
    product: windows
    category: api_call
detection:
    selection:
        ApiCall|contains:
            - 'VirtualAlloc'
            - 'NtAllocateVirtualMemory'
        MemoryProtection: 
            - '0x40'  # PAGE_EXECUTE_READWRITE
    filter:
        CallerModule|endswith:
            - '\ntdll.dll'
            - '\kernel32.dll'
            - '\kernelbase.dll'
    condition: selection and not filter
level: medium
tags:
    - attack.t1055
```

```yaml
title: AMSI Bypass Attempt
id: d4e5f6a7-b8c9-0123-def0-456789012345
status: stable
description: Detects AMSI bypass attempts in PowerShell
author: Ugur Ates
logsource:
    product: windows
    category: ps_script_block_logging
detection:
    selection:
        ScriptBlockText|contains:
            - 'AmsiScanBuffer'
            - 'amsiInitFailed'
            - 'AmsiUtils'
            - 'Runtime.InteropServices.Marshal'
            - 'System.Management.Automation.AmsiUtils'
    condition: selection
level: critical
tags:
    - attack.defense_evasion
    - attack.t1562.001
```

```yaml
title: NTDLL Unhooking Attempt
id: e5f6a7b8-c9d0-1234-ef01-567890123456
status: experimental
description: Detects attempts to unhook NTDLL
author: Ugur Ates
logsource:
    product: windows
    category: file_access
detection:
    selection:
        TargetFilename|endswith: '\ntdll.dll'
        AccessMask: '0x120089'  # Read access
    filter:
        ProcessName|endswith:
            - '\smss.exe'
            - '\csrss.exe'
            - '\services.exe'
            - '\svchost.exe'
    condition: selection and not filter
level: high
tags:
    - attack.defense_evasion
    - attack.t1562.001
```

---

## 📋 KQL Queries (Microsoft Defender for Endpoint)

### Remote Thread Injection Detection

```kusto
// CreateRemoteThread across processes
DeviceEvents
| where ActionType == "CreateRemoteThreadApiCall"
| where InitiatingProcessId != TargetProcessId
| project 
    Timestamp,
    DeviceName,
    InitiatingProcessFileName,
    InitiatingProcessId,
    TargetProcessFileName = FileName,
    TargetProcessId,
    RemoteThreadId
| where InitiatingProcessFileName !in ("csrss.exe", "services.exe", "svchost.exe")
| order by Timestamp desc
```

### Memory Allocation in Remote Process

```kusto
// VirtualAllocEx in remote processes
DeviceEvents
| where ActionType == "NtAllocateVirtualMemoryRemoteApiCall"
| project 
    Timestamp,
    DeviceName,
    InitiatingProcessFileName,
    TargetProcessFileName = FileName,
    AdditionalFields
| extend AllocSize = parse_json(AdditionalFields).AllocatedSize
| extend Protection = parse_json(AdditionalFields).ProtectionAttributes
| where Protection contains "EXECUTE"
```

### Process Hollowing Detection

```kusto
// Suspended process creation followed by memory manipulation
let suspicious_creates = 
DeviceProcessEvents
| where ProcessCreationFlags has "CREATE_SUSPENDED"
| project ProcessId, SuspendedTime = Timestamp, FileName;

DeviceEvents
| where ActionType in ("NtWriteVirtualMemoryApiCall", "SetThreadContextApiCall")
| join kind=inner suspicious_creates on $left.TargetProcessId == $right.ProcessId
| where Timestamp between (SuspendedTime .. SuspendedTime + 30s)
| project 
    Timestamp,
    DeviceName,
    InitiatingProcessFileName,
    TargetProcessFileName = FileName,
    ActionType
```

### AMSI Bypass Detection

```kusto
// PowerShell AMSI bypass attempts
DeviceEvents
| where ActionType == "PowerShellCommand"
| where AdditionalFields has_any (
    "AmsiScanBuffer",
    "amsiInitFailed",
    "AmsiUtils",
    "VirtualProtect"
)
| project 
    Timestamp,
    DeviceName,
    InitiatingProcessFileName,
    CommandLine = tostring(parse_json(AdditionalFields).ScriptBlock)
```

### Direct Syscall Detection

```kusto
// Syscall from non-standard module (call stack analysis)
DeviceEvents
| where ActionType contains "VirtualMemory" or ActionType contains "Thread"
| extend CallStack = tostring(parse_json(AdditionalFields).CallStack)
| where CallStack !contains "ntdll.dll"
| where CallStack !contains "kernel32.dll"
| project 
    Timestamp,
    DeviceName,
    InitiatingProcessFileName,
    ActionType,
    CallStack
```

### Thread Hijacking Detection

```kusto
// SetThreadContext on remote threads
DeviceEvents
| where ActionType == "SetThreadContextApiCall"
| where InitiatingProcessId != TargetProcessId
| project 
    Timestamp,
    DeviceName,
    InitiatingProcessFileName,
    TargetProcessFileName = FileName,
    TargetThreadId
```

### DLL Injection Detection

```kusto
// Unsigned DLL loads from suspicious paths
DeviceImageLoadEvents
| where SignatureState != "Valid"
| where FolderPath has_any ("\\Temp\\", "\\AppData\\", "\\Downloads\\", "\\Users\\")
| where FileName !in ("ntdll.dll", "kernel32.dll", "kernelbase.dll")
| project 
    Timestamp,
    DeviceName,
    FileName,
    FolderPath,
    InitiatingProcessFileName,
    SignatureState
```

---

## 📋 Sysmon Configuration

```xml
<Sysmon schemaversion="4.90">
  <EventFiltering>
    
    <!-- Event ID 8: CreateRemoteThread -->
    <RuleGroup name="ProcessInjection" groupRelation="or">
      <CreateRemoteThread onmatch="include">
        <TargetImage condition="is not">C:\Windows\System32\csrss.exe</TargetImage>
      </CreateRemoteThread>
    </RuleGroup>
    
    <!-- Event ID 10: Process Access (for injection detection) -->
    <ProcessAccess onmatch="include">
      <GrantedAccess condition="is">0x1FFFFF</GrantedAccess>
      <GrantedAccess condition="is">0x1F0FFF</GrantedAccess>
      <GrantedAccess condition="is">0x143A</GrantedAccess>
    </ProcessAccess>
    
    <!-- Event ID 7: Image Load (DLL injection) -->
    <ImageLoad onmatch="include">
      <ImageLoaded condition="contains">\Temp\</ImageLoaded>
      <ImageLoaded condition="contains">\AppData\Local\Temp\</ImageLoaded>
      <Signed condition="is">false</Signed>
    </ImageLoad>
    
  </EventFiltering>
</Sysmon>
```

---

## 📋 Quick Reference Table

| Technique | Event ID | API Calls | Detection Difficulty |
|-----------|----------|-----------|---------------------|
| Local Injection | 8 | VirtualAlloc, CreateThread | Easy |
| Remote Thread | 8, 10 | OpenProcess, VirtualAllocEx, CreateRemoteThread | Easy |
| Process Hollowing | 1, 10 | CreateProcess(SUSPENDED), NtUnmapViewOfSection | Medium |
| Thread Hijacking | 10 | SuspendThread, SetThreadContext | Medium |
| APC Injection | 10 | QueueUserAPC | Medium |
| DLL Injection | 7, 8 | LoadLibrary, CreateRemoteThread | Easy |
| Direct Syscalls | - | syscall instruction | Hard |
| NTDLL Unhooking | - | Memory patch | Hard |
| AMSI Bypass | - | AmsiScanBuffer patch | Medium |

---

**Author:** Ugur Ates | SOC Team Lead
**Last Updated:** 2024
