# 🔬 Shellcode Injection Lab

## Eğitim Amaçlı Kapsamlı Shellcode Injection Teknikleri

> ⚠️ **UYARI:** Bu proje yalnızca eğitim ve araştırma amaçlıdır. Yetkisiz sistemlerde kullanmak yasadışıdır.

---

## 📚 Proje Hakkında

Bu proje, SOC analistleri ve güvenlik araştırmacıları için shellcode injection tekniklerini **hem saldırı hem savunma** perspektifinden anlatan kapsamlı bir laboratuvar ortamıdır.

### Hedef Kitle
- SOC Analistleri (Blue Team)
- Penetration Tester'lar (Red Team)
- Malware Analistleri
- Güvenlik Araştırmacıları

---

## 🗂️ Proje Yapısı

```
shellcode-injection-lab/
│
├── 01-fundamentals/              # Temel kavramlar
│   ├── shellcode_basics.py       # Shellcode nedir, nasıl çalışır
│   └── pe_structure.py           # PE dosya yapısı analizi
│
├── 02-injection-techniques/      # Injection teknikleri
│   ├── 01_local_injection.py     # Local process injection
│   ├── 02_remote_injection.py    # Remote thread injection
│   ├── 03_process_hollowing.py   # Process hollowing
│   ├── 04_thread_hijacking.py    # Thread hijacking
│   ├── 05_apc_injection.py       # APC Queue injection
│   └── 06_dll_injection.py       # DLL injection
│
├── 03-evasion-techniques/        # AV/EDR bypass teknikleri
│   ├── 01_direct_syscalls.py     # Direct syscall kullanımı
│   ├── 02_ntdll_unhooking.py     # NTDLL unhooking
│   ├── 03_amsi_bypass.py         # AMSI bypass
│   ├── 04_etw_bypass.py          # ETW patching
│   └── 05_encryption.py          # Payload encryption (AES/XOR)
│
├── 04-detection/                 # Tespit yöntemleri
│   ├── detection_rules.md        # YARA/Sigma kuralları
│   ├── kql_queries.md            # KQL sorguları
│   └── behavioral_indicators.md  # Davranışsal göstergeler
│
├── 05-payloads/                  # Test payload'ları
│   ├── calc_shellcode.py         # Calculator açan shellcode
│   ├── msgbox_shellcode.py       # MessageBox gösteren shellcode
│   └── reverse_shell.py          # Reverse shell (msfvenom)
│
├── utils/                        # Yardımcı araçlar
│   ├── shellcode_generator.py    # Shellcode üretici
│   ├── pe_analyzer.py            # PE analiz aracı
│   └── process_utils.py          # Process yardımcıları
│
├── docs/                         # Dokümantasyon
│   ├── MITRE_MAPPING.md          # MITRE ATT&CK mapping
│   ├── API_REFERENCE.md          # Windows API referansı
│   └── DETECTION_GUIDE.md        # Tespit rehberi
│
└── requirements.txt              # Python bağımlılıkları
```

---

## 🎯 Teknikler ve MITRE ATT&CK Mapping

| Teknik | MITRE ID | Zorluk | Tespit Seviyesi |
|--------|----------|--------|-----------------|
| Local Injection | T1055 | ⭐ | Kolay |
| Remote Thread Injection | T1055.001 | ⭐⭐ | Orta |
| Process Hollowing | T1055.012 | ⭐⭐⭐ | Zor |
| Thread Hijacking | T1055.003 | ⭐⭐⭐ | Zor |
| APC Injection | T1055.004 | ⭐⭐⭐ | Orta |
| DLL Injection | T1055.001 | ⭐⭐ | Kolay |
| Direct Syscalls | T1106 | ⭐⭐⭐⭐ | Çok Zor |
| NTDLL Unhooking | T1562.001 | ⭐⭐⭐⭐ | Çok Zor |

---

## 🚀 Kurulum

### Gereksinimler
- Windows 10/11 (x64)
- Python 3.8+
- Visual Studio Build Tools (C derleyici için)

### Kurulum Adımları

```bash
# Repository'yi klonla
git clone https://github.com/your-repo/shellcode-injection-lab.git
cd shellcode-injection-lab

# Virtual environment oluştur
python -m venv venv
venv\Scripts\activate

# Bağımlılıkları yükle
pip install -r requirements.txt
```

---

## 📖 Kullanım

### 1. Temel Örnek - Local Injection
```python
from techniques.local_injection import LocalInjector

# MessageBox shellcode
shellcode = bytes([...])

injector = LocalInjector()
injector.inject(shellcode)
```

### 2. Remote Injection
```python
from techniques.remote_injection import RemoteInjector

injector = RemoteInjector(target_pid=1234)
injector.inject(shellcode)
```

### 3. Process Hollowing
```python
from techniques.process_hollowing import ProcessHollowing

hollower = ProcessHollowing(target_exe="C:\\Windows\\System32\\notepad.exe")
hollower.hollow_and_inject(shellcode)
```

---

## 🛡️ Blue Team Perspektifi

Her teknik için:
- Tespit göstergeleri (IOCs)
- YARA kuralları
- Sigma kuralları
- KQL sorguları
- Davranışsal analiz ipuçları

---

## 📚 Referanslar

- [MITRE ATT&CK - Process Injection](https://attack.mitre.org/techniques/T1055/)
- [Elastic - Ten Process Injection Techniques](https://www.elastic.co/blog/ten-process-injection-techniques-technical-survey-common-and-trending-process)
- [Red Team Notes](https://www.ired.team/)
- [HackTricks - AV Bypass](https://book.hacktricks.xyz/windows-hardening/av-bypass)

---

## ⚖️ Yasal Uyarı

Bu araçlar yalnızca:
- Eğitim amaçlı
- Yetkili penetration testleri
- Güvenlik araştırmaları

için kullanılmalıdır. Yetkisiz kullanım yasadışıdır.

---

**Yazar:** Ugur Ates | SOC Team Lead | Aviation Cybersecurity
