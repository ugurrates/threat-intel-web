#!/usr/bin/env python3
"""
Shellcode Injection Lab - Main Entry Point
==========================================

Eğitim amaçlı shellcode injection tekniklerini gösteren interaktif lab.

Kullanım:
    python main.py

Author: Ugur Ates
Purpose: Educational - Blue Team & Red Team Training
"""

import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

BANNER = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║   ███████╗██╗  ██╗███████╗██╗     ██╗      ██████╗ ██████╗ ██████╗ ███████╗  ║
║   ██╔════╝██║  ██║██╔════╝██║     ██║     ██╔════╝██╔═══██╗██╔══██╗██╔════╝  ║
║   ███████╗███████║█████╗  ██║     ██║     ██║     ██║   ██║██║  ██║█████╗    ║
║   ╚════██║██╔══██║██╔══╝  ██║     ██║     ██║     ██║   ██║██║  ██║██╔══╝    ║
║   ███████║██║  ██║███████╗███████╗███████╗╚██████╗╚██████╔╝██████╔╝███████╗  ║
║   ╚══════╝╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝  ║
║                                                                              ║
║                    ██╗███╗   ██╗     ██╗███████╗ ██████╗████████╗            ║
║                    ██║████╗  ██║     ██║██╔════╝██╔════╝╚══██╔══╝            ║
║                    ██║██╔██╗ ██║     ██║█████╗  ██║        ██║               ║
║                    ██║██║╚██╗██║██   ██║██╔══╝  ██║        ██║               ║
║                    ██║██║ ╚████║╚█████╔╝███████╗╚██████╗   ██║               ║
║                    ╚═╝╚═╝  ╚═══╝ ╚════╝ ╚══════╝ ╚═════╝   ╚═╝               ║
║                                                                              ║
║                        ██╗      █████╗ ██████╗                               ║
║                        ██║     ██╔══██╗██╔══██╗                              ║
║                        ██║     ███████║██████╔╝                              ║
║                        ██║     ██╔══██║██╔══██╗                              ║
║                        ███████╗██║  ██║██████╔╝                              ║
║                        ╚══════╝╚═╝  ╚═╝╚═════╝                               ║
║                                                                              ║
║                    Educational Shellcode Injection Framework                  ║
║                                                                              ║
║                    Author: Ugur Ates | SOC Team Lead                         ║
║                    Purpose: Blue Team & Red Team Training                    ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

MENU = """
┌──────────────────────────────────────────────────────────────────────────────┐
│                              MAIN MENU                                        │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  🔴 INJECTION TECHNIQUES                                                     │
│  ────────────────────────                                                    │
│  1. Local Process Injection (Shellcode Runner)                               │
│  2. Remote Thread Injection (CreateRemoteThread)                             │
│  3. Process Hollowing (RunPE)                                                │
│  4. APC Queue Injection                                                      │
│  5. Thread Hijacking                                                         │
│  6. DLL Injection                                                            │
│                                                                              │
│  🟡 EVASION TECHNIQUES                                                       │
│  ─────────────────────                                                       │
│  7. Direct Syscalls                                                          │
│  8. NTDLL Unhooking                                                          │
│  9. AMSI Bypass                                                              │
│  10. Payload Encryption                                                      │
│                                                                              │
│  🔵 BLUE TEAM TOOLS                                                          │
│  ──────────────────                                                          │
│  11. Hook Detection                                                          │
│  12. AMSI Status Check                                                       │
│                                                                              │
│  📚 DOCUMENTATION                                                            │
│  ────────────────                                                            │
│  13. MITRE ATT&CK Mapping                                                    │
│  14. Detection Guide                                                         │
│                                                                              │
│  0. Exit                                                                     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
"""

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def show_file(filepath):
    """Display markdown file content"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        print(content)
    except FileNotFoundError:
        print(f"❌ File not found: {filepath}")
    input("\n[Press Enter to continue...]")

def main():
    while True:
        clear_screen()
        print(BANNER)
        print(MENU)
        
        choice = input("Select option: ").strip()
        
        if choice == "0":
            print("\n👋 Goodbye!")
            break
            
        elif choice == "1":
            from techniques.local_injection import inject_rwx_split
            from payloads.test_shellcodes import CALC_SHELLCODE_X64
            print("\n⚠️ This will execute calculator shellcode!")
            confirm = input("Continue? (y/n): ").strip().lower()
            if confirm == 'y':
                inject_rwx_split(CALC_SHELLCODE_X64)
            input("\n[Press Enter to continue...]")
            
        elif choice == "2":
            print("\n🎯 Remote Thread Injection")
            print("─" * 40)
            pid = input("Target PID (notepad.exe recommended): ").strip()
            if pid:
                from techniques.remote_injection import inject_remote
                from payloads.test_shellcodes import CALC_SHELLCODE_X64
                try:
                    inject_remote(CALC_SHELLCODE_X64, int(pid))
                except ValueError:
                    print("Invalid PID")
            input("\n[Press Enter to continue...]")
            
        elif choice == "3":
            from techniques.process_hollowing import hollow_with_shellcode
            from payloads.test_shellcodes import CALC_SHELLCODE_X64
            print("\n⚠️ This will create a hollowed notepad.exe process!")
            confirm = input("Continue? (y/n): ").strip().lower()
            if confirm == 'y':
                hollow_with_shellcode(CALC_SHELLCODE_X64)
            input("\n[Press Enter to continue...]")
            
        elif choice == "4":
            print("\n🎯 APC Queue Injection")
            print("1. Inject to existing process")
            print("2. Early Bird (new suspended process)")
            sub = input("Select (1/2): ").strip()
            
            from payloads.test_shellcodes import CALC_SHELLCODE_X64
            
            if sub == "1":
                pid = input("Target PID: ").strip()
                if pid:
                    from techniques.apc_injection import inject_apc
                    try:
                        inject_apc(CALC_SHELLCODE_X64, int(pid))
                    except ValueError:
                        print("Invalid PID")
            elif sub == "2":
                from techniques.apc_injection import early_bird_injection
                early_bird_injection(CALC_SHELLCODE_X64, 
                    r"C:\Windows\System32\notepad.exe")
            input("\n[Press Enter to continue...]")
            
        elif choice == "5":
            print("\n⚠️ Thread Hijacking can crash the target process!")
            pid = input("Target PID: ").strip()
            if pid:
                from techniques.thread_hijacking import hijack_thread
                from payloads.test_shellcodes import CALC_SHELLCODE_X64
                confirm = input("Continue? (y/n): ").strip().lower()
                if confirm == 'y':
                    try:
                        hijack_thread(CALC_SHELLCODE_X64, int(pid))
                    except ValueError:
                        print("Invalid PID")
            input("\n[Press Enter to continue...]")
            
        elif choice == "6":
            print("\n🎯 DLL Injection")
            print("1. Inject DLL")
            print("2. Generate DLL source code")
            sub = input("Select (1/2): ").strip()
            
            if sub == "1":
                dll_path = input("DLL full path: ").strip()
                pid = input("Target PID: ").strip()
                if dll_path and pid:
                    from techniques.dll_injection import inject_dll
                    try:
                        inject_dll(dll_path, int(pid))
                    except ValueError:
                        print("Invalid PID")
            elif sub == "2":
                from techniques.dll_injection import generate_dll_source
                print("\n" + generate_dll_source())
            input("\n[Press Enter to continue...]")
            
        elif choice == "7":
            from evasion.direct_syscalls import TECHNIQUE_INFO, DETECTION_RULES
            from evasion.direct_syscalls import SYSCALL_NUMBERS, print_syscall_stub
            print(TECHNIQUE_INFO)
            print("\nSyscall Stubs:")
            for name, number in SYSCALL_NUMBERS.items():
                print_syscall_stub(name, number)
            print(DETECTION_RULES)
            input("\n[Press Enter to continue...]")
            
        elif choice == "8":
            from evasion.ntdll_unhooking import TECHNIQUE_INFO, detect_hooks
            print(TECHNIQUE_INFO)
            print("\n🔍 Detecting hooks...")
            hooks = detect_hooks()
            if hooks:
                print(f"\n🚨 {len(hooks)} hooks detected!")
            else:
                print("\n✅ No hooks detected")
            input("\n[Press Enter to continue...]")
            
        elif choice == "9":
            from evasion.amsi_bypass import TECHNIQUE_INFO, test_amsi
            print(TECHNIQUE_INFO)
            print("\n🔍 Testing AMSI...")
            is_active = test_amsi()
            if is_active:
                print("\n✅ AMSI is active")
            else:
                print("\n⚠️ AMSI is not active or bypassed")
            input("\n[Press Enter to continue...]")
            
        elif choice == "10":
            from evasion.encryption import transform_shellcode, generate_c_loader
            from payloads.test_shellcodes import CALC_SHELLCODE_X64
            
            print("\n🔐 Payload Encryption")
            print("1. XOR")
            print("2. RC4")
            print("3. AES-256")
            method = input("Select method (1/2/3): ").strip()
            
            methods = {"1": "xor", "2": "rc4", "3": "aes"}
            if method in methods:
                result = transform_shellcode(CALC_SHELLCODE_X64, methods[method])
                print(f"\n✅ Encrypted with {methods[method].upper()}")
                print(f"   Original size: {result['original_size']} bytes")
                print(f"   Encrypted size: {len(result['encrypted'])} bytes")
                print(f"   Key: {result['key'].hex()[:32]}...")
                
                gen = input("\nGenerate C loader? (y/n): ").strip().lower()
                if gen == 'y':
                    code = generate_c_loader(
                        result['encrypted'], 
                        result['key'], 
                        methods[method]
                    )
                    print("\n" + code[:2000] + "...")
            input("\n[Press Enter to continue...]")
            
        elif choice == "11":
            from evasion.ntdll_unhooking import detect_hooks
            print("\n🔍 Hook Detection")
            print("─" * 40)
            hooks = detect_hooks(verbose=True)
            input("\n[Press Enter to continue...]")
            
        elif choice == "12":
            from evasion.amsi_bypass import test_amsi
            print("\n🔍 AMSI Status Check")
            print("─" * 40)
            test_amsi(verbose=True)
            input("\n[Press Enter to continue...]")
            
        elif choice == "13":
            show_file("docs/MITRE_MAPPING.md")
            
        elif choice == "14":
            show_file("docs/DETECTION_GUIDE.md")
            
        else:
            print("\n❌ Invalid option")
            input("\n[Press Enter to continue...]")

if __name__ == "__main__":
    print("\n⚠️ WARNING: This tool is for EDUCATIONAL purposes only!")
    print("   Unauthorized use against systems you don't own is ILLEGAL.")
    print("")
    confirm = input("Do you understand and accept? (yes/no): ").strip().lower()
    
    if confirm == "yes":
        main()
    else:
        print("\nExiting...")
